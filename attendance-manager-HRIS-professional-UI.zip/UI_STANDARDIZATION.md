# HRIS UI Standardization

This version applies a professional enterprise HRIS visual baseline without changing application business logic.

## Changes
- Standardized the primary typeface to Inter.
- Removed Space Grotesk and JetBrains Mono as UI defaults.
- Standardized heading hierarchy.
- Reduced oversized typography and excessive letter spacing.
- Replaced excessive rounded-2xl/rounded-3xl styling with compact rounded-lg treatment.
- Replaced heavy shadow-xl/shadow-2xl styling with subtle shadows.
- Standardized tiny 8–11px labels toward readable 12px text.
- Reduced excessive `font-black` usage to `font-semibold`.
- Added centralized HRIS design utility classes for cards, inputs, buttons and status badges.
- Standardized enterprise blue, slate neutral, and semantic status colors.
- Preserved existing React/Firebase/Firestore/business logic.

## Validation
The source was inspected after changes. A local production build could not be executed because the environment could not install one dependency (`@types/nodemailer`) from its package registry. No application source or dependency configuration was intentionally changed to work around that limitation.
