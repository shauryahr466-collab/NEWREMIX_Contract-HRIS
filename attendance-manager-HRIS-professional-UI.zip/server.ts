import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import nodemailer from 'nodemailer';
import { fileURLToPath } from 'url';
import { initializeApp, cert } from 'firebase-admin/app';
import { getFirestore, FieldValue } from 'firebase-admin/firestore';
import { getAuth } from 'firebase-admin/auth';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Initialize Firebase Admin
initializeApp({
  projectId: 'infra-snowfall-cq7jp'
});

const db = getFirestore();
const authAdmin = getAuth();

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Middleware to verify Admin token
  const verifyAdmin = async (req: express.Request, res: express.Response, next: express.NextFunction) => {
    const authHeader = req.headers.authorization;
    if (!authHeader?.startsWith('Bearer ')) return res.status(401).json({ error: 'Unauthorized' });

    const idToken = authHeader.split('Bearer ')[1];
    try {
      const decodedToken = await authAdmin.verifyIdToken(idToken);
      // In a real app, check if decodedToken.role === 'admin' or if email matches ADMIN_EMAIL
      // For now, we'll assume any valid token from the designated admin email is OK
      const ADMIN_EMAILS = ['hr.sandiprajak466@gmail.com', 'shauryahr466@gmail.com'];
      if (!ADMIN_EMAILS.includes(decodedToken.email?.toLowerCase() || '')) {
        return res.status(403).json({ error: 'Forbidden: Admin access required' });
      }
      next();
    } catch (error) {
      res.status(401).json({ error: 'Invalid token' });
    }
  };

  // OTP Store
  const otpStore = new Map<string, { code: string; expires: number }>();

  // API Routes
  app.post('/api/auth/send-otp', async (req, res) => {
    const { email } = req.body;
    if (!email) return res.status(400).json({ error: 'Email is required' });

    const otp = Math.floor(100000 + Math.random() * 900000).toString();
    otpStore.set(email, { code: otp, expires: Date.now() + 10 * 60 * 1000 });

    console.log(`[OTP] Generated for ${email}: ${otp}`);

    try {
      const transporter = nodemailer.createTransport({
        host: process.env.SMTP_HOST || 'smtp.ethereal.email',
        port: parseInt(process.env.SMTP_PORT || '587'),
        secure: false,
        auth: {
          user: process.env.SMTP_USER,
          pass: process.env.SMTP_PASS,
        },
      });

      if (!process.env.SMTP_USER) {
        return res.json({ 
          message: 'OTP sent (simulated)',
          debugOtp: process.env.NODE_ENV !== 'production' ? otp : undefined 
        });
      }

      await transporter.sendMail({
        from: '"Contractor HRIS" <noreply@contractorhris.com>',
        to: email,
        subject: "Your Authentication Code",
        html: `<div style="font-family: sans-serif; padding: 20px;"><h2>Verification Code</h2><p>Your code is: <strong>${otp}</strong></p></div>`,
      });

      res.json({ message: 'OTP sent' });
    } catch (error) {
      res.status(500).json({ error: 'Email failed' });
    }
  });

  app.post('/api/auth/verify-otp', (req, res) => {
    const { email, code } = req.body;
    const stored = otpStore.get(email);
    if (!stored || stored.code !== code || Date.now() > stored.expires) {
      return res.status(400).json({ error: 'Invalid OTP' });
    }
    otpStore.delete(email);
    res.json({ success: true });
  });

  // Admin Routes
  app.post('/api/admin/create-user', verifyAdmin, async (req, res) => {
    const { email, password, displayName, role } = req.body;
    try {
      const userRecord = await authAdmin.createUser({
        email,
        password,
        displayName,
      });

      // Save user profile in Firestore
      await db.collection('users').doc(userRecord.uid).set({
        id: userRecord.uid,
        username: displayName,
        email: email,
        role: role || 'Editor',
        createdAt: FieldValue.serverTimestamp(),
      });

      res.json({ success: true, uid: userRecord.uid });
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.get('/api/admin/users', verifyAdmin, async (req, res) => {
    try {
      const snapshot = await db.collection('users').get();
      const users = snapshot.docs.map(doc => doc.data());
      res.json(users);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
