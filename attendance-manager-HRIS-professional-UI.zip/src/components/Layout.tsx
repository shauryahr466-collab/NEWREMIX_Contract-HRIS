import React, { useState } from 'react';
import { Outlet, NavLink, useLocation } from 'react-router-dom';
import { LayoutDashboard, Users, FileUp, Fingerprint, FileText, Settings, LogOut, Shield, ShieldAlert, Clock, CalendarRange, UserCheck, ChevronLeft, ChevronRight, Search, Bell, User as UserIcon, Menu, Moon, Sun, RefreshCw } from 'lucide-react';
import { cn } from '../lib/utils';
import { useAppStore } from '../store';
import { auth } from '../lib/firebase';
import { signOut } from 'firebase/auth';
import { motion, AnimatePresence } from 'motion/react';
import { EmployeeDrawer } from './EmployeeDrawer';

const ADMIN_EMAILS = ['hr.sandiprajak466@gmail.com', 'shauryahr466@gmail.com'];

export function Layout() {
  const { 
    settings, selectedEmployeeId, employees, 
    openEmployeeProfile, closeEmployeeProfile, 
    theme, setTheme, globalSearchTerm, setGlobalSearchTerm, 
    recalculate, isInitializing, quotaExceeded, resetError,
    setIsOtpVerified
  } = useAppStore();
  const location = useLocation();
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [isMobileOpen, setIsMobileOpen] = useState(false);
  
  const isAdmin = ADMIN_EMAILS.some(email => auth.currentUser?.email?.toLowerCase() === email.toLowerCase());

  const handleSignOut = () => {
    setIsOtpVerified(false);
    signOut(auth);
  };

  const selectedEmployee = employees.find(e => e.id === selectedEmployeeId) || null;

  const navItems = [
    { to: '/', icon: LayoutDashboard, label: 'Enterprise Dashboard' },
    { to: '/employees', icon: Users, label: 'Employee Directory' },
    { to: '/import', icon: FileUp, label: 'Punch Import' },
    { to: '/attendance', icon: Fingerprint, label: 'Attendance logs' },
    { to: '/auditor', icon: ShieldAlert, label: 'Attendance Auditor' },
    { to: '/audit-logs', icon: Shield, label: 'System Audit Log' },
    { to: '/overtime', icon: Clock, label: 'OT Audit Log' },
    { to: '/sbl', icon: CalendarRange, label: 'SBL Management' },
    { to: '/force-attendance', icon: UserCheck, label: 'Manual Corrections' },
    { to: '/reports', icon: FileText, label: 'Analytic Reports' },
    { to: '/settings', icon: Settings, label: 'Configuration' },
  ];

  if (isAdmin) {
    navItems.push({ to: '/admin', icon: Shield, label: 'System Admin' });
  }

  const currentNavItem = navItems.find(item => item.to === location.pathname);

  return (
    <div className="flex h-screen bg-slate-50 dark:bg-slate-950 text-slate-800 dark:text-slate-100 font-sans overflow-hidden transition-colors duration-300">
      <AnimatePresence>
        {quotaExceeded && (
          <motion.div 
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="fixed top-0 left-0 right-0 z-[100] bg-rose-600 text-white py-2 px-4 flex items-center justify-center gap-3 shadow-lg"
          >
            <ShieldAlert size={16} className="shrink-0" />
            <p className="text-xs font-semibold uppercase tracking-normal text-center">
              Write Quota Exceeded - System in Read-Only Mode. Please wait for daily reset.
            </p>
            <button 
              onClick={resetError}
              className="ml-4 p-1 hover:bg-white/10 rounded transition-colors"
            >
              <Search size={12} className="rotate-45" />
            </button>
          </motion.div>
        )}
      </AnimatePresence>
      {/* Desktop Sidebar */}
      <aside 
        className={cn(
          "flex flex-col hidden md:flex transition-all duration-300 ease-in-out relative z-50",
          theme === 'dark' ? "bg-slate-950 border-r border-slate-800" : "bg-white border-r border-slate-100",
          isCollapsed ? "w-20" : "w-64"
        )}
      >
        <div className="p-6 h-20 flex items-center justify-between border-b border-slate-100 dark:border-white/10">
          <AnimatePresence mode="wait">
            {!isCollapsed && (
              <motion.div 
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -10 }}
                className="flex items-center gap-3"
              >
                <div className="w-8 h-8 enterprise-gradient border border-white/20 rounded-lg flex items-center justify-center font-bold text-white shadow-lg">
                  {settings.companyName.charAt(0).toUpperCase()}
                </div>
                <h1 className="text-lg font-semibold text-slate-900 dark:text-white tracking-tight truncate w-32">{settings.companyName}</h1>
              </motion.div>
            )}
          </AnimatePresence>
          <button 
            onClick={() => setIsCollapsed(!isCollapsed)}
            className="p-1.5 rounded-lg bg-slate-50 dark:bg-white/5 hover:bg-slate-100 dark:hover:bg-white/10 text-slate-400 dark:text-white/60 transition-colors"
          >
            {isCollapsed ? <ChevronRight size={18} /> : <ChevronLeft size={18} />}
          </button>
        </div>
        
        <nav className="flex-1 p-4 space-y-1 overflow-y-auto custom-scrollbar">
          <ul className="space-y-1">
            {navItems.map((item) => (
              <li key={item.to}>
                <NavLink
                  to={item.to}
                  title={isCollapsed ? item.label : undefined}
                  className={({ isActive }) =>
                    cn(
                      'flex items-center gap-3 p-3 rounded-xl text-sm font-semibold transition-all duration-200 group',
                      isActive 
                        ? 'bg-indigo-600 text-white shadow-md shadow-indigo-200 dark:shadow-none' 
                        : 'text-slate-500 dark:text-white/50 hover:bg-slate-50 dark:hover:bg-white/5 hover:text-slate-900 dark:hover:text-white/80'
                    )
                  }
                >
                  <item.icon className={cn("w-5 h-5 shrink-0 transition-transform group-hover:scale-110", isCollapsed ? "mx-auto" : "")} />
                  {!isCollapsed && <span className="truncate">{item.label}</span>}
                </NavLink>
              </li>
            ))}
          </ul>
        </nav>

        <div className="p-4 border-t border-slate-100 dark:border-white/10">
          <div className={cn(
            "p-3 rounded-lg transition-all duration-300",
            isCollapsed ? "bg-transparent" : "bg-slate-50 dark:bg-white/5 border border-slate-100 dark:border-white/5"
          )}>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 shrink-0 rounded-xl bg-indigo-500/20 border border-indigo-500/30 flex items-center justify-center font-bold text-indigo-400">
                {auth.currentUser?.displayName?.charAt(0) || auth.currentUser?.email?.charAt(0) || 'U'}
              </div>
              {!isCollapsed && (
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-semibold text-slate-900 dark:text-white truncate uppercase tracking-tight">
                    {auth.currentUser?.displayName || auth.currentUser?.email?.split('@')[0]}
                  </p>
                  <p className="text-xs font-bold text-slate-500 truncate mt-0.5 opacity-60">
                    {auth.currentUser?.email}
                  </p>
                  <p className="text-xs font-bold text-indigo-400 uppercase tracking-normal mt-1">
                    {isAdmin ? 'Administrator' : 'Staff Member'}
                  </p>
                </div>
              )}
            </div>
            {!isCollapsed && (
              <button 
                onClick={handleSignOut}
                className="mt-4 flex items-center gap-3 p-3 w-full text-xs font-semibold text-rose-500 hover:bg-rose-50 rounded-xl transition-all uppercase tracking-normal"
              >
                <LogOut className="w-4 h-4" />
                Sign Out System
              </button>
            )}
            {isCollapsed && (
               <button 
                onClick={handleSignOut}
                className="mt-4 flex items-center justify-center p-3 w-full text-rose-500 hover:bg-rose-50 rounded-xl transition-all"
                title="Sign Out"
              >
                <LogOut className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col h-full overflow-hidden relative">
        {/* Top Header */}
        <header className="h-20 glass-header flex items-center justify-between px-8 shrink-0">
          <div className="flex items-center gap-6">
            <button 
              onClick={() => setIsMobileOpen(true)}
              className="md:hidden p-2 hover:bg-slate-100 rounded-lg"
            >
              <Menu size={20} />
            </button>
            
            <div className="hidden lg:flex items-center gap-2 text-xs font-semibold uppercase tracking-wide text-slate-400">
              <NavLink to="/" className="hover:text-indigo-600 transition-colors">Core</NavLink>
              <ChevronRight size={10} />
              <span className="text-slate-900 dark:text-white">{currentNavItem?.label || 'Application'}</span>
            </div>
          </div>

          <div className="flex items-center gap-6">
            <div className="relative hidden md:block">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input 
                type="text" 
                placeholder="Search ID or Name..."
                value={globalSearchTerm}
                onChange={(e) => {
                  const val = e.target.value;
                  setGlobalSearchTerm(val);
                  
                  // If exact match found, open profile
                  if (val.length >= 2) {
                    const searchNorm = val.trim().toLowerCase();
                    const found = employees.find(emp => {
                      const empIdNorm = emp.id.trim().toLowerCase();
                      const nameNorm = emp.name.trim().toLowerCase();
                      const desigNorm = emp.designation?.trim().toLowerCase() || '';
                      
                      return empIdNorm === searchNorm || 
                             nameNorm === searchNorm ||
                             desigNorm === searchNorm;
                    });
                    if (found) {
                      openEmployeeProfile(found.id);
                      setGlobalSearchTerm(''); // Clear after opening
                    }
                  }
                }}
                className="w-64 pl-10 pr-4 py-2 bg-slate-50 dark:bg-slate-900 dark:text-white border border-slate-100 dark:border-slate-800 rounded-xl text-xs font-bold focus:ring-2 focus:ring-indigo-500/20 transition-all font-sans"
              />
            </div>
            
            <div className="flex items-center gap-2">
              <button 
                onClick={() => recalculate()}
                disabled={isInitializing}
                className={cn(
                  "p-2.5 text-slate-500 dark:text-slate-400 hover:text-indigo-600 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-100 dark:border-slate-800 rounded-xl transition-all flex items-center justify-center",
                  isInitializing && "animate-spin opacity-50"
                )}
                title="Force Sync Data"
              >
                <RefreshCw size={18} />
              </button>
              <button 
                onClick={() => setTheme(theme === 'light' ? 'dark' : 'light')}
                className="p-2.5 text-slate-500 dark:text-slate-400 hover:text-indigo-600 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-100 dark:border-slate-800 rounded-xl transition-all flex items-center justify-center"
                title={`Switch to ${theme === 'light' ? 'dark' : 'light'} mode`}
              >
                {theme === 'light' ? <Moon size={18} /> : <Sun size={18} />}
              </button>
              <button className="p-2.5 text-slate-500 dark:text-slate-400 hover:text-indigo-600 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-100 dark:border-slate-800 rounded-xl transition-all relative">
                <Bell size={18} />
                <span className="absolute top-2 right-2 w-2 h-2 bg-rose-500 border-2 border-white dark:border-slate-950 rounded-full"></span>
              </button>
              <div className="h-8 w-[1px] bg-slate-200 dark:bg-slate-700 mx-2"></div>
              <div className="flex items-center gap-3 pl-2">
                <div className="text-right hidden sm:block">
                  <p className="text-xs font-semibold text-slate-900 dark:text-white leading-none">Contractor HRIS</p>
                  <p className="text-xs font-bold text-slate-400 uppercase tracking-normal mt-1">v2.4.0 Live</p>
                </div>
                <div className="w-10 h-10 rounded-xl bg-slate-900 dark:bg-indigo-600 text-white flex items-center justify-center shadow-lg shadow-slate-200 dark:shadow-none">
                  <UserIcon size={20} />
                </div>
              </div>
            </div>
          </div>
        </header>
        
        {/* Page Content */}
        <div className="flex-1 overflow-y-auto overflow-x-hidden custom-scrollbar-light p-6 md:p-10">
          <div className="max-w-7xl mx-auto space-y-8 pb-12">
            <AnimatePresence mode="wait">
              <motion.div
                key={location.pathname}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.2 }}
              >
                <Outlet />
              </motion.div>
            </AnimatePresence>
          </div>
        </div>
      </main>

      {/* Mobile Sidebar Overlay */}
      <AnimatePresence>
        {isMobileOpen && (
          <div className="fixed inset-0 z-[100] md:hidden">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsMobileOpen(false)}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              className="absolute top-0 left-0 bottom-0 w-72 bg-slate-900 shadow-md p-6 overflow-y-auto"
            >
              <div className="flex items-center justify-between mb-10">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-indigo-500 rounded-lg flex items-center justify-center font-bold text-white uppercase">
                    {settings.companyName.charAt(0)}
                  </div>
                  <h1 className="text-white font-semibold">{settings.companyName}</h1>
                </div>
                <button onClick={() => setIsMobileOpen(false)} className="text-white/60">
                   <ChevronLeft size={24} />
                </button>
              </div>
              
              <nav className="space-y-2">
                {navItems.map((item) => (
                  <NavLink
                    key={item.to}
                    to={item.to}
                    onClick={() => setIsMobileOpen(false)}
                    className={({ isActive }) =>
                      cn(
                        'flex items-center gap-4 p-4 rounded-lg text-sm font-bold transition-all',
                        isActive ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-900/20' : 'text-white/40 hover:bg-white/5'
                      )
                    }
                  >
                    <item.icon size={20} />
                    {item.label}
                  </NavLink>
                ))}
              </nav>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <EmployeeDrawer 
        employee={selectedEmployee}
        isOpen={!!selectedEmployeeId}
        onClose={closeEmployeeProfile}
      />
    </div>
  );
}
