import React, { useMemo, useState, useEffect } from 'react';
import { useAppStore } from '../store';
import { Shield, Users, Fingerprint, Clock, AlertCircle, Database, Server, UserPlus, Mail, Lock, User, Key, Loader2, RefreshCw } from 'lucide-react';
import { format } from 'date-fns';
import { toast } from 'sonner';
import { auth } from '../lib/firebase';

export function AdminDashboard() {
  const { employees, punches, settings, shiftAssignments, assignmentLogs } = useAppStore();
  const [adminUsers, setAdminUsers] = useState<any[]>([]);
  const [isFetchingUsers, setIsFetchingUsers] = useState(false);
  const [isCreatingUser, setIsCreatingUser] = useState(false);
  const [newUser, setNewUser] = useState({ email: '', password: '', displayName: '', role: 'Editor' });

  const fetchUsers = async () => {
    setIsFetchingUsers(true);
    try {
      const token = await auth.currentUser?.getIdToken();
      const response = await fetch('/api/admin/users', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (response.ok) {
        const data = await response.json();
        setAdminUsers(data);
      }
    } catch (error) {
      console.error('Failed to fetch users:', error);
    } finally {
      setIsFetchingUsers(false);
    }
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  const handleCreateUser = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsCreatingUser(true);
    try {
      const token = await auth.currentUser?.getIdToken();
      const response = await fetch('/api/admin/create-user', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(newUser),
      });
      if (response.ok) {
        toast.success('User created successfully');
        setNewUser({ email: '', password: '', displayName: '', role: 'Editor' });
        fetchUsers();
      } else {
        const data = await response.json();
        throw new Error(data.error);
      }
    } catch (error: any) {
      toast.error(error.message || 'Failed to create user');
    } finally {
      setIsCreatingUser(false);
    }
  };

  const stats = useMemo(() => {
    const totalPunches = punches.length;
    const totalEmployees = employees.length;
    const totalAssignments = shiftAssignments.length;
    const totalLogs = assignmentLogs.length;
    
    // Calculate storage usage estimate (rough)
    const rawDataSize = JSON.stringify({ employees, punches, settings, shiftAssignments, assignmentLogs }).length;
    const sizeKB = (rawDataSize / 1024).toFixed(2);
    
    return {
      totalPunches,
      totalEmployees,
      totalAssignments,
      totalLogs,
      sizeKB
    };
  }, [employees, punches, settings, shiftAssignments, assignmentLogs]);

  const recentAdminLogs = useMemo(() => {
    return [...assignmentLogs].sort((a, b) => b.timestamp.localeCompare(a.timestamp)).slice(0, 10);
  }, [assignmentLogs]);

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-900 tracking-tight">Admin Control Panel</h2>
          <p className="text-slate-500 text-sm">System-wide monitoring and administrative tools.</p>
        </div>
        <div className="px-4 py-2 bg-indigo-50 border border-indigo-100 rounded-lg flex items-center gap-2">
          <Shield className="w-4 h-4 text-indigo-600" />
          <span className="text-xs font-bold text-indigo-600 uppercase tracking-wider">Owner & Editor Mode</span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard 
          icon={Users} 
          label="Total Employees" 
          value={stats.totalEmployees} 
          color="blue" 
          subValue="Registered profiles"
        />
        <StatCard 
          icon={Fingerprint} 
          label="Punch Records" 
          value={stats.totalPunches} 
          color="indigo" 
          subValue="Biometric logs"
        />
        <StatCard 
          icon={Clock} 
          label="Shift Maps" 
          value={stats.totalAssignments} 
          color="amber" 
          subValue="Active assignments"
        />
        <StatCard 
          icon={Database} 
          label="Local Cache" 
          value={`${stats.sizeKB} KB`} 
          color="emerald" 
          subValue="Est. JSON Payload"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          {/* User Management Section */}
          <div className="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden">
            <div className="p-4 border-b border-slate-100 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Users className="w-4 h-4 text-slate-400" />
                <h3 className="font-bold text-slate-800">User Management</h3>
              </div>
              <button 
                onClick={fetchUsers}
                className="p-1.5 hover:bg-slate-50 rounded-lg transition-colors text-slate-400"
                title="Refresh User List"
              >
                <RefreshCw className={`w-4 h-4 ${isFetchingUsers ? 'animate-spin' : ''}`} />
              </button>
            </div>
            
            <div className="p-6 border-b border-slate-100 bg-slate-50/50">
              <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-normal mb-4">Add New Authorized User</h4>
              <form onSubmit={handleCreateUser} className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="relative">
                  <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <input 
                    type="text"
                    value={newUser.displayName}
                    onChange={(e) => setNewUser({...newUser, displayName: e.target.value})}
                    placeholder="Full Name"
                    className="w-full pl-9 pr-3 py-2.5 text-xs font-bold border border-slate-200 rounded-xl bg-white outline-none focus:ring-2 focus:ring-indigo-500"
                    required
                  />
                </div>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <input 
                    type="email"
                    value={newUser.email}
                    onChange={(e) => setNewUser({...newUser, email: e.target.value})}
                    placeholder="Email"
                    className="w-full pl-9 pr-3 py-2.5 text-xs font-bold border border-slate-200 rounded-xl bg-white outline-none focus:ring-2 focus:ring-indigo-500"
                    required
                  />
                </div>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <input 
                    type="password"
                    value={newUser.password}
                    onChange={(e) => setNewUser({...newUser, password: e.target.value})}
                    placeholder="Password"
                    className="w-full pl-9 pr-3 py-2.5 text-xs font-bold border border-slate-200 rounded-xl bg-white outline-none focus:ring-2 focus:ring-indigo-500"
                    required
                  />
                </div>
                <div className="flex gap-2">
                  <select 
                    value={newUser.role}
                    onChange={(e) => setNewUser({...newUser, role: e.target.value})}
                    className="flex-1 px-3 py-2.5 text-xs font-bold border border-slate-200 rounded-xl bg-white outline-none focus:ring-2 focus:ring-indigo-500"
                  >
                    <option value="Editor">Editor</option>
                    <option value="Admin">Admin</option>
                  </select>
                  <button 
                    type="submit"
                    disabled={isCreatingUser}
                    className="p-2.5 bg-slate-900 text-white rounded-xl hover:bg-slate-800 disabled:opacity-50 transition-all shadow-sm"
                  >
                    {isCreatingUser ? <Loader2 className="w-4 h-4 animate-spin" /> : <UserPlus className="w-4 h-4" />}
                  </button>
                </div>
              </form>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead className="bg-slate-50 border-b border-slate-100">
                  <tr>
                    <th className="px-6 py-3 text-xs font-semibold text-slate-400 uppercase tracking-normal">Name</th>
                    <th className="px-6 py-3 text-xs font-semibold text-slate-400 uppercase tracking-normal">Email</th>
                    <th className="px-6 py-3 text-xs font-semibold text-slate-400 uppercase tracking-normal text-center">Role</th>
                    <th className="px-6 py-3 text-xs font-semibold text-slate-400 uppercase tracking-normal text-right">Added On</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-50">
                  {isFetchingUsers ? (
                    <tr>
                      <td colSpan={4} className="px-6 py-12 text-center">
                        <Loader2 className="w-6 h-6 animate-spin text-slate-300 mx-auto" />
                      </td>
                    </tr>
                  ) : adminUsers.length > 0 ? (
                    adminUsers.map((user: any) => (
                      <tr key={user.id} className="hover:bg-slate-50/50 transition-colors">
                        <td className="px-6 py-4">
                          <div className="flex items-center gap-3">
                            <div className="w-8 h-8 bg-indigo-50 text-indigo-600 rounded-lg flex items-center justify-center font-bold text-xs">
                              {user.username?.[0] || 'U'}
                            </div>
                            <span className="text-sm font-bold text-slate-700">{user.username}</span>
                          </div>
                        </td>
                        <td className="px-6 py-4 text-xs font-medium text-slate-500">{user.email}</td>
                        <td className="px-6 py-4 text-center">
                          <span className={`px-2.5 py-1 rounded-full text-xs font-semibold uppercase tracking-wider ${
                            user.role === 'Admin' ? 'bg-indigo-100 text-indigo-600' : 'bg-emerald-100 text-emerald-600'
                          }`}>
                            {user.role}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-right text-xs font-mono text-slate-400">
                          {user.createdAt ? format(new Date(user.createdAt._seconds * 1000), 'MMM dd, yyyy') : 'N/A'}
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan={4} className="px-6 py-12 text-center text-slate-400 text-sm italic">
                        No registered users found.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>

          <div className="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden">
            <div className="p-4 border-b border-slate-100 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Server className="w-4 h-4 text-slate-400" />
                <h3 className="font-bold text-slate-800">Recent Admin Activity</h3>
              </div>
              <span className="text-xs font-bold text-slate-400 uppercase tracking-normal">Last 10 Logs</span>
            </div>
            <div className="divide-y divide-slate-50">
              {recentAdminLogs.length > 0 ? (
                recentAdminLogs.map((log) => (
                  <div key={log.id} className="p-4 flex items-center justify-between hover:bg-slate-50 transition-colors">
                    <div className="flex items-center gap-3">
                      <div className={`p-2 rounded-full ${log.action === 'assign' ? 'bg-indigo-50 text-indigo-600' : 'bg-red-50 text-red-600'}`}>
                        <Clock className="w-4 h-4" />
                      </div>
                      <div>
                        <p className="text-sm font-medium text-slate-900">
                          {log.action === 'assign' ? 'Assigned' : 'Unassigned'} {log.shiftName}
                        </p>
                        <p className="text-xs text-slate-500">
                          Employee: {log.employeeId} • Date: {log.date}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-xs font-mono text-slate-400">
                        {format(new Date(log.timestamp), 'HH:mm:ss')}
                      </p>
                      <p className="text-xs text-slate-400">
                        {format(new Date(log.timestamp), 'MMM dd, yyyy')}
                      </p>
                    </div>
                  </div>
                ))
              ) : (
                <div className="p-12 text-center text-slate-400">
                  <p className="text-sm">No administrative logs found.</p>
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <div className="bg-white border border-slate-200 rounded-xl shadow-sm p-6">
            <h3 className="font-bold text-slate-800 mb-4 flex items-center gap-2">
              <Shield className="w-4 h-4 text-indigo-500" />
              Security Information
            </h3>
            <div className="space-y-4">
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-100">
                <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">Access Level</p>
                <p className="text-sm font-bold text-slate-900">Owner & System Editor</p>
              </div>
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-100">
                <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">Environment</p>
                <p className="text-sm font-bold text-slate-900">Production (Live)</p>
              </div>
              <div className="p-4 bg-amber-50 border border-amber-100 rounded-lg">
                <div className="flex gap-3">
                  <AlertCircle className="w-5 h-5 text-amber-500 shrink-0" />
                  <div>
                    <p className="text-xs font-bold text-amber-900">Administrative Note</p>
                    <p className="text-xs text-amber-700 mt-0.5 leading-relaxed">
                      You are in Super Admin mode. All data deletions or system purges are permanent and cannot be reversed from this interface.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function StatCard({ icon: Icon, label, value, color, subValue }: any) {
  const colors: any = {
    blue: 'bg-blue-50 text-blue-600 border-blue-100',
    indigo: 'bg-indigo-50 text-indigo-600 border-indigo-100',
    amber: 'bg-amber-50 text-amber-600 border-amber-100',
    emerald: 'bg-emerald-50 text-emerald-600 border-emerald-100',
  };

  return (
    <div className="bg-white p-5 border border-slate-200 rounded-xl shadow-sm">
      <div className="flex items-center justify-between mb-3">
        <div className={`p-2 rounded-lg border ${colors[color]}`}>
          <Icon className="w-5 h-5" />
        </div>
        <span className="text-xs font-bold text-slate-400 uppercase tracking-normal">{label}</span>
      </div>
      <div className="space-y-0.5">
        <h4 className="text-2xl font-bold text-slate-900">{value}</h4>
        <p className="text-xs text-slate-500 font-medium">{subValue}</p>
      </div>
    </div>
  );
}
