import React, { useState, useMemo, useEffect, useDeferredValue } from 'react';
import { useSearchParams } from 'react-router-dom';
import { useAppStore } from '../store';
import { format, parseISO, startOfMonth, endOfMonth, eachDayOfInterval, isSameMonth, isToday, startOfWeek, endOfWeek, addMonths, subMonths, isSameDay, subDays, startOfYesterday, endOfYesterday, subWeeks } from 'date-fns';
import { Calendar as CalendarIcon, Search, Filter, LayoutList, CalendarDays, ChevronLeft, ChevronRight, UserPlus, RefreshCw, X, Archive, Download, MoreVertical, Clock, Printer, ChevronDown, Wand2, FileText, History, Calculator, Trash2, AlertCircle, Info } from 'lucide-react';
import { cn, formatAMPM, formatDuration, formatMinutes, normalizeEmployeeId } from '../lib/utils';
import { getNepaliDate } from '../utils/dateHelper';
import { toast } from 'sonner';
import { processPunches } from '../lib/engine';
import * as XLSX from 'xlsx';
import { MultiSelect } from '../components/MultiSelect';
import { AttendanceHeatmap } from '../components/AttendanceHeatmap';
import { PunchTimeline } from '../components/PunchTimeline';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';

export function Attendance() {
  const { 
    processedData, 
    employees, 
    settings, 
    shiftAssignments, 
    setShiftAssignments, 
    punches, 
    deletePunchesBatch, 
    fetchPunches, 
    recalculate,
    calculationSource, 
    setCalculationSource, 
    assignmentLogs, 
    addAssignmentLog, 
    isInitializing, 
    quotaExceeded,
    globalSearchTerm,
    openEmployeeProfile
  } = useAppStore();
  
  const [searchTerm, setSearchTerm] = useState('');
  const activeSearch = searchTerm || globalSearchTerm;
  const deferredSearchTerm = useDeferredValue(activeSearch);
  const [startDate, setStartDate] = useState<string>(() => {
    // Default to start of previous month to ensure imported data is visible
    const date = subMonths(new Date(), 1);
    return format(startOfMonth(date), 'yyyy-MM-dd');
  });
  const [endDate, setEndDate] = useState<string>(format(new Date(), 'yyyy-MM-dd'));
  const [statusFilter, setStatusFilter] = useState<string[]>(['All']);
  const [deptFilter, setDeptFilter] = useState<string[]>(['All']);
  const [shiftFilter, setShiftFilter] = useState<string[]>(['All']);
  const [designationFilter, setDesignationFilter] = useState<string[]>(['All']);
  const [contractorFilter, setContractorFilter] = useState<string[]>(['All']);

  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState<number | 'All'>(50);
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [showDatePresets, setShowDatePresets] = useState(false);
  const [recentSearches, setRecentSearches] = useState<string[]>(() => {
    return JSON.parse(localStorage.getItem('attend_recent_searches') || '[]');
  });

  // Update recent searches
  useEffect(() => {
    if (searchTerm && searchTerm.length > 2) {
      const timer = setTimeout(() => {
        setRecentSearches(prev => {
          const filtered = prev.filter(s => s.toLowerCase() !== searchTerm.toLowerCase());
          const next = [searchTerm, ...filtered].slice(0, 5);
          localStorage.setItem('attend_recent_searches', JSON.stringify(next));
          return next;
        });
      }, 1000);
      return () => clearTimeout(timer);
    }
  }, [searchTerm]);

  const [assignmentModal, setAssignmentModal] = useState<{
    isOpen: boolean;
    employeeId: string;
    date: string;
  }>({ isOpen: false, employeeId: '', date: '' });

  const [logModal, setLogModal] = useState<{
    isOpen: boolean;
    record: any;
    employeeName: string;
  }>({ isOpen: false, record: null, employeeName: '' });

  const [activeMenu, setActiveMenu] = useState<string | null>(null);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [isSearchFocused, setIsSearchFocused] = useState(false);
  const [expandedRows, setExpandedRows] = useState<string[]>([]);

  const [searchParams] = useSearchParams();

  useEffect(() => {
    const dept = searchParams.get('dept');
    const status = searchParams.get('status');
    const date = searchParams.get('date');

    if (dept) setDeptFilter([dept]);
    if (status) setStatusFilter([status === 'Active' ? 'All' : status]); // Adjust for "Active" which isn't a status
    if (date) {
      setStartDate(date);
      setEndDate(date);
    }
  }, [searchParams]);

  const toggleRowExpansion = (id: string) => {
    setExpandedRows(prev => prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]);
  };

  const handleRefresh = async () => {
    setIsRefreshing(true);
    await recalculate();
    setIsRefreshing(false);
  };

  const departments = useMemo(() => {
    const depts = employees.map(e => e.department).filter(Boolean) as string[];
    return ['All', ...new Set(depts)];
  }, [employees]);

  const shiftOptions = useMemo(() => {
    const shifts = settings.shifts?.map(s => s.name) || [];
    return ['All', ...new Set(shifts)];
  }, [settings.shifts]);

  const designations = useMemo(() => {
    const des = employees.map(e => e.designation).filter(Boolean) as string[];
    return ['All', ...new Set(des)];
  }, [employees]);

  const contractors = useMemo(() => {
    const cons = employees.map(e => e.contractorName).filter(Boolean) as string[];
    return ['All', ...new Set(cons)];
  }, [employees]);

  const [selectedEmployees, setSelectedEmployees] = useState<string[]>([]);
  const [bulkModal, setBulkModal] = useState({ 
    isOpen: false, 
    step: 1 as 1 | 2,
    shiftId: '', 
    startDate: format(new Date(), 'yyyy-MM-dd'), 
    endDate: format(new Date(), 'yyyy-MM-dd') 
  });

  const handleBulkAssign = async () => {
    if (quotaExceeded) return;
    if (selectedEmployees.length === 0) return;
    
    const tId = toast.loading(`Assigning shift to ${selectedEmployees.length} employees...`);
    try {
      let nextAssignments = [...shiftAssignments];
      const start = parseISO(bulkModal.startDate);
      const end = parseISO(bulkModal.endDate);
      const dateRange = eachDayOfInterval({ start, end });

      selectedEmployees.forEach(empId => {
        dateRange.forEach(day => {
          const dStr = format(day, 'yyyy-MM-dd');
          const existingIndex = nextAssignments.findIndex(s => s.employeeId === empId && s.date === dStr);
          
          if (bulkModal.shiftId) {
            if (existingIndex > -1) {
              nextAssignments[existingIndex] = { ...nextAssignments[existingIndex], shiftId: bulkModal.shiftId };
            } else {
              nextAssignments.push({ employeeId: empId, date: dStr, shiftId: bulkModal.shiftId });
            }
          } else if (existingIndex > -1) {
            nextAssignments.splice(existingIndex, 1);
          }
        });
      });

      await setShiftAssignments(nextAssignments);
      
      // Log for first 5 employees to avoid flooding Firestore if many selected
      // Actually log the action generally if possible or first few
      for (const id of selectedEmployees.slice(0, 5)) {
         await addAssignmentLog(id, `${bulkModal.startDate} to ${bulkModal.endDate}`, bulkModal.shiftId, bulkModal.shiftId ? 'Assigned' : 'Removed');
      }

      toast.success('Bulk assignment completed successfully', { id: tId });
      setBulkModal({ ...bulkModal, isOpen: false, step: 1 });
      setSelectedEmployees([]);
    } catch (e) {
      toast.error('Failed to complete bulk assignment', { id: tId });
    }
  };

  const toggleEmployeeSelection = (id: string) => {
    setSelectedEmployees(prev => prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id]);
  };

  const handleDeleteSelectedRecords = async () => {
    if (quotaExceeded) return;
    if (selectedEmployees.length === 0) return;
    
    if (!confirm(`Are you sure you want to delete ALL attendance records for the ${selectedEmployees.length} selected employees between ${startDate} and ${endDate}? This will permanently remove their biometric logs for this period.`)) {
      return;
    }

    const tId = toast.loading('Deleting records...');
    try {
      const punchesToDelete = punches.filter(p => {
        const pDate = p.punchDatetime.split(/[ T]/)[0];
        return selectedEmployees.includes(p.employeeId) && pDate >= startDate && pDate <= endDate;
      });

      if (punchesToDelete.length === 0) {
        toast.info('No punch records found for the selection in this period.', { id: tId });
        return;
      }

      await deletePunchesBatch(punchesToDelete.map(p => p.id));
      toast.success(`Successfully deleted ${punchesToDelete.length} records.`, { id: tId });
      setSelectedEmployees([]);
    } catch (e) {
      toast.error('Failed to delete records', { id: tId });
    }
  };

  const handleExportExcel = () => {
    if (filteredData.length === 0) return;

    const exportData = filteredData.map(d => {
      const emp = employees.find(e => e.id === d.employeeId);
      const assignment = shiftAssignments.find(a => a.employeeId === d.employeeId && a.date === d.date);
      const shift = settings.shifts?.find(s => s.id === (assignment?.shiftId || emp?.shiftId));
      
      return {
        'Date': d.date,
        'Employee ID': d.employeeId,
        'Employee Name': emp?.name || '-',
        'Department': emp?.department || '-',
        'Designation': emp?.designation || '-',
        'Shift': shift?.name || (d.shiftId === 'DS' ? 'DS' : 'No Shift'),
        'First Punch': formatAMPM(d.firstPunch),
        'Last Punch': (d.lastPunch && d.lastPunch !== d.firstPunch) ? formatAMPM(d.lastPunch) : '-',
        'Work Duration': formatDuration(d.workingHours),
        'Overtime': d.overtime > 0 ? formatDuration(d.overtime) : '--',
        'Status': d.status,
        'Actual Bio Logs': (d.rawLogs || d.logs).map(l => formatAMPM(l)).join(', '),
        'Calculated Logs': d.logs.map(l => formatAMPM(l)).join(', ')
      };
    });

    const worksheet = XLSX.utils.json_to_sheet(exportData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Attendance');
    XLSX.writeFile(workbook, `Filtered_Attendance_${startDate}_to_${endDate}.xlsx`);
  };

  const setPresetDate = (type: 'this-week' | 'last-week' | 'this-month' | 'last-month') => {
    const today = new Date();
    let start = today;
    let end = today;

    switch (type) {
      case 'this-week':
        start = startOfWeek(today, { weekStartsOn: 1 });
        end = today;
        break;
      case 'last-week':
        start = startOfWeek(subDays(today, 7), { weekStartsOn: 1 });
        end = endOfWeek(subDays(today, 7), { weekStartsOn: 1 });
        break;
      case 'this-month':
        start = startOfMonth(today);
        end = today;
        break;
      case 'last-month':
        start = startOfMonth(subMonths(today, 1));
        end = endOfMonth(subMonths(today, 1));
        break;
    }

    setStartDate(format(start, 'yyyy-MM-dd'));
    setEndDate(format(end, 'yyyy-MM-dd'));
    setShowDatePresets(false);
  };

  const handlePrint = () => {
    window.print();
  };

  const handleExportPDF = () => {
    if (filteredData.length === 0) return;

    const doc = new jsPDF('landscape');
    
    // Sort data: Date ascending
    const sortedData = [...filteredData].sort((a, b) => a.date.localeCompare(b.date));

    // Header
    doc.setFontSize(16);
    doc.setTextColor(15, 23, 42);
    doc.text('Attendance Summary Report', 14, 15);
    
    doc.setFontSize(8);
    doc.setTextColor(100, 116, 139);
    doc.text(`Period: ${startDate} to ${endDate} | Generated: ${format(new Date(), 'dd/MM/yyyy h:mm a')}`, 14, 21);

    const tableHeaders = [
      ['#', 'Date (A.D.)', 'Date (B.S.)', 'Emp ID', 'Name', 'Shift', 'In', 'Out', 'Late', 'Early', 'Dur', 'OT', 'Status']
    ];

    const tableData = sortedData.map((d, index) => {
      const emp = employees.find(e => e.id === d.employeeId);
      const shift = settings.shifts?.find(s => s.id === (shiftAssignments.find(a => a.employeeId === d.employeeId && a.date === d.date)?.shiftId || emp?.shiftId));
      
      return [
        index + 1,
        format(parseISO(d.date), 'dd/MM/yyyy'),
        getNepaliDate(d.date),
        d.employeeId,
        emp?.name || '-',
        shift?.name || (d.shiftId === 'DS' ? 'DS' : '-'),
        formatAMPM(d.firstPunch),
        (d.lastPunch && d.lastPunch !== d.firstPunch) ? formatAMPM(d.lastPunch) : '-',
        formatMinutes(d.lateMinutes),
        formatMinutes(d.earlyMinutes),
        formatDuration(d.workingHours),
        d.overtime > 0 ? formatDuration(d.overtime) : '-',
        d.status
      ];
    });

    autoTable(doc, {
      head: tableHeaders,
      body: tableData,
      startY: 25,
      theme: 'grid',
      styles: { 
        fontSize: 5.5, 
        cellPadding: 0.8, 
        font: 'helvetica',
        lineColor: [200, 200, 200],
        lineWidth: 0.05,
        overflow: 'hidden'
      },
      headStyles: { 
        fillColor: [30, 41, 59], 
        textColor: [255, 255, 255], 
        fontSize: 6, 
        fontStyle: 'bold', 
        halign: 'center' 
      },
      columnStyles: {
        0: { cellWidth: 7 },
        1: { cellWidth: 15 }, // Date A.D.
        2: { cellWidth: 18 }, // Date B.S.
        3: { cellWidth: 12 }, // Emp ID
        4: { cellWidth: 35 }, // Name
        5: { cellWidth: 15 }, // Shift
        6: { halign: 'center', cellWidth: 18 }, // In
        7: { halign: 'center', cellWidth: 18 }, // Out
        8: { halign: 'center', cellWidth: 12 }, // Late
        9: { halign: 'center', cellWidth: 12 }, // Early
        10: { halign: 'center', cellWidth: 12 }, // Dur
        11: { halign: 'center', cellWidth: 12 }, // OT
        12: { halign: 'center' } // Status
      },
      margin: { left: 10, right: 10 },
      didParseCell: (data) => {
        if (data.section === 'body' && data.column.index === 12) {
          const status = data.cell.raw;
          if (status === 'Absent' || status === 'SPF') {
            data.cell.styles.textColor = [185, 28, 28];
          }
          if (status === 'Present') {
            data.cell.styles.textColor = [21, 128, 61];
          }
          if (status === 'Weekly Off') {
            data.cell.styles.textColor = [67, 56,  202];
          }
          if (status === 'PWO') {
            data.cell.styles.textColor = [79, 70, 229];
            data.cell.styles.fontStyle = 'bold';
          }
        }
      },
      didDrawPage: (data) => {
        doc.setFontSize(7);
        doc.setTextColor(148, 163, 184);
        doc.text(
          `Page ${data.pageNumber}`,
          doc.internal.pageSize.width - 20,
          doc.internal.pageSize.height - 7
        );
      }
    });

    doc.save(`Attendance_Report_${startDate}_to_${endDate}.pdf`);
  };

  const smartDetectShift = (empId: string) => {
    // 1. Check history in processed data first
    const empHistory = processedData.filter(d => d.employeeId === empId && d.status !== 'Absent' && d.status !== 'Weekly Off');
    
    // 2. Also look at punch logs from last 7 days specifically to detect times
    const sevenDaysAgo = subWeeks(new Date(), 1);
    const recentPunches = punches.filter(p => p.employeeId === empId && parseISO(p.punchDatetime) > sevenDaysAgo);
    
    if (empHistory.length === 0 && recentPunches.length === 0) {
      const emp = employees.find(e => e.id === empId);
      return emp?.shiftId || '';
    }

    // Smart logic: detect average start time from logs if history is thin
    if (recentPunches.length > 0) {
      const punchTimes = recentPunches.map(p => {
        const d = parseISO(p.punchDatetime);
        return d.getHours() * 60 + d.getMinutes();
      });
      const avgStartMinutes = punchTimes.reduce((a, b) => a + b, 0) / punchTimes.length;
      
      // Find shift closest to this average start time
      const bestShift = settings.shifts.reduce((prev, curr) => {
        const [h, m] = curr.startTime.split(':').map(Number);
        const currStartMins = h * 60 + m;
        const prevStartMins = prev ? (prev.startTime.split(':').map(Number)[0] * 60 + prev.startTime.split(':').map(Number)[1]) : -1000;
        
        return Math.abs(currStartMins - avgStartMinutes) < Math.abs(prevStartMins - avgStartMinutes) ? curr : prev;
      });
      if (bestShift) return bestShift.id;
    }

    // Fallback to most frequent shift in records
    const shiftCounts: Record<string, number> = {};
    empHistory.forEach(record => {
      const assignment = shiftAssignments.find(a => a.employeeId === empId && a.date === record.date);
      const shiftId = assignment?.shiftId || employees.find(e => e.id === empId)?.shiftId || '';
      if (shiftId) shiftCounts[shiftId] = (shiftCounts[shiftId] || 0) + 1;
    });

    const entries = Object.entries(shiftCounts);
    if (entries.length === 0) return '';
    return entries.sort((a, b) => b[1] - a[1])[0][0];
  };

  const suggestShift = smartDetectShift; // Alias for compatibility with previous UI bindings if any

  const handleAssignShift = (shiftId: string) => {
    const existingIndex = shiftAssignments.findIndex(
      s => s.employeeId === assignmentModal.employeeId && s.date === assignmentModal.date
    );

    let nextAssignments = [...shiftAssignments];
    const action = existingIndex > -1 ? (shiftId ? 'Updated' : 'Removed') : 'Assigned';

    if (existingIndex > -1) {
      if (shiftId) {
        nextAssignments[existingIndex] = { ...nextAssignments[existingIndex], shiftId };
      } else {
        nextAssignments.splice(existingIndex, 1);
      }
    } else if (shiftId) {
      nextAssignments.push({
        employeeId: assignmentModal.employeeId,
        date: assignmentModal.date,
        shiftId
      });
    }

    addAssignmentLog(assignmentModal.employeeId, assignmentModal.date, shiftId, action as any);
    setShiftAssignments(nextAssignments);
    setAssignmentModal({ ...assignmentModal, isOpen: false });
  };

  // Optimizing lookups for the filtering process
  const empMap = useMemo(() => new Map(employees.map(e => [e.id, e])), [employees]);
  const shiftMap = useMemo(() => new Map(settings.shifts?.map(s => [s.id, s]) || []), [settings.shifts]);
  const assignmentMap = useMemo(() => new Map(shiftAssignments.map(a => [`${a.employeeId}_${a.date}`, a.shiftId])), [shiftAssignments]);

  const filteredData = useMemo(() => {
    const searchLower = deferredSearchTerm.toLowerCase();
    const searchNumeric = normalizeEmployeeId(searchLower);
    
    return processedData.filter(d => {
      const emp = empMap.get(d.employeeId);
      
      let matchesSearch = searchLower === '';
      if (!matchesSearch) {
        const empIdLower = d.employeeId.toLowerCase();
        const empIdNorm = normalizeEmployeeId(d.employeeId);
        const empNameLower = emp?.name?.toLowerCase() || '';
        
        matchesSearch = empIdLower.includes(searchLower) || 
                        empNameLower.includes(searchLower) ||
                        (searchNumeric !== '' && empIdNorm.includes(searchNumeric));
      }
      const recordDate = d.date;
      const matchesDate = (!startDate || recordDate >= startDate) && (!endDate || recordDate <= endDate);
      
      if (!matchesSearch || !matchesDate) return false;

      const matchesStatus = statusFilter.includes('All') || 
                            statusFilter.some(s => s.toLowerCase() === d.status.toLowerCase()) || 
                            (statusFilter.some(s => s.toLowerCase() === 'late') && d.lateMinutes > 0);
      const matchesDept = deptFilter.includes('All') || (emp?.department && deptFilter.includes(emp.department));
      
      const shiftId = assignmentMap.get(`${d.employeeId}_${d.date}`) || emp?.shiftId;
      const shift = shiftId ? shiftMap.get(shiftId) : null;
      const matchesShift = shiftFilter.includes('All') || (shift && shiftFilter.includes(shift.name));
      const matchesDesignation = designationFilter.includes('All') || (emp?.designation && designationFilter.includes(emp.designation));
      const matchesContractor = contractorFilter.includes('All') || (emp?.contractorName && contractorFilter.includes(emp.contractorName));

      return matchesStatus && matchesDept && matchesShift && matchesDesignation && matchesContractor;
    }).sort((a, b) => a.date.localeCompare(b.date) || a.employeeId.localeCompare(b.employeeId));
  }, [processedData, empMap, shiftMap, assignmentMap, deferredSearchTerm, startDate, endDate, statusFilter, deptFilter, shiftFilter, designationFilter, contractorFilter]);

  const paginatedData = useMemo(() => {
    if (pageSize === 'All') return filteredData;
    const start = (currentPage - 1) * pageSize;
    return filteredData.slice(start, start + pageSize);
  }, [filteredData, currentPage, pageSize]);

  const totalPages = pageSize === 'All' ? 1 : Math.ceil(filteredData.length / pageSize);

  useEffect(() => {
    setCurrentPage(1);
  }, [deferredSearchTerm, startDate, endDate, statusFilter, deptFilter, shiftFilter, designationFilter, contractorFilter]);

  const calendarDays = useMemo(() => {
    const start = startOfWeek(startOfMonth(currentMonth));
    const end = endOfWeek(endOfMonth(currentMonth));
    return eachDayOfInterval({ start, end });
  }, [currentMonth]);

  const getAttendanceForDay = (day: Date, empId: string) => {
    const dStr = format(day, 'yyyy-MM-dd');
    return processedData.find(record => record.employeeId === empId && record.date === dStr);
  };

  const getShiftForDay = (day: Date, empId: string) => {
    const dStr = format(day, 'yyyy-MM-dd');
    const assignment = shiftAssignments.find(a => a.employeeId === empId && a.date === dStr);
    const emp = employees.find(e => e.id === empId);
    const shiftId = assignment?.shiftId || emp?.shiftId;
    return settings.shifts?.find(s => s.id === shiftId);
  };

  const summaryStats = useMemo(() => {
    const uniqueEmployees = new Set(filteredData.map(d => d.employeeId)).size;
    const totalPresent = filteredData.filter(d => ['Present', 'Late', 'SPF', 'On Time', 'Early', 'PWO'].includes(d.status)).length;
    const totalAbsent = filteredData.filter(d => d.status === 'Absent').length;
    const totalLate = filteredData.filter(d => d.lateMinutes > 0).length;
    const totalOT = filteredData.reduce((acc, d) => acc + (d.overtime || 0), 0);
    return { uniqueEmployees, totalPresent, totalAbsent, totalLate, totalOT };
  }, [filteredData]);

  const handleStatClick = (status: string) => {
    setStatusFilter([status]);
    setCurrentPage(1);
  };

  const uniqueEmployeesInFilter = useMemo(() => {
    return Array.from(new Set(filteredData.map(d => d.employeeId)));
  }, [filteredData]);

  if (isInitializing && processedData.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] gap-4">
        <div className="w-12 h-12 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin" />
        <div className="text-center">
          <h3 className="text-lg font-bold text-slate-700">Synchronizing Data</h3>
          <p className="text-sm text-slate-500">Loading attendance records and punches...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 pb-8">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 print:hidden">
        <div>
          <h2 className="text-2xl font-bold text-slate-900 tracking-tight">Attendance Tracking</h2>
          <p className="text-sm text-slate-500">Day-to-day shift assignment and verification</p>
        </div>
        
        <div className="flex flex-wrap items-center gap-3">
          <button 
            onClick={handleRefresh}
            disabled={isRefreshing}
            className={`flex items-center gap-2 px-4 py-2 bg-indigo-600 border ${isRefreshing ? 'opacity-50 ring-2 ring-indigo-100' : 'border-indigo-500'} text-white rounded-lg text-sm font-bold hover:bg-indigo-700 transition shadow-lg shadow-indigo-100`}
          >
            <Calculator className={`w-4 h-4 ${isRefreshing ? 'animate-spin' : ''}`} />
            {isRefreshing ? 'Calculating...' : 'Recalculate Attendance'}
          </button>

          {selectedEmployees.length > 0 && (
            <div className="flex items-center gap-2 animate-in fade-in slide-in-from-top-1">
              <button 
                onClick={() => {
                  if (quotaExceeded) return;
                  setBulkModal({ ...bulkModal, isOpen: true });
                }}
                disabled={quotaExceeded}
                className={`flex items-center gap-2 px-3 py-1.5 bg-indigo-600 text-white rounded-lg text-sm font-bold hover:bg-indigo-700 transition shadow-sm ${quotaExceeded ? 'opacity-50 cursor-not-allowed' : ''}`}
              >
                <UserPlus className="w-4 h-4" /> Bulk Assign ({selectedEmployees.length})
              </button>
              <button 
                onClick={handleDeleteSelectedRecords}
                disabled={quotaExceeded}
                className={`flex items-center gap-2 px-3 py-1.5 bg-red-50 text-red-600 border border-red-200 rounded-lg text-sm font-bold hover:bg-red-100 transition shadow-sm ${quotaExceeded ? 'opacity-50 cursor-not-allowed' : ''}`}
              >
                <Trash2 className="w-4 h-4" /> Delete Records ({selectedEmployees.length})
              </button>
            </div>
          )}

          {/* Remove ViewMode Toggles per user request */}
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input 
              type="text" 
              placeholder="Search Name or ID..." 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              onFocus={() => setIsSearchFocused(true)}
              onBlur={() => setTimeout(() => setIsSearchFocused(false), 200)} // Delay to allow click
              className="pl-9 pr-4 py-2 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 w-full sm:w-48 bg-white shadow-sm"
            />
            
            {recentSearches.length > 0 && !searchTerm && isSearchFocused && (
              <div className="absolute top-full left-0 mt-2 w-full bg-white border border-slate-200 rounded-xl shadow-sm z-30 p-2 animate-in fade-in slide-in-from-top-1">
                <div className="flex items-center gap-2 px-2 pb-2 border-b border-slate-50 mb-1">
                  <History className="w-3 h-3 text-slate-400" />
                  <span className="text-xs font-bold text-slate-400 uppercase tracking-normal">Recent Searches</span>
                </div>
                {recentSearches.map((s, i) => (
                  <button
                    key={i}
                    onClick={() => setSearchTerm(s)}
                    className="w-full text-left px-2 py-1.5 text-xs font-semibold text-slate-600 hover:bg-slate-50 hover:text-indigo-600 rounded-md transition-colors truncate"
                  >
                    {s}
                  </button>
                ))}
              </div>
            )}
          </div>

            <div className="flex flex-col gap-2 relative">
              <div className="flex items-center gap-2">
                <div className="relative">
                  <button 
                    onClick={() => setShowDatePresets(!showDatePresets)}
                    className="flex items-center gap-1 text-xs font-bold bg-slate-100 text-slate-500 px-2 py-1 rounded hover:bg-indigo-50 hover:text-indigo-600 transition uppercase tracking-wider"
                  >
                    Quick Date <ChevronDown className="w-3 h-3" />
                  </button>
                  {showDatePresets && (
                    <div className="absolute top-full left-0 mt-1 w-36 bg-white border border-slate-200 rounded-lg shadow-sm z-30 py-1 overflow-hidden animate-in fade-in slide-in-from-top-1">
                      {[
                        { label: 'This Week', value: 'this-week' },
                        { label: 'Last Week', value: 'last-week' },
                        { label: 'This Month', value: 'this-month' },
                        { label: 'Last Month', value: 'last-month' },
                      ].map((preset) => (
                        <button
                          key={preset.value}
                          onClick={() => setPresetDate(preset.value as any)}
                          className="w-full px-3 py-2 text-left text-xs font-bold text-slate-600 hover:bg-indigo-50 hover:text-indigo-600 transition-colors"
                        >
                          {preset.label}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
                <button 
                  onClick={() => {
                    setStartDate(format(startOfMonth(new Date()), 'yyyy-MM-dd'));
                    setEndDate(format(endOfMonth(new Date()), 'yyyy-MM-dd'));
                  }}
                  className="text-xs font-bold bg-slate-100 text-slate-500 px-2 py-1 rounded hover:bg-indigo-50 hover:text-indigo-600 transition uppercase tracking-wider"
                >
                  Current Month
                </button>
              </div>
              <div className="flex items-center gap-2 bg-white border border-slate-200 rounded-lg px-3 py-1.5 shadow-sm">
                <CalendarIcon className="w-4 h-4 text-slate-400" />
                <div className="flex items-center gap-1 text-sm">
                  <input 
                    type="date" 
                    value={startDate}
                    onChange={(e) => setStartDate(e.target.value)}
                    className="focus:outline-none text-slate-600 bg-transparent"
                  />
                  <span className="text-slate-300">to</span>
                  <input 
                    type="date" 
                    value={endDate}
                    onChange={(e) => setEndDate(e.target.value)}
                    className="focus:outline-none text-slate-600 bg-transparent"
                  />
                </div>
              </div>
            </div>
          </div>

          <div className="w-48">
            <MultiSelect 
              options={departments}
              selected={deptFilter}
              onChange={setDeptFilter}
              placeholder="All Departments"
              label="Department"
            />
          </div>

          <div className="w-48">
            <MultiSelect 
              options={shiftOptions}
              selected={shiftFilter}
              onChange={setShiftFilter}
              placeholder="All Shifts"
              label="Shift"
            />
          </div>

          <div className="w-48">
            <MultiSelect 
              options={designations}
              selected={designationFilter}
              onChange={setDesignationFilter}
              placeholder="All Designations"
              label="Designation"
            />
          </div>

          <div className="w-48">
            <MultiSelect 
              options={contractors}
              selected={contractorFilter}
              onChange={setContractorFilter}
              placeholder="All Contractors"
              label="Contractor"
            />
          </div>
          
          <div className="w-48">
            <MultiSelect 
              options={['All', 'Present', 'Absent', 'Late', 'PWO', 'Early', 'Weekly Off', 'SPF']}
              selected={statusFilter}
              onChange={setStatusFilter}
              placeholder="All Status"
              label="Status"
            />
          </div>

          <div className="flex gap-2">
            <button 
              onClick={handlePrint}
              className="flex items-center gap-2 px-3 py-1.5 bg-slate-800 text-white rounded-lg text-sm font-bold hover:bg-slate-900 transition shadow-sm"
            >
              <Printer className="w-4 h-4" /> Print
            </button>
            <button 
              onClick={handleExportExcel}
              className="flex items-center gap-2 px-3 py-1.5 bg-green-600 text-white rounded-lg text-sm font-bold hover:bg-green-700 transition shadow-sm"
            >
              <Download className="w-4 h-4" /> Export Excel
            </button>
            <button 
              onClick={handleExportPDF}
              className="flex items-center gap-2 px-3 py-1.5 bg-indigo-500 text-white rounded-lg text-sm font-bold hover:bg-indigo-600 transition shadow-sm"
            >
              <FileText className="w-4 h-4" /> Export PDF
            </button>
          </div>
        </div>

      <div className="hidden print:block mb-8">
        <h1 className="text-xl font-bold uppercase tracking-normal text-slate-900">Attendance Report</h1>
        <p className="text-sm text-slate-500">Period: {startDate} to {endDate}</p>
        <div className="mt-4 grid grid-cols-4 gap-4 border-y border-slate-200 py-4">
          <div>
            <p className="text-xs font-bold text-slate-400 uppercase">Total Present</p>
            <p className="font-bold text-slate-900">{summaryStats.totalPresent}</p>
          </div>
          <div>
            <p className="text-xs font-bold text-slate-400 uppercase">Total Absent</p>
            <p className="font-bold text-slate-900">{summaryStats.totalAbsent}</p>
          </div>
          <div>
            <p className="text-xs font-bold text-slate-400 uppercase">Total Late</p>
            <p className="font-bold text-slate-900">{summaryStats.totalLate}</p>
          </div>
          <div>
            <p className="text-xs font-bold text-slate-400 uppercase">Total Overtime</p>
            <p className="font-bold text-slate-900">{formatDuration(summaryStats.totalOT)}</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4 print:hidden">
          <div 
            onClick={() => { setStatusFilter(['All']); setCurrentPage(1); }}
            className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm flex items-center gap-4 cursor-pointer hover:ring-2 hover:ring-indigo-500/20 transition-all active:scale-95"
          >
            <div className="w-10 h-10 bg-indigo-50 dark:bg-indigo-900/20 rounded-full flex items-center justify-center">
              <UserPlus className="w-5 h-5 text-indigo-600" />
            </div>
            <div>
              <p className="text-xs font-bold text-slate-400 uppercase tracking-normal">Employees</p>
              <p className="text-xl font-bold text-slate-900 dark:text-white">{summaryStats.uniqueEmployees}</p>
            </div>
          </div>
          <div 
            onClick={() => handleStatClick('Present')}
            className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm flex items-center gap-4 cursor-pointer hover:ring-2 hover:ring-emerald-500/20 transition-all active:scale-95"
          >
            <div className="w-10 h-10 bg-green-50 dark:bg-green-900/20 rounded-full flex items-center justify-center">
              <RefreshCw className="w-5 h-5 text-green-600" />
            </div>
            <div>
              <p className="text-xs font-bold text-slate-400 uppercase tracking-normal">Present</p>
              <p className="text-xl font-bold text-green-600">{summaryStats.totalPresent}</p>
            </div>
          </div>
          <div 
            onClick={() => handleStatClick('Absent')}
            className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm flex items-center gap-4 cursor-pointer hover:ring-2 hover:ring-rose-500/20 transition-all active:scale-95"
          >
            <div className="w-10 h-10 bg-red-50 dark:bg-rose-900/20 rounded-full flex items-center justify-center">
              <X className="w-5 h-5 text-red-600" />
            </div>
            <div>
              <p className="text-xs font-bold text-slate-400 uppercase tracking-normal">Absent</p>
              <p className="text-xl font-bold text-red-600">{summaryStats.totalAbsent}</p>
            </div>
          </div>
          <div 
            onClick={() => handleStatClick('Late')}
            className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm flex items-center gap-4 cursor-pointer hover:ring-2 hover:ring-amber-500/20 transition-all active:scale-95"
          >
            <div className="w-10 h-10 bg-amber-50 dark:bg-amber-900/20 rounded-full flex items-center justify-center">
              <Clock className="w-5 h-5 text-amber-600" />
            </div>
            <div>
              <p className="text-xs font-bold text-slate-400 uppercase tracking-normal">Late</p>
              <p className="text-xl font-bold text-amber-600">{summaryStats.totalLate}</p>
            </div>
          </div>
          <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm flex items-center gap-4">
            <div className="w-10 h-10 bg-indigo-50 dark:bg-indigo-900/20 rounded-full flex items-center justify-center">
              <CalendarIcon className="w-5 h-5 text-indigo-600" />
            </div>
            <div>
              <p className="text-xs font-bold text-slate-400 uppercase tracking-normal">Overtime</p>
              <p className="text-xl font-bold text-indigo-600">{formatDuration(summaryStats.totalOT)}</p>
            </div>
          </div>
        </div>

      {/* Employee Pulse / Matrix Summary - Show when a specific user is selected via search or selected specifically */}
      {searchTerm && (employees.filter(e => 
        e.id.toLowerCase().includes(searchTerm.toLowerCase()) || 
        e.name.toLowerCase().includes(searchTerm.toLowerCase())
      ).length === 1 || employees.find(e => e.id === searchTerm || e.name === searchTerm)) && (() => {
        const matchingEmps = employees.filter(e => 
          e.id.toLowerCase().includes(searchTerm.toLowerCase()) || 
          e.name.toLowerCase().includes(searchTerm.toLowerCase())
        );
        const emp = matchingEmps.length === 1 ? matchingEmps[0] : employees.find(e => e.id === searchTerm || e.name === searchTerm);
        if (!emp) return null;
        
        return (
          <div className="bg-white p-6 rounded-lg border border-indigo-100 shadow-sm animate-in slide-in-from-bottom-2 duration-300 ring-4 ring-indigo-50/50">
             <div className="flex items-center justify-between mb-4 px-2">
                <div className="flex items-center gap-3">
                   <div className="w-12 h-12 bg-indigo-600 rounded-lg flex items-center justify-center text-white text-lg font-semibold shadow-lg shadow-indigo-100 overflow-hidden">
                      {emp.name.charAt(0)}
                   </div>
                   <div>
                      <h3 className="text-lg font-semibold text-slate-900 leading-none">{emp.name}</h3>
                      <p className="text-xs font-bold text-slate-400 uppercase tracking-normal mt-1">{emp.id} • {emp.department} • {emp.designation}</p>
                   </div>
                </div>
                <button 
                  onClick={() => setSearchTerm('')}
                  className="p-2 hover:bg-slate-100 rounded-full text-slate-400 transition-colors"
                  title="Close personal view"
                >
                  <X className="w-5 h-5" />
                </button>
             </div>
             <AttendanceHeatmap 
              employeeId={emp.id}
              month={currentMonth}
              data={processedData}
              onDayClick={(date) => setAssignmentModal({ isOpen: true, employeeId: emp.id, date })}
              onMonthChange={setCurrentMonth}
             />
          </div>
        );
      })()}

      <div id="attendance-report-table" className="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden print:border-none print:shadow-none">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse min-w-[1100px] print:min-w-0 print:table-auto">
              <thead className="bg-slate-50 border-b border-slate-200 print:bg-white">
                <tr className="text-xs font-bold text-slate-400 uppercase tracking-wider print:text-slate-900">
                  <th className="px-6 py-4 w-12 text-center print:hidden">
                    <input 
                      type="checkbox" 
                      onChange={(e) => {
                        if (e.target.checked) setSelectedEmployees(uniqueEmployeesInFilter);
                        else setSelectedEmployees([]);
                      }}
                      checked={selectedEmployees.length > 0 && selectedEmployees.length >= uniqueEmployeesInFilter.length}
                      className="w-4 h-4 rounded border-slate-300 text-indigo-600 cursor-pointer"
                    />
                  </th>
                  <th className="px-4 py-4 w-12 text-center">S.No</th>
                  <th className="px-6 py-4 w-[110px]">Date</th>
                  <th className="px-2 py-4 w-28 hidden print:table-cell">Date (B.S.)</th>
                  <th className="px-2 py-4 w-12">Day</th>
                  <th className="px-6 py-4 w-[100px]">Emp ID</th>
                  <th className="px-6 py-4 min-w-[180px]">Employee Name</th>
                  <th className="px-4 py-4 w-[120px]">Dept</th>
                  <th className="px-4 py-4 w-[120px] print:hidden">Contractor</th>
                  <th className="px-6 py-4 w-[140px] print:hidden">Shift</th>
                  <th className="px-2 py-4 w-12">WO</th>
                  <th className="px-6 py-4 w-[120px]">In Time</th>
                  <th className="px-6 py-4 w-[120px]">Out Time</th>
                  <th className="px-2 py-4 w-12 text-center">Logs</th>
                  <th className="px-4 py-4 w-[80px] text-right">Late</th>
                  <th className="px-4 py-4 w-[80px] text-right">Early</th>
                  <th className="px-6 py-4 w-[100px] text-right">Dur</th>
                  <th className="px-4 py-4 w-[70px] text-right">OT</th>
                  <th className="px-6 py-4 w-[120px]">Status</th>
                  <th className="px-6 py-4 w-[80px] text-center print:hidden">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-[13px] print:divide-slate-300">
                {paginatedData.length > 0 ? paginatedData.map((d, index) => {
                  const sNo = (currentPage - 1) * (pageSize === 'All' ? 0 : pageSize) + index + 1;
                  const emp = employees.find(e => e.id === d.employeeId);
                  const assignment = shiftAssignments.find(a => a.employeeId === d.employeeId && a.date === d.date);
                  const shift = settings.shifts?.find(s => s.id === (assignment?.shiftId || emp?.shiftId));
                  
                  const isExpanded = expandedRows.includes(d.id);
                  
                  return (
                    <React.Fragment key={d.id}>
                    <tr className={cn(
                      "hover:bg-slate-50/50 transition-colors group print:hover:bg-transparent",
                      selectedEmployees.includes(d.employeeId) && "bg-indigo-50/30",
                      isExpanded && "bg-slate-50 border-l-4 border-l-indigo-500",
                      (d.status === 'Weekly Off' || (emp?.weeklyOff && d.date && format(parseISO(d.date), 'EEEE') === emp.weeklyOff)) && "bg-indigo-50/10 dark:bg-indigo-900/10"
                    )}>
                      <td className="px-6 py-4 text-center print:hidden">
                        <div className="flex items-center gap-3">
                          <input 
                            type="checkbox" 
                            checked={selectedEmployees.includes(d.employeeId)}
                            onChange={() => toggleEmployeeSelection(d.employeeId)}
                            className="w-4 h-4 rounded border-slate-300 text-indigo-600 cursor-pointer"
                          />
                          <button 
                            onClick={() => toggleRowExpansion(d.id)}
                            className={`p-1 rounded transition-colors ${isExpanded ? 'bg-indigo-100 text-indigo-600' : 'text-slate-300 hover:text-slate-600 hover:bg-slate-100'}`}
                            title="Toggle Timeline"
                          >
                            <ChevronDown className={`w-4 h-4 transition-transform duration-200 ${isExpanded ? 'rotate-180' : ''}`} />
                          </button>
                        </div>
                      </td>
                      <td className="px-4 py-4 text-center text-slate-400 font-mono text-xs">{sNo}</td>
                      <td className="px-6 py-4 text-slate-500 font-medium whitespace-nowrap">{d.date}</td>
                      <td className="px-2 py-4 hidden print:table-cell">
                         <span className="text-xs font-bold text-slate-500">
                           {getNepaliDate(d.date)}
                         </span>
                      </td>
                      <td className="px-2 py-4">
                         <span className="text-xs font-semibold text-slate-400 uppercase tracking-tighter">
                           {format(parseISO(d.date), 'EEE')}
                         </span>
                      </td>
                      <td className="px-6 py-4 font-mono text-slate-500">{d.employeeId}</td>
                      <td className="px-6 py-4">
                        <div className="flex flex-col min-w-0">
                          <button 
                            onClick={() => openEmployeeProfile(d.employeeId)}
                            className="font-medium text-slate-900 dark:text-white block hover:text-indigo-600 transition-colors cursor-pointer truncate min-w-0"
                            title={emp?.name || d.employeeId}
                          >
                            {emp?.name || (d.employeeId.startsWith('1211') ? 'Bio Staff' : '-')}
                          </button>
                          <span className="text-xs text-slate-400 font-bold block truncate">{emp?.designation || '-'}</span>
                        </div>
                      </td>
                      <td className="px-4 py-4">
                        <span className="text-slate-600 dark:text-slate-400 font-medium truncate block max-w-[100px]" title={emp?.department}>{emp?.department || '-'}</span>
                      </td>
                      <td className="px-4 py-4 print:hidden">
                        <span className="text-slate-500 truncate block max-w-[100px]" title={emp?.contractorName}>{emp?.contractorName || '-'}</span>
                      </td>
                      <td className="px-6 py-4 print:hidden">
                         <button 
                          onClick={() => {
                            if (quotaExceeded) return;
                            setAssignmentModal({ isOpen: true, employeeId: d.employeeId, date: d.date });
                          }}
                          disabled={quotaExceeded}
                          className={`flex items-center gap-2 px-2 py-1.5 rounded-lg border text-xs font-bold uppercase transition-all shadow-sm ${quotaExceeded ? 'opacity-50 cursor-not-allowed border-slate-100 bg-slate-50 text-slate-400' : (assignment ? 'border-indigo-100 bg-indigo-50 text-indigo-600' : 'border-slate-100 bg-slate-50 text-slate-400 hover:border-indigo-200 hover:bg-white')}`}
                         >
                           {shift ? shift.name.substring(0, 8) : 'No Shift'}
                         </button>
                      </td>
                      <td className="px-2 py-4">
                        <span className="text-xs font-semibold text-slate-400 uppercase">
                          {emp?.weeklyOff ? emp.weeklyOff.substring(0, 3) : '-'}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-slate-600 dark:text-slate-400 font-medium whitespace-nowrap">
                        {d.firstPunch ? formatAMPM(d.firstPunch) : (d.lastPunch ? <span className="font-bold text-rose-600 italic text-xs bg-rose-50 px-1 rounded">MISSING IN</span> : '-')}
                      </td>
                      <td className="px-6 py-4 text-slate-600 dark:text-slate-400 font-medium whitespace-nowrap">
                        {(d.lastPunch && d.lastPunch !== d.firstPunch) ? formatAMPM(d.lastPunch) : (d.firstPunch ? <span className="font-bold text-rose-600 italic text-xs bg-rose-50 px-1 rounded">MISSING OUT</span> : '-')}
                      </td>
                      <td className="px-2 py-4 text-center">
                         <span className="text-xs font-bold text-slate-400 bg-slate-50 dark:bg-slate-800 px-1.5 py-0.5 rounded border border-slate-100 dark:border-slate-700">
                           {(d.rawLogs || d.logs).length}
                         </span>
                      </td>
                      <td className="px-4 py-4 text-right text-amber-600 font-mono font-bold text-xs">
                        {d.lateMinutes > 0 ? `${d.lateMinutes}m` : '-'}
                      </td>
                      <td className="px-4 py-4 text-right text-rose-500 font-mono font-bold text-xs">
                        {d.earlyMinutes > 0 ? `${d.earlyMinutes}m` : '-'}
                      </td>
                      <td className="px-6 py-4 text-right text-slate-900 dark:text-white font-mono font-medium">
                        {formatDuration(d.workingHours)}
                      </td>
                      <td className={`px-4 py-4 text-right font-mono font-bold ${d.overtime > 0 ? 'text-indigo-600' : 'text-slate-200 dark:text-slate-700'}`}>
                        {d.overtime > 0 ? formatDuration(d.overtime) : '--'}
                      </td>
                      <td className="px-6 py-4">
                        <span className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-bold uppercase tracking-wider ${
                          d.status === 'Present' ? 'bg-emerald-100 text-emerald-700' : 
                          d.status === 'Absent' ? 'bg-slate-100 text-slate-500' :
                          d.status === 'Weekly Off' ? 'bg-indigo-100 text-indigo-700' :
                          d.status === 'PWO' ? 'bg-indigo-600 text-white' :
                          d.status === 'Late' || d.lateMinutes > 0 ? 'bg-amber-100 text-amber-700' :
                          d.status === 'Early' || d.earlyMinutes > 0 ? 'bg-orange-100 text-orange-700' :
                          'bg-red-50 text-red-600' // SPF
                        } print:text-xs print:font-bold print:uppercase print:tracking-normal print:bg-transparent`}>
                          {d.status === 'Weekly Off' ? 'Off' : (d.status === 'SPF' ? 'MISSING OUT' : (d.status === 'PWO' && d.lateMinutes > 0 ? 'PWO (LATE)' : d.status))}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-xs text-slate-400 font-mono max-w-[200px] print:hidden" title={(d.rawLogs || d.logs).map(l => formatAMPM(l)).join(', ')}>
                        <div className="whitespace-normal text-slate-600 transition-all">
                          {(d.rawLogs || d.logs).map(l => formatAMPM(l)).join(', ') || '--'}
                        </div>
                      </td>
                      <td className="px-6 py-4 text-xs text-slate-300 font-mono max-w-[200px] print:hidden italic" title={d.logs.map(l => formatAMPM(l)).join(', ')}>
                        <div className="whitespace-normal text-slate-400 transition-all">
                          {d.logs.map(l => formatAMPM(l)).join(', ') || '--'}
                        </div>
                      </td>
                      <td className="px-6 py-4 text-center relative print:hidden">
                        <button 
                          onClick={() => setActiveMenu(activeMenu === d.id ? null : d.id)}
                          className="p-1 hover:bg-slate-100 rounded-lg text-slate-400 hover:text-slate-600 transition-colors"
                        >
                          <MoreVertical className="w-4 h-4" />
                        </button>

                        {activeMenu === d.id && (
                          <>
                            <div className="fixed inset-0 z-10" onClick={() => setActiveMenu(null)}></div>
                            <div className="absolute right-6 top-10 w-48 bg-white border border-slate-200 rounded-xl shadow-sm z-20 overflow-hidden animate-in fade-in slide-in-from-top-2 duration-150">
                              <button 
                                onClick={() => {
                                  setSearchTerm(d.employeeId);
                                  setActiveMenu(null);
                                  window.scrollTo({ top: 0, behavior: 'smooth' });
                                }}
                                className="w-full px-4 py-2 text-left text-xs font-bold text-slate-600 hover:bg-indigo-50 hover:text-indigo-600 flex items-center gap-2"
                              >
                                <CalendarDays className="w-3.5 h-3.5" /> View Personal Calendar
                              </button>
                              <button 
                                onClick={() => {
                                  setLogModal({ isOpen: true, record: d, employeeName: emp?.name || 'Unknown' });
                                  setActiveMenu(null);
                                }}
                                className="w-full px-4 py-2 text-left text-xs font-bold text-slate-600 hover:bg-indigo-50 hover:text-indigo-600 flex items-center gap-2"
                              >
                                <Clock className="w-3.5 h-3.5" /> View Detailed Logs
                              </button>
                              <button 
                                onClick={() => {
                                  setAssignmentModal({ isOpen: true, employeeId: d.employeeId, date: d.date });
                                  setActiveMenu(null);
                                }}
                                className="w-full px-4 py-2 text-left text-xs font-bold text-slate-600 dark:text-slate-300 hover:bg-indigo-50 dark:hover:bg-indigo-900/20 hover:text-indigo-600 flex items-center gap-2"
                              >
                                <UserPlus className="w-3.5 h-3.5" /> Adjust Shift
                              </button>
                              <div className="border-t border-slate-100 dark:border-slate-800 my-1"></div>
                              <button 
                                onClick={async () => {
                                  if (window.confirm("Are you sure you want to delete this specific day's punches for this employee?")) {
                                    const dayPunches = punches.filter(p => p.employeeId === d.employeeId && p.punchDatetime.startsWith(d.date)).map(p => p.id);
                                    if (dayPunches.length > 0) {
                                      await deletePunchesBatch(dayPunches);
                                      toast.success("Daily logs purged successfully");
                                    } else {
                                      toast.error("No raw logs found for this entry");
                                    }
                                  }
                                  setActiveMenu(null);
                                }}
                                className="w-full px-4 py-2 text-left text-xs font-semibold text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-900/20 flex items-center gap-2"
                              >
                                <Trash2 className="w-3.5 h-3.5" /> Purge Daily Bio Logs
                              </button>
                            </div>
                          </>
                        )}
                      </td>
                    </tr>
                    {isExpanded && (
                      <tr className="bg-white/50">
                        <td colSpan={19} className="p-0 border-b border-slate-100">
                          <div className="bg-slate-50/30 animate-in slide-in-from-top-2 duration-300 overflow-hidden">
                             <PunchTimeline record={d} />
                          </div>
                        </td>
                      </tr>
                    )}
                    </React.Fragment>
                  );
                }) : (
                  <tr>
                    <td colSpan={14} className="px-6 py-20 text-center">
                      <div className="flex flex-col items-center gap-3">
                        <Archive className="w-10 h-10 text-slate-200" />
                        <p className="text-slate-400 font-medium">
                          {punches.length > 0 && processedData.length > 0 
                            ? "No attendance records match your current filters or date range." 
                            : "No attendance records found. Please import biometric logs to get started."}
                        </p>
                        {punches.length > 0 && processedData.length > 0 && (
                          <button 
                            onClick={() => {
                              setStartDate('1970-01-01');
                              setEndDate('2099-12-31');
                              setStatusFilter(['All']);
                              setDeptFilter(['All']);
                              setSearchTerm('');
                            }}
                            className="text-xs font-bold text-indigo-600 hover:underline"
                          >
                            Clear all filters to see all data
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          {/* Pagination Footer */}
          <div className="bg-slate-50 border-t border-slate-200 px-6 py-4 flex flex-col sm:flex-row items-center justify-between gap-4 print:hidden">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-slate-400 uppercase tracking-normal">Rows:</span>
                <select 
                  value={pageSize} 
                  onChange={(e) => {
                    const val = e.target.value;
                    setPageSize(val === 'All' ? 'All' : Number(val));
                    setCurrentPage(1);
                  }}
                  className="bg-white border border-slate-200 rounded-lg text-xs font-bold px-3 py-1.5 focus:outline-none focus:ring-2 focus:ring-indigo-500 shadow-sm"
                >
                  <option value={10}>10</option>
                  <option value={25}>25</option>
                  <option value={50}>50</option>
                  <option value={100}>100</option>
                  <option value="All">All</option>
                </select>
              </div>
              <p className="text-xs font-bold text-slate-400 uppercase tracking-tight">
                Showing {(currentPage - 1) * (pageSize === 'All' ? 0 : pageSize) + 1} to {Math.min(currentPage * (pageSize === 'All' ? filteredData.length : pageSize), filteredData.length)} of {filteredData.length} records
              </p>
            </div>

            {pageSize !== 'All' && totalPages > 1 && (
              <div className="flex items-center gap-1">
                <button 
                  onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
                  disabled={currentPage === 1}
                  className="p-2 border border-slate-200 rounded-lg hover:bg-white disabled:opacity-30 disabled:cursor-not-allowed transition-colors shadow-sm bg-white"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <div className="flex items-center gap-1">
                  {Array.from({ length: Math.min(5, totalPages) }).map((_, i) => {
                    let pageNum = 1;
                    if (totalPages <= 5) pageNum = i + 1;
                    else if (currentPage <= 3) pageNum = i + 1;
                    else if (currentPage >= totalPages - 2) pageNum = totalPages - 4 + i;
                    else pageNum = currentPage - 2 + i;
                    
                    if (pageNum <= 0 || pageNum > totalPages) return null;

                    return (
                      <button
                        key={pageNum}
                        onClick={() => setCurrentPage(pageNum)}
                        className={`w-8 h-8 rounded-lg text-xs font-bold transition-all ${currentPage === pageNum ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-200' : 'text-slate-500 hover:bg-white border border-transparent hover:border-slate-200'}`}
                      >
                        {pageNum}
                      </button>
                    );
                  })}
                </div>
                <button 
                  onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
                  disabled={currentPage === totalPages}
                  className="p-2 border border-slate-200 rounded-lg hover:bg-white disabled:opacity-30 disabled:cursor-not-allowed transition-colors shadow-sm bg-white"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>
        </div>

      {/* Bulk Assignment Modal */}
      {bulkModal.isOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg shadow-md w-full max-w-lg overflow-hidden animate-in fade-in zoom-in duration-200 font-sans">
            <div className="px-6 py-4 bg-slate-50 border-b border-slate-100 flex items-center justify-between">
              <h3 className="font-bold text-slate-700 text-lg">Bulk Shift Assignment</h3>
              <button 
                onClick={() => setBulkModal({ ...bulkModal, isOpen: false })}
                className="text-slate-400 hover:text-slate-600"
              >
                 <X className="w-5 h-5" />
              </button>
            </div>
            
            <div className="p-6 space-y-4">
              {bulkModal.step === 1 ? (
                <>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-400 uppercase mb-1">Start Date</label>
                      <input 
                        type="date"
                        value={bulkModal.startDate}
                        onChange={e => setBulkModal({ ...bulkModal, startDate: e.target.value })}
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm bg-white"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-400 uppercase mb-1">End Date</label>
                      <input 
                        type="date"
                        value={bulkModal.endDate}
                        onChange={e => setBulkModal({ ...bulkModal, endDate: e.target.value })}
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm bg-white"
                      />
                    </div>
                  </div>

                  <div>
                    <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Select Shift</p>
                    <div className="grid grid-cols-1 gap-2">
                       <button 
                        onClick={() => setBulkModal({ ...bulkModal, shiftId: '' })}
                        className={`p-3 text-left border rounded-xl transition-colors ${bulkModal.shiftId === '' ? 'border-indigo-600 bg-indigo-50/50' : 'border-slate-200 hover:bg-slate-50'}`}
                      >
                        <p className="font-bold text-slate-700 text-sm">Default / Reset</p>
                      </button>
                      {settings.shifts?.map(shift => (
                        <button 
                          key={shift.id}
                          onClick={() => setBulkModal({ ...bulkModal, shiftId: shift.id })}
                          className={`p-3 text-left border rounded-xl transition-colors ${bulkModal.shiftId === shift.id ? 'border-indigo-600 bg-indigo-50/50' : 'border-slate-200 hover:bg-slate-50'}`}
                        >
                          <div className="flex items-center justify-between">
                            <p className="font-bold text-slate-900 text-sm">{shift.name}</p>
                            <span className="text-xs font-bold text-indigo-500">{shift.startTime}-{shift.endTime}</span>
                          </div>
                        </button>
                      ))}
                    </div>
                  </div>
                </>
              ) : (
                <div className="space-y-4">
                   <div className="bg-amber-50 border border-amber-200 p-4 rounded-xl flex items-start gap-3">
                      <AlertCircle className="w-5 h-5 text-amber-600 mt-0.5 shrink-0" />
                      <div className="space-y-1">
                        <p className="text-sm font-bold text-amber-900 leading-none">Confirm Bulk Assignment</p>
                        <p className="text-xs text-amber-700 font-medium">Assigning "{bulkModal.shiftId ? settings.shifts?.find(s => s.id === bulkModal.shiftId)?.name : 'Default'}" to {selectedEmployees.length} staff from {bulkModal.startDate} to {bulkModal.endDate}.</p>
                      </div>
                   </div>
                   <div className="border border-slate-200 rounded-xl overflow-hidden max-h-[220px] overflow-y-auto divide-y divide-slate-100">
                      {selectedEmployees.map(id => {
                        const emp = employees.find(e => e.id === id);
                        return (
                          <div key={id} className="px-4 py-2.5 flex items-center justify-between bg-white text-xs">
                             <span className="font-bold text-slate-700">{emp?.name || id}</span>
                             <span className="font-mono text-slate-400 uppercase">{id}</span>
                          </div>
                        );
                      })}
                   </div>
                </div>
              )}
            </div>
            
            <div className="px-6 py-4 bg-slate-50 border-t border-slate-100 flex justify-end gap-3">
               <button 
                onClick={() => {
                  if (bulkModal.step === 2) setBulkModal({ ...bulkModal, step: 1 });
                  else setBulkModal({ ...bulkModal, isOpen: false });
                }}
                className="px-4 py-2 text-sm font-bold text-slate-500 hover:text-slate-700"
               >
                 {bulkModal.step === 2 ? 'Back' : 'Cancel'}
               </button>
               <button 
                onClick={() => {
                  if (bulkModal.step === 1) setBulkModal({ ...bulkModal, step: 2 });
                  else handleBulkAssign();
                }}
                className="px-6 py-2 bg-indigo-600 text-white rounded-lg text-sm font-bold hover:bg-indigo-700 transition"
               >
                 {bulkModal.step === 1 ? 'Preview Changes' : 'Confirm & Apply'}
               </button>
            </div>
          </div>
        </div>
      )}

      {/* Assignment Modal */}
      {assignmentModal.isOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg shadow-md w-full max-w-md max-h-[90vh] flex flex-col overflow-hidden animate-in fade-in zoom-in duration-200">
            <div className="px-6 py-4 bg-slate-50 border-b border-slate-100 flex items-center justify-between shrink-0">
              <h3 className="font-bold text-slate-700 text-lg">Assign Shift</h3>
              <div className="flex items-center gap-2">
                <button 
                  onClick={() => {
                    const suggested = smartDetectShift(assignmentModal.employeeId);
                    if (suggested) handleAssignShift(suggested);
                    else alert('Not enough historical data to suggest a shift.');
                  }}
                  className="flex items-center gap-1 px-3 py-1.5 bg-indigo-100 text-indigo-700 rounded-lg text-xs font-bold uppercase hover:bg-indigo-200 transition"
                  title="Smart Detect shift based on historical attendance patterns"
                >
                  <Wand2 className="w-3.5 h-3.5" /> Smart Detect
                </button>
                <button 
                  onClick={() => setAssignmentModal({ ...assignmentModal, isOpen: false })}
                  className="text-slate-400 hover:text-slate-600 p-2"
                >
                   <X className="w-5 h-5" />
                </button>
              </div>
            </div>
            
            <div className="p-6 space-y-4 overflow-y-auto">
              <div>
                <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Target Date</p>
                <div className="p-2 bg-indigo-50 text-indigo-700 rounded-lg font-bold text-sm">
                  {assignmentModal.date}
                </div>
              </div>

              <div>
                <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Choose Shift</p>
                <div className="grid grid-cols-1 gap-2">
                  <button 
                    onClick={() => handleAssignShift('')}
                    className="p-3 text-left border border-slate-200 rounded-xl hover:border-indigo-300 hover:bg-slate-50 transition-colors"
                  >
                    <p className="font-bold text-slate-700 text-sm">Default / Unset</p>
                    <p className="text-xs text-slate-500">Reset to employee default shift</p>
                  </button>
                  {settings.shifts?.map(shift => (
                    <button 
                      key={shift.id}
                      onClick={() => handleAssignShift(shift.id)}
                      className="p-3 text-left border border-slate-200 rounded-xl hover:border-indigo-300 hover:bg-indigo-50 transition-colors"
                    >
                      <div className="flex items-center justify-between">
                        <p className="font-bold text-slate-900 text-sm">{shift.name}</p>
                        <span className="text-xs font-bold text-indigo-500 uppercase">{shift.startTime} - {shift.endTime}</span>
                      </div>
                      <p className="text-xs text-slate-500">{shift.isNightShift ? 'Night Shift (Cross-day enabled)' : 'Day Shift'}</p>
                    </button>
                  ))}
                </div>
              </div>

              <div className="pt-4 border-t border-slate-100">
                <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3 flex items-center gap-2">
                  <History className="w-3.5 h-3.5" /> Recent Changes Log
                </p>
                <div className="space-y-2">
                  {assignmentLogs
                    .filter(log => log.employeeId === assignmentModal.employeeId)
                    .slice(0, 5)
                    .map((log, i) => {
                      const shift = settings.shifts?.find(s => s.id === log.shiftId);
                      return (
                        <div key={i} className="flex items-center justify-between p-2 bg-slate-50 rounded-lg border border-slate-100 text-xs">
                          <div className="flex items-center gap-2">
                            <span className={`px-1.5 py-0.5 rounded font-semibold uppercase ${log.action === 'Assigned' ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'}`}>
                              {log.action}
                            </span>
                            <span className="font-bold text-slate-600 truncate max-w-[120px]">
                               {log.date}: {shift?.name || 'Default'}
                            </span>
                          </div>
                          <span className="text-slate-400 font-mono">
                            {format(parseISO(log.timestamp), 'MMM dd, HH:mm')}
                          </span>
                        </div>
                      );
                    })}
                  {assignmentLogs.filter(log => log.employeeId === assignmentModal.employeeId).length === 0 && (
                    <p className="text-xs text-slate-400 italic text-center py-2">No recent changes found</p>
                  )}
                </div>
              </div>
            </div>
            
            <div className="px-6 py-4 bg-slate-50 border-t border-slate-100 flex justify-end shrink-0">
               <button 
                onClick={() => setAssignmentModal({ ...assignmentModal, isOpen: false })}
                className="px-6 py-2 bg-white border border-slate-200 text-slate-700 rounded-lg text-sm font-bold hover:bg-slate-50 transition shadow-sm"
               >
                 Close
               </button>
            </div>
          </div>
        </div>
      )}

      {/* Detailed Logs Modal */}
      {logModal.isOpen && logModal.record && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg shadow-md w-full max-w-md overflow-hidden animate-in fade-in zoom-in duration-200">
            <div className="px-6 py-4 bg-slate-50 border-b border-slate-100 flex items-center justify-between">
              <div>
                <h3 className="font-bold text-slate-700 text-lg">Punch Logs</h3>
                <p className="text-xs font-bold text-slate-400 uppercase tracking-normal">{logModal.employeeName} • {logModal.record.date}</p>
              </div>
              <button 
                onClick={() => setLogModal({ ...logModal, isOpen: false })}
                className="text-slate-400 hover:text-slate-600"
              >
                 <X className="w-5 h-5" />
              </button>
            </div>
            
            <div className="p-6">
              <div className="space-y-6">
                <div>
                  <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3">Actual Bio Logs (Raw)</p>
                  <div className="space-y-2 max-h-48 overflow-y-auto pr-2 custom-scrollbar">
                    {(logModal.record.rawLogs || logModal.record.logs).length > 0 ? (
                      (logModal.record.rawLogs || logModal.record.logs).map((log: string, idx: number) => (
                        <div key={idx} className="flex items-center justify-between p-2 bg-slate-50 rounded-lg border border-slate-100">
                          <span className="text-xs font-bold text-slate-700">{format(parseISO(log), 'hh:mm:ss a')}</span>
                          <span className="text-xs font-mono text-slate-400">{format(parseISO(log), 'MMM dd')}</span>
                        </div>
                      ))
                    ) : (
                      <p className="text-xs text-slate-400 italic">No raw logs</p>
                    )}
                  </div>
                </div>

                <div>
                  <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3">Processed Logs (After Rules)</p>
                  <div className="space-y-2 max-h-48 overflow-y-auto pr-2 custom-scrollbar">
                    {logModal.record.logs.length > 0 ? (
                      logModal.record.logs.map((log: string, idx: number) => (
                        <div key={idx} className="flex items-center justify-between p-2 bg-indigo-50/50 rounded-lg border border-indigo-100">
                          <span className="text-xs font-bold text-indigo-700">{format(parseISO(log), 'hh:mm:ss a')}</span>
                          <span className="text-xs font-mono text-indigo-400">{format(parseISO(log), 'MMM dd')}</span>
                        </div>
                      ))
                    ) : (
                      <p className="text-xs text-slate-400 italic">No processed logs</p>
                    )}
                  </div>
                </div>
              </div>

              <div className="mt-8 grid grid-cols-2 gap-4">
                <div className="p-3 bg-green-50 rounded-xl border border-green-100">
                  <p className="text-xs font-bold text-green-600 uppercase tracking-normal mb-1">In Time</p>
                  <p className="text-sm font-bold text-slate-700">{logModal.record.firstPunch ? format(parseISO(logModal.record.firstPunch), 'hh:mm a') : '--'}</p>
                </div>
                <div className="p-3 bg-indigo-50 rounded-xl border border-indigo-100">
                  <p className="text-xs font-bold text-indigo-600 uppercase tracking-normal mb-1">Out Time</p>
                  <p className="text-sm font-bold text-slate-700">{logModal.record.lastPunch && logModal.record.lastPunch !== logModal.record.firstPunch ? format(parseISO(logModal.record.lastPunch), 'hh:mm a') : '--'}</p>
                </div>
              </div>
            </div>
            
            <div className="px-6 py-4 bg-slate-50 border-t border-slate-100 flex justify-end">
               <button 
                onClick={() => setLogModal({ ...logModal, isOpen: false })}
                className="px-6 py-2 bg-slate-900 text-white rounded-lg text-sm font-bold hover:bg-slate-800 transition shadow-lg"
               >
                 Close
               </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
