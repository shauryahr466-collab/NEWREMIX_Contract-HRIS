import React, { useMemo, useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { useAppStore } from '../store';
import { detectExceptions } from '../lib/engine';
import { format, parseISO, startOfMonth, endOfMonth, eachDayOfInterval, isSameDay } from 'date-fns';
import { 
  ShieldAlert, 
  Search, 
  Filter, 
  CheckCircle2, 
  AlertCircle, 
  Clock, 
  Calendar, 
  User, 
  ChevronRight, 
  ArrowRight,
  History,
  Info,
  X,
  Save,
  Trash2,
  RefreshCw
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { toast } from 'sonner';
import type { AttendanceException, AuditLog, ProcessedAttendance } from '../types';

export default function AttendanceAuditor() {
  const { 
    processedData, 
    employees, 
    settings, 
    auditLogs, 
    addAuditLog, 
    updatePunch, 
    addPunch,
    deletePunch,
    fetchPunches,
    recalculate,
    exceptions,
    updateException,
    openEmployeeProfile,
    globalSearchTerm
  } = useAppStore();
  
  const [searchParams] = useSearchParams();
  const initialType = searchParams.get('type') || 'All';
  const initialDate = searchParams.get('date') || '';
  
  const [typeFilter, setTypeFilter] = useState(initialType);
  const [dateFilter, setDateFilter] = useState(initialDate);
  const [searchTerm, setSearchTerm] = useState('');
  const activeSearch = searchTerm || globalSearchTerm;
  const [statusFilter, setStatusFilter] = useState('pending');
  
  const [selectedException, setSelectedException] = useState<AttendanceException | null>(null);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  
  const allExceptions = useMemo(() => {
    const detected = detectExceptions(processedData, employees, settings);
    return detected.map(d => {
      const stored = exceptions.find(e => e.id === d.id);
      if (stored) return { ...d, ...stored };
      return d;
    });
  }, [processedData, employees, settings, exceptions]);

  const filteredExceptions = useMemo(() => {
    return allExceptions.filter(ex => {
      const matchesType = typeFilter === 'All' || ex.type === typeFilter;
      const matchesDate = !dateFilter || ex.date === dateFilter;
      const emp = employees.find(e => e.id === ex.employeeId);
      const matchesSearch = !activeSearch || 
        emp?.name.toLowerCase().includes(activeSearch.toLowerCase()) || 
        ex.employeeId.toLowerCase().includes(activeSearch.toLowerCase());
      const matchesStatus = statusFilter === 'All' || ex.status === statusFilter;
      
      return matchesType && matchesDate && matchesSearch && matchesStatus;
    });
  }, [allExceptions, typeFilter, dateFilter, activeSearch, statusFilter, employees]);

  const summary = useMemo(() => {
    return {
      total: allExceptions.length,
      pending: allExceptions.filter(e => e.status === 'pending').length,
      spf: allExceptions.filter(e => e.type === 'SPF').length,
      timing: allExceptions.filter(e => e.type === 'Punch Outside Shift').length,
      short: allExceptions.filter(e => e.type === 'Short Hours').length,
    };
  }, [allExceptions]);

  const handleResolve = async (exception: AttendanceException, remarks: string) => {
    const tId = toast.loading('Marking as resolved...');
    try {
      await updateException(exception.id, { 
        status: 'resolved', 
        remarks: remarks || 'Manual resolution', 
        resolvedAt: new Date().toISOString(),
        resolvedBy: 'Admin'
      });
      
      await addAuditLog({
        employeeId: exception.employeeId,
        employeeName: employees.find(e => e.id === exception.employeeId)?.name || 'Unknown',
        date: exception.date,
        field: 'Exception Status',
        oldValue: 'pending',
        newValue: 'resolved',
        changedBy: 'Admin',
        remarks: remarks || 'Manual resolution'
      });

      toast.success('Exception resolved successfully', { id: tId });
      setIsEditModalOpen(false);
    } catch (e) {
      toast.error('Failed to resolve exception', { id: tId });
    }
  };

  const handleRecalculate = async () => {
     const tId = toast.loading('Recalculating attendance data...');
     try {
       await recalculate();
       toast.success('Attendance records refreshed', { id: tId });
     } catch (e) {
       toast.error('Recalculation failed', { id: tId });
     }
  };

  return (
    <div className="space-y-6 pb-20">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-semibold text-slate-900 tracking-tight flex items-center gap-2">
            <ShieldAlert className="w-6 h-6 text-rose-600" />
            Attendance Auditor
          </h2>
          <p className="text-sm text-slate-500 font-bold uppercase tracking-normal mt-1">Quality control & data exception detection</p>
        </div>
        <div className="flex items-center gap-2">
          <button 
            onClick={handleRecalculate}
            className="flex items-center gap-2 bg-white border border-slate-200 px-4 py-2 rounded-xl text-sm font-semibold text-slate-600 hover:bg-slate-50 transition-all shadow-sm"
          >
            <RefreshCw className="w-4 h-4" />
            Recalculate
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatSummaryCard label="Total Exceptions" value={summary.total} icon={<ShieldAlert className="w-5 h-5 text-rose-500" />} color="rose" />
        <StatSummaryCard label="Pending Review" value={summary.pending} icon={<Clock className="w-5 h-5 text-amber-500" />} color="amber" />
        <StatSummaryCard label="SPF Detected" value={summary.spf} icon={<AlertCircle className="w-5 h-5 text-indigo-500" />} color="indigo" />
        <StatSummaryCard label="Timing Issues" value={summary.timing} icon={<Calendar className="w-5 h-5 text-sky-500" />} color="sky" />
      </div>

      <div className="bg-white p-4 rounded-lg border border-slate-200 shadow-sm space-y-4">
        <div className="flex flex-wrap items-center gap-4">
          <div className="relative flex-1 min-w-[240px]">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input 
              type="text" 
              placeholder="Search employee name or ID..."
              className="w-full pl-10 pr-4 py-2 bg-slate-50 border-none rounded-xl text-sm focus:ring-2 focus:ring-indigo-500/20"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          
          <select 
            value={typeFilter}
            onChange={(e) => setTypeFilter(e.target.value)}
            className="px-4 py-2 bg-slate-50 border-none rounded-xl text-sm font-bold text-slate-600 focus:ring-2 focus:ring-indigo-500/20"
          >
            <option value="All">All Types</option>
            <option value="SPF">SPF (Single Punch)</option>
            <option value="Short Hours">Short Hours</option>
            <option value="Long Hours">Long Hours</option>
            <option value="Punch Outside Shift">Timing Mismatch</option>
            <option value="Duplicate Punch">Duplicates</option>
          </select>

          <input 
            type="date" 
            value={dateFilter}
            onChange={(e) => setDateFilter(e.target.value)}
            className="px-4 py-2 bg-slate-50 border-none rounded-xl text-sm font-bold text-slate-600 focus:ring-2 focus:ring-indigo-500/20"
          />

          <select 
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-4 py-2 bg-slate-50 border-none rounded-xl text-sm font-bold text-slate-600 focus:ring-2 focus:ring-indigo-500/20"
          >
            <option value="pending">Pending</option>
            <option value="resolved">Resolved</option>
            <option value="All">All Status</option>
          </select>
        </div>

        <div className="overflow-x-auto rounded-xl border border-slate-100">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50/50">
                <th className="px-6 py-4 text-xs font-semibold text-slate-400 uppercase tracking-normal text-center">Status</th>
                <th className="px-6 py-4 text-xs font-semibold text-slate-400 uppercase tracking-normal">Employee</th>
                <th className="px-6 py-4 text-xs font-semibold text-slate-400 uppercase tracking-normal">Date</th>
                <th className="px-6 py-4 text-xs font-semibold text-slate-400 uppercase tracking-normal">Exception Type</th>
                <th className="px-6 py-4 text-xs font-semibold text-slate-400 uppercase tracking-normal">Details</th>
                <th className="px-6 py-4 text-xs font-semibold text-slate-400 uppercase tracking-normal text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {filteredExceptions.map((ex, idx) => {
                const emp = employees.find(e => e.id === ex.employeeId);
                return (
                  <motion.tr 
                    key={ex.id}
                    initial={{ opacity: 0, y: 5 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: idx * 0.02 }}
                    className="hover:bg-slate-50/50 group"
                  >
                    <td className="px-6 py-4 text-center">
                      {ex.status === 'pending' ? (
                        <div className="w-5 h-5 rounded-full border-2 border-amber-200 mx-auto" />
                      ) : (
                        <CheckCircle2 className="w-5 h-5 text-emerald-500 mx-auto" />
                      )}
                    </td>
                    <td className="px-6 py-4">
                      <div 
                        onClick={() => openEmployeeProfile(ex.employeeId)}
                        className="cursor-pointer group"
                      >
                        <p className="text-sm font-semibold text-slate-900 leading-none group-hover:text-indigo-600 transition-colors">{emp?.name || 'Unknown'}</p>
                        <p className="text-xs font-bold text-slate-400 uppercase tracking-tighter mt-1">{ex.employeeId}</p>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <p className="text-sm font-bold text-slate-600">{format(parseISO(ex.date), 'dd MMM yyyy')}</p>
                    </td>
                    <td className="px-6 py-4">
                      <span className={`text-xs font-semibold uppercase tracking-normal px-2 py-1 rounded-lg ${
                        ex.severity === 'high' ? 'bg-rose-50 text-rose-600' : 
                        ex.severity === 'medium' ? 'bg-amber-50 text-amber-600' : 'bg-slate-100 text-slate-500'
                      }`}>
                        {ex.type}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <p className="text-xs text-slate-500 font-medium max-w-xs">{ex.description}</p>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <button 
                        onClick={() => {
                          setSelectedException(ex);
                          setIsEditModalOpen(true);
                        }}
                        className="text-xs font-semibold uppercase tracking-normal text-indigo-600 px-3 py-1.5 hover:bg-indigo-50 rounded-lg transition-colors border border-transparent hover:border-indigo-100"
                      >
                        Correct Issue
                      </button>
                    </td>
                  </motion.tr>
                );
              })}
              {filteredExceptions.length === 0 && (
                <tr>
                  <td colSpan={6} className="px-6 py-20 text-center">
                    <div className="flex flex-col items-center justify-center opacity-30">
                       <ShieldAlert className="w-12 h-12 text-slate-300 mb-2" />
                       <p className="text-sm font-bold text-slate-400 uppercase tracking-normal">No exceptions found matching filters</p>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      <div className="mt-12">
        <div className="flex items-center gap-2 mb-4">
          <History className="w-5 h-5 text-slate-400" />
          <h3 className="text-lg font-semibold text-slate-900 tracking-tight">Recent Audit Trail</h3>
        </div>
        <div className="bg-white rounded-lg border border-slate-200 shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50/50">
                  <th className="px-6 py-4 text-xs font-semibold text-slate-400 uppercase tracking-normal">Timestamp</th>
                  <th className="px-6 py-4 text-xs font-semibold text-slate-400 uppercase tracking-normal">Modifier</th>
                  <th className="px-6 py-4 text-xs font-semibold text-slate-400 uppercase tracking-normal">Employee</th>
                  <th className="px-6 py-4 text-xs font-semibold text-slate-400 uppercase tracking-normal">Field</th>
                  <th className="px-6 py-4 text-xs font-semibold text-slate-400 uppercase tracking-normal">Old Value</th>
                  <th className="px-6 py-4 text-xs font-semibold text-slate-400 uppercase tracking-normal text-center">→</th>
                  <th className="px-6 py-4 text-xs font-semibold text-slate-400 uppercase tracking-normal">New Value</th>
                  <th className="px-6 py-4 text-xs font-semibold text-slate-400 uppercase tracking-normal">Remarks</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                {auditLogs.slice(0, 50).map((log) => (
                  <tr key={log.id} className="hover:bg-slate-50/50 transition-colors">
                    <td className="px-6 py-4 text-xs font-bold text-slate-400 uppercase">
                      {format(parseISO(log.timestamp), 'dd MMM HH:mm')}
                    </td>
                    <td className="px-6 py-4">
                      <span className="text-xs font-semibold text-slate-700">{log.changedBy}</span>
                    </td>
                    <td className="px-6 py-4">
                      <p className="text-xs font-bold text-slate-900 leading-none">{log.employeeName}</p>
                      <p className="text-xs font-semibold text-slate-400 uppercase tracking-tighter mt-0.5">{log.employeeId}</p>
                    </td>
                    <td className="px-6 py-4">
                      <span className="text-xs font-semibold uppercase tracking-normal text-indigo-500 bg-indigo-50 px-2 py-0.5 rounded">
                        {log.field}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-xs font-mono text-slate-400 line-through truncate max-w-[100px]">{log.oldValue || 'Empty'}</td>
                    <td className="px-6 py-4 text-center text-slate-300">→</td>
                    <td className="px-6 py-4 text-xs font-mono text-emerald-600 font-bold truncate max-w-[100px]">{log.newValue || 'Empty'}</td>
                    <td className="px-6 py-4 text-xs italic text-slate-500">{log.remarks}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {isEditModalOpen && selectedException && (
        <CorrectionModal 
          exception={selectedException} 
          onClose={() => setIsEditModalOpen(false)}
          onSuccess={() => {
            setIsEditModalOpen(false);
            fetchPunches();
          }}
        />
      )}
    </div>
  );
}

function StatSummaryCard({ label, value, icon, color }: any) {
  const colors: any = {
    rose: 'bg-rose-50 text-rose-600 border-rose-100',
    amber: 'bg-amber-50 text-amber-600 border-amber-100',
    indigo: 'bg-indigo-50 text-indigo-600 border-indigo-100',
    sky: 'bg-sky-50 text-sky-600 border-sky-100',
  };
  
  return (
    <div className={`p-5 rounded-lg border shadow-sm ${colors[color] || 'bg-white border-slate-200'}`}>
       <div className="flex items-center justify-between mb-3">
          <div className="w-10 h-10 bg-white/80 rounded-xl flex items-center justify-center shadow-sm">
             {icon}
          </div>
          <span className="text-2xl font-semibold">{value}</span>
       </div>
       <p className="text-xs font-semibold uppercase tracking-normal opacity-60 ml-1">{label}</p>
    </div>
  );
}

function CorrectionModal({ exception, onClose, onSuccess }: { exception: AttendanceException, onClose: () => void, onSuccess: () => void }) {
  const { employees, processedData, settings, addAuditLog, updatePunch, addPunch, deletePunch, updateException } = useAppStore();
  const emp = employees.find(e => e.id === exception.employeeId);
  const attendance = processedData.find(p => p.id === `${exception.employeeId}_${exception.date}`);

  const [inTime, setInTime] = useState(attendance?.firstPunch ? format(parseISO(attendance.firstPunch), 'HH:mm') : '');
  const [outTime, setOutTime] = useState(attendance?.lastPunch ? format(parseISO(attendance.lastPunch), 'HH:mm') : '');
  const [remarks, setRemarks] = useState('');
  const [loading, setLoading] = useState(false);

  const handleApplyCorrection = async () => {
    if (!inTime && !outTime) {
      toast.error('Please specify at least one time');
      return;
    }
    
    setLoading(true);
    const tId = toast.loading('Applying correction...');
    
    try {
      // 1. Log the change
      await addAuditLog({
        employeeId: exception.employeeId,
        employeeName: emp?.name || 'Unknown',
        date: exception.date,
        field: 'Punch Timings',
        oldValue: `IN: ${attendance?.firstPunch || 'None'}, OUT: ${attendance?.lastPunch || 'None'}`,
        newValue: `IN: ${inTime}, OUT: ${outTime}`,
        changedBy: 'Admin',
        remarks: remarks || `Resolved ${exception.type}`
      });

      // 2. Actually update or add punches
      // In this prototype, we'll try to update the existing first/last punch or add new ones
      // Since our engine groups by day, adding a punch at that date will trigger recalculation
      const dateBase = exception.date;
      
      if (inTime) {
        const timestampIn = `${dateBase}T${inTime}:00`;
        await addPunch({ employeeId: exception.employeeId, punchDatetime: timestampIn });
      }
      
      if (outTime) {
        const timestampOut = `${dateBase}T${outTime}:00`;
        await addPunch({ employeeId: exception.employeeId, punchDatetime: timestampOut });
      }

      // 3. Mark exception as resolved in Firestore
      await updateException(exception.id, { status: 'resolved', remarks });

      toast.success('Correction applied and recalculated', { id: tId });
      onSuccess();
    } catch (e) {
      toast.error('Failed to apply correction', { id: tId });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        className="bg-white w-full max-w-lg rounded-lg shadow-md overflow-hidden"
      >
        <div className="bg-slate-900 p-6 text-white relative">
           <div className="flex items-center gap-3 mb-2">
              <div className="w-8 h-8 bg-rose-500 rounded-lg flex items-center justify-center">
                 <ShieldAlert className="w-5 h-5 text-white" />
              </div>
              <h3 className="text-xl font-semibold">Issue Correction</h3>
           </div>
           <p className="text-slate-400 text-xs font-bold uppercase tracking-normal">{exception.type} — {format(parseISO(exception.date), 'dd MMM yyyy')}</p>
           <button onClick={onClose} className="absolute top-6 right-6 text-slate-400 hover:text-white transition-colors">
              <X className="w-6 h-6" />
           </button>
        </div>

        <div className="p-5 space-y-6">
          <div className="flex items-center gap-4 bg-slate-50 p-4 rounded-lg border border-slate-100">
             <div className="w-12 h-12 bg-indigo-600 rounded-xl flex items-center justify-center text-white text-lg font-semibold">
                {emp?.name.charAt(0)}
             </div>
             <div>
                <p className="text-sm font-semibold text-slate-900">{emp?.name}</p>
                <p className="text-xs font-bold text-slate-400 uppercase tracking-normal leading-none mt-1">{emp?.id} • {emp?.department}</p>
             </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-xs font-semibold text-slate-400 uppercase tracking-normal ml-1">Proposed IN Time</label>
              <div className="relative">
                <Clock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input 
                  type="time" 
                  value={inTime}
                  onChange={(e) => setInTime(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 bg-slate-50 border-none rounded-xl text-sm font-semibold focus:ring-2 focus:ring-indigo-500/20"
                />
              </div>
            </div>
            <div className="space-y-2">
              <label className="text-xs font-semibold text-slate-400 uppercase tracking-normal ml-1">Proposed OUT Time</label>
              <div className="relative">
                <Clock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input 
                  type="time" 
                  value={outTime}
                  onChange={(e) => setOutTime(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 bg-slate-50 border-none rounded-xl text-sm font-semibold focus:ring-2 focus:ring-indigo-500/20"
                />
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-xs font-semibold text-slate-400 uppercase tracking-normal ml-1">Resolution Remarks</label>
            <textarea 
              placeholder="Explain why this change is being made..."
              value={remarks}
              onChange={(e) => setRemarks(e.target.value)}
              className="w-full h-24 p-4 bg-slate-50 border-none rounded-lg text-sm italic focus:ring-2 focus:ring-indigo-500/20 resize-none"
            />
          </div>

          <div className="flex gap-3">
            <button 
              onClick={onClose}
              disabled={loading}
              className="flex-1 px-6 py-4 bg-slate-100 text-slate-600 rounded-lg font-semibold text-sm hover:bg-slate-200 transition-all uppercase tracking-normal"
            >
              Cancel
            </button>
            <button 
              onClick={handleApplyCorrection}
              disabled={loading}
              className="flex-[2] px-6 py-4 bg-rose-600 text-white rounded-lg font-semibold text-sm hover:bg-rose-700 transition-all uppercase tracking-normal shadow-sm shadow-rose-100 flex items-center justify-center gap-2"
            >
              {loading ? (
                <div className="w-5 h-5 border-2 border-white/20 border-t-white rounded-full animate-spin" />
              ) : (
                <>
                  <Save className="w-5 h-5" />
                  Save & Resolve
                </>
              )}
            </button>
          </div>
        </div>

        <div className="bg-amber-50 p-4 border-t border-amber-100">
           <div className="flex gap-3">
              <Info className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
              <p className="text-xs text-amber-700 font-bold uppercase tracking-tight leading-relaxed">
                Saving this correction will trigger an automatic recalculation of the attendance record, overtime, and monthly reports.
              </p>
           </div>
        </div>
      </motion.div>
    </div>
  );
}
