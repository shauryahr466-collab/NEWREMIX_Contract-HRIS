import { useMemo, useState } from 'react';
import { useAppStore } from '../store';
import { format, parseISO } from 'date-fns';
import { 
  ShieldAlert, Search, Filter, Calendar, 
  ArrowDownAz, Clock, User, ClipboardList,
  FileText, Download
} from 'lucide-react';
import { cn } from '../lib/utils';
import { motion } from 'motion/react';
import * as XLSX from 'xlsx';

export default function AuditLogs() {
  const { auditLogs, employees, globalSearchTerm } = useAppStore();
  const [searchTerm, setSearchTerm] = useState('');
  const activeSearch = searchTerm || globalSearchTerm;
  const [filterField, setFilterField] = useState('All');

  const filteredLogs = useMemo(() => {
    return auditLogs.filter(log => {
      const matchesSearch = !activeSearch || 
        log.employeeName.toLowerCase().includes(activeSearch.toLowerCase()) || 
        log.employeeId.toLowerCase().includes(activeSearch.toLowerCase()) ||
        log.changedBy.toLowerCase().includes(activeSearch.toLowerCase()) ||
        log.field.toLowerCase().includes(activeSearch.toLowerCase());
      
      const matchesField = filterField === 'All' || log.field === filterField;
      
      return matchesSearch && matchesField;
    });
  }, [auditLogs, activeSearch, filterField]);

  const fields = useMemo(() => ['All', ...new Set(auditLogs.map(l => l.field))], [auditLogs]);

  const exportAuditLogs = () => {
    const data = filteredLogs.map(l => ({
      'Timestamp': format(parseISO(l.timestamp), 'yyyy-MM-dd HH:mm:ss'),
      'Employee ID': l.employeeId,
      'Employee Name': l.employeeName,
      'Modified Field': l.field,
      'Old Value': l.oldValue,
      'New Value': l.newValue,
      'Admin': l.changedBy,
      'Remarks': l.remarks
    }));

    const ws = XLSX.utils.json_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Audit Logs");
    XLSX.writeFile(wb, `Audit_Logs_${format(new Date(), 'yyyyMMdd_HHmm')}.xlsx`);
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-semibold text-slate-900 flex items-center gap-3">
            <ShieldAlert size={32} className="text-indigo-600" />
            System Audit Log
          </h1>
          <p className="text-sm font-bold text-slate-500 uppercase tracking-normal mt-1">
            Tracking administrative overrides and sensitive modifications
          </p>
        </div>
        <button 
          onClick={exportAuditLogs}
          className="flex items-center gap-2 px-6 py-3 bg-white border border-slate-200 rounded-lg text-xs font-semibold uppercase tracking-normal text-slate-600 hover:bg-slate-50 transition-all shadow-sm"
        >
          <Download size={14} />
          Export Audit
        </button>
      </div>

      <div className="bg-white rounded-[2.5rem] border border-slate-200/60 shadow-sm shadow-slate-200/40 p-5">
        <div className="flex flex-wrap items-center gap-4 mb-8">
          <div className="flex-1 min-w-[300px] relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
            <input 
              type="text"
              placeholder="Search by Employee, Admin, or Field..."
              value={activeSearch}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-12 pr-4 py-4 bg-slate-50 border-none rounded-lg text-sm font-bold focus:ring-2 focus:ring-indigo-500/20 transition-all"
            />
          </div>

          <div className="flex items-center gap-2">
            <Filter size={16} className="text-slate-400" />
            <select 
              value={filterField}
              onChange={(e) => setFilterField(e.target.value)}
              className="px-4 py-4 bg-slate-50 border-none rounded-lg text-sm font-bold text-slate-600 focus:ring-2 focus:ring-indigo-500/20"
            >
              <option value="All">All Events</option>
              {fields.filter(f => f !== 'All').map(f => (
                <option key={f} value={f}>{f}</option>
              ))}
            </select>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full border-separate border-spacing-y-3">
            <thead>
              <tr className="text-left text-xs font-semibold text-slate-400 uppercase tracking-wide">
                <th className="px-6 py-4">Timestamp</th>
                <th className="px-6 py-4">Employee</th>
                <th className="px-6 py-4">Field Changed</th>
                <th className="px-6 py-4">Modification Details</th>
                <th className="px-6 py-4">Admin</th>
                <th className="px-6 py-4">Remarks</th>
              </tr>
            </thead>
            <tbody>
              {filteredLogs.map((log) => (
                <tr key={log.id} className="group hover:scale-[1.005] transition-all">
                  <td className="px-6 py-4 bg-slate-50/50 rounded-l-2xl border-y border-l border-slate-100">
                    <p className="text-xs font-semibold text-slate-900">{format(parseISO(log.timestamp), 'dd MMM yyyy')}</p>
                    <p className="text-xs font-bold text-slate-400 uppercase">{format(parseISO(log.timestamp), 'HH:mm:ss')}</p>
                  </td>
                  <td className="px-6 py-4 bg-slate-50/50 border-y border-slate-100">
                    <p className="text-xs font-semibold text-slate-900">{log.employeeName}</p>
                    <p className="text-xs font-semibold text-indigo-600 uppercase tracking-normal">{log.employeeId}</p>
                  </td>
                  <td className="px-6 py-4 bg-slate-50/50 border-y border-slate-100">
                    <span className="px-3 py-1 bg-indigo-50 text-indigo-600 rounded-full text-xs font-semibold uppercase tracking-normal border border-indigo-100">
                      {log.field}
                    </span>
                  </td>
                  <td className="px-6 py-4 bg-slate-50/50 border-y border-slate-100">
                    <div className="flex items-center gap-3">
                      <span className="text-xs font-bold text-slate-400 line-through truncate max-w-[100px]">{log.oldValue || 'None'}</span>
                      <ArrowDownAz size={12} className="text-slate-300 rotate-[-90deg]" />
                      <span className="text-xs font-semibold text-emerald-600 truncate max-w-[150px]">{log.newValue}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 bg-slate-50/50 border-y border-slate-100">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-lg bg-white border border-slate-200 flex items-center justify-center text-slate-400">
                        <User size={14} />
                      </div>
                      <p className="text-xs font-semibold text-slate-600 uppercase tracking-normal">{log.changedBy}</p>
                    </div>
                  </td>
                  <td className="px-6 py-4 bg-slate-50/50 rounded-r-2xl border-y border-r border-slate-100">
                    <p className="text-xs font-bold text-slate-500 italic max-w-[200px] truncate">{log.remarks}</p>
                  </td>
                </tr>
              ))}
              {filteredLogs.length === 0 && (
                <tr>
                  <td colSpan={6} className="py-20 text-center">
                    <div className="flex flex-col items-center gap-4 opacity-20">
                      <ClipboardList size={64} />
                      <p className="text-lg font-semibold uppercase tracking-normal text-slate-400">No audit logs found</p>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
