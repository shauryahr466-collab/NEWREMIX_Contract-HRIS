import { useMemo, useState, useEffect } from 'react';
import { useAppStore } from '../store';
import { format, parseISO, isBefore, isValid, addDays, subDays } from 'date-fns';
import { 
  Users, UserCheck, UserX, Clock, Fingerprint, Calendar, Building2, 
  ChevronLeft, ChevronRight, CalendarClock, ShieldAlert, AlertCircle, 
  ArrowRight, CalendarRange, TrendingUp, DollarSign, Activity,
  Briefcase, History, FileUp, UserPlus, Cog, RefreshCw
} from 'lucide-react';
import { formatAMPM, formatDuration, cn } from '../lib/utils';
import { detectExceptions } from '../lib/engine';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, 
  ResponsiveContainer, Cell, PieChart, Pie, AreaChart, Area
} from 'recharts';
import { motion } from 'motion/react';
import { Link, useNavigate } from 'react-router-dom';
import { DepartmentInsights } from '../components/DepartmentInsights';

export function Dashboard() {
  const navigate = useNavigate();
  const { 
    employees, processedData, settings, shiftAssignments, 
    overtimeRecords, sblRecords, forceAttendanceRecords,
    assignmentLogs, auditLogs, punches,
    openEmployeeProfile, recalculate, isInitializing
  } = useAppStore();
  
  const [activeTab, setActiveTab] = useState<'overview' | 'insights'>('overview');
  const availableDates = useMemo(() => {
    return [...new Set(processedData.map(p => p.date))].sort().reverse();
  }, [processedData]);

  const [dashboardDate, setDashboardDate] = useState<string>(format(new Date(), 'yyyy-MM-dd'));
  const todayStr = useMemo(() => format(new Date(), 'yyyy-MM-dd'), []);

  useEffect(() => {
    if (availableDates.length > 0 && !availableDates.includes(dashboardDate)) {
      setDashboardDate(availableDates[0]);
    }
  }, [availableDates]);

  const isTodaySelected = dashboardDate === todayStr;

  const handlePrevDay = () => setDashboardDate(prev => format(subDays(parseISO(prev), 1), 'yyyy-MM-dd'));
  const handleNextDay = () => setDashboardDate(prev => format(addDays(parseISO(prev), 1), 'yyyy-MM-dd'));

  const processedByDate = useMemo(() => {
    const map = new Map<string, typeof processedData>();
    processedData.forEach(p => {
      const list = map.get(p.date) || [];
      list.push(p);
      map.set(p.date, list);
    });
    return map;
  }, [processedData]);

  const todaysData = useMemo(() => processedByDate.get(dashboardDate) || [], [processedByDate, dashboardDate]);

  const auditSummary = useMemo(() => {
     // Optimization: Only detect exceptions for the selected dashboard date
     const todaysExceptions = detectExceptions(todaysData, employees, settings);
     
     return {
       total: todaysExceptions.length,
       spf: todaysExceptions.filter(e => e.type === 'SPF').length,
       missingOut: todaysExceptions.filter(e => e.type === 'SPF' || e.type === 'Missing Out').length,
       mismatch: todaysExceptions.filter(e => e.type === 'Punch Outside Shift' || e.type === 'Shift Mismatch').length,
       duplicate: todaysExceptions.filter(e => e.type === 'Duplicate Punch').length
     };
  }, [todaysData, employees, settings]);

  const stats = useMemo(() => {
    const present = todaysData.filter(d => ['Present', 'Late', 'SPF', 'On Time', 'Early', 'PWO'].includes(d.status)).length;
    
    const todaysOT = overtimeRecords.filter(r => r.date === dashboardDate && r.status === 'Approved').reduce((acc, curr) => acc + curr.hours, 0);
    const todaysSBL = sblRecords.filter(r => r.date === dashboardDate && (r.status === 'Approved' || r.status === 'Final Confirmed')).length;
    const activeEmployeesCount = employees.filter(e => e.status === 'Active').length;
    const absent = Math.max(0, activeEmployeesCount - present - todaysSBL);
    
    const contractorCount = new Set(employees.filter(e => e.contractorName).map(e => e.contractorName)).size;

    const totalWorkingHours = todaysData.reduce((acc, curr) => acc + curr.workingHours, 0);
    const expectedHours = todaysData.reduce((acc, curr) => acc + (curr.expectedHours || 8), 0);
    const progressPercent = expectedHours > 1 ? Math.min(100, (totalWorkingHours / expectedHours) * 100) : 0;

    return {
      activeEmployees: activeEmployeesCount,
      contractorCount,
      present,
      absent,
      late: todaysData.filter(d => d.lateMinutes > 0).length,
      spf: todaysData.filter(d => d.status === 'SPF').length,
      early: todaysData.filter(d => d.status === 'Early').length,
      assignedShifts: shiftAssignments.filter(a => a.date === dashboardDate).length,
      todaysOT,
      todaysSBL,
      todaysForce: forceAttendanceRecords.filter(r => r.date === dashboardDate).length,
      totalWorkingHours: formatDuration(totalWorkingHours),
      expectedHours: expectedHours.toFixed(1),
      progressPercent
    };
  }, [todaysData, employees, dashboardDate, shiftAssignments, overtimeRecords, sblRecords, forceAttendanceRecords]);

  const dailyBreakdownData = useMemo(() => [
    { name: 'Present', value: stats.present, color: '#10b981' },
    { name: 'Absent', value: stats.absent, color: '#ef4444' },
    { name: 'On Leave', value: stats.todaysSBL, color: '#6366f1' },
  ].filter(d => d.value > 0), [stats]);

  const recentActivities = useMemo(() => {
    const activities: any[] = [];

    // OT Approvals/Requests
    overtimeRecords.slice(-20).forEach(ot => {
      activities.push({
        id: `ot-${ot.id}`,
        type: 'OT',
        title: ot.status === 'Approved' ? 'OT Approved' : 'OT Request',
        subtitle: `${ot.hours}h for ${ot.date}`,
        timestamp: ot.reviewedDate || ot.date, // Approximate if unavailable
        status: ot.status,
        employeeId: ot.employeeId,
        icon: Clock,
        color: ot.status === 'Approved' ? 'emerald' : 'amber'
      });
    });

    // SBL Requests
    sblRecords.slice(-20).forEach(sbl => {
      activities.push({
        id: `sbl-${sbl.id}`,
        type: 'SBL',
        title: `${sbl.leaveType} ${sbl.status}`,
        subtitle: `${sbl.duration} - ${sbl.reason}`,
        timestamp: sbl.date,
        status: sbl.status,
        employeeId: sbl.employeeId,
        icon: CalendarClock,
        color: 'indigo'
      });
    });

    // Corrections
    forceAttendanceRecords.slice(-10).forEach(f => {
      activities.push({
        id: `force-${f.id}`,
        type: 'Correction',
        title: 'Manual Correction',
        subtitle: `${f.inTime} - ${f.outTime} (${f.reason})`,
        timestamp: f.timestamp,
        employeeId: f.employeeId,
        icon: ShieldAlert,
        color: 'rose'
      });
    });

    // Shift Assignments
    assignmentLogs.slice(-20).forEach(log => {
      activities.push({
        id: `shift-${log.id}`,
        type: 'Shift',
        title: `Shift ${log.action}`,
        subtitle: `${log.shiftName} - ${log.date}`,
        timestamp: log.timestamp,
        employeeId: log.employeeId,
        icon: History,
        color: 'indigo'
      });
    });

    // Audit Logs (Field changes)
    auditLogs.slice(-20).forEach(log => {
      activities.push({
        id: `audit-${log.id}`,
        type: 'Audit',
        title: `${log.field} Updated`,
        subtitle: `${log.oldValue} → ${log.newValue}`,
        timestamp: log.timestamp,
        employeeId: log.employeeId,
        icon: Cog,
        color: 'slate'
      });
    });

    // Recent Punches (the top 50 most recent ones for REGISTERED employees)
    const existingEmpIds = new Set(employees.map(e => e.id));
    const latestPunches = [...punches]
      .filter(p => existingEmpIds.has(p.employeeId))
      .sort((a, b) => new Date(b.punchDatetime).getTime() - new Date(a.punchDatetime).getTime())
      .slice(0, 50);

    // Group punches by employee/date to show as "Attendance Import" or "Punch Log"
    const imports = new Set(punches.map(p => p.importId).filter(Boolean));
    // For simplicity, just add some recent punches as activities
    latestPunches.slice(0, 5).forEach(p => {
       activities.push({
         id: `punch-${p.id}`,
         type: 'Punch',
         title: 'Biometric Log',
         subtitle: `Authenticated at ${p.location || 'Main Gate'}`,
         timestamp: p.punchDatetime,
         employeeId: p.employeeId,
         icon: Fingerprint,
         color: 'slate'
       });
    });

    return activities
      .filter(a => a.timestamp)
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
      .slice(0, 10);
  }, [overtimeRecords, sblRecords, forceAttendanceRecords, assignmentLogs, auditLogs, punches]);

  const chartData = useMemo(() => {
     const last30Days = [];
     for (let i = 29; i >= 0; i--) {
       last30Days.push(format(subDays(parseISO(dashboardDate), i), 'yyyy-MM-dd'));
     }

     return last30Days.map(date => {
       const dayData = processedByDate.get(date) || [];
       const present = dayData.filter(d => ['Present', 'Late', 'SPF', 'On Time', 'Early'].includes(d.status)).length;
       return {
         date,
         display: format(parseISO(date), 'dd MMM'),
         Attendance: present,
         OT: overtimeRecords.filter(r => r.date === date && r.status === 'Approved').reduce((acc, curr) => acc + curr.hours, 0)
       };
     });
  }, [processedByDate, dashboardDate, overtimeRecords]);

  const weeklyAttendanceTrends = useMemo(() => {
    const last7Days = [];
    for (let i = 6; i >= 0; i--) {
      last7Days.push(format(subDays(parseISO(dashboardDate), i), 'yyyy-MM-dd'));
    }

    return last7Days.map(date => {
      const dayData = processedByDate.get(date) || [];
      const onTime = dayData.filter(d => ['Present', 'On Time', 'Early', 'PWO'].includes(d.status) && d.lateMinutes === 0).length;
      const late = dayData.filter(d => d.lateMinutes > 0).length;
      const total = onTime + late;
      
      return {
        date,
        display: format(parseISO(date), 'EEE'),
        OnTime: onTime,
        Late: late,
        onTimePercent: total > 0 ? Math.round((onTime / total) * 100) : 0
      };
    });
  }, [processedByDate, dashboardDate]);

  return (
    <div className="space-y-10 animate-in fade-in slide-in-from-bottom-4 duration-700">
      {/* Header with Navigation Tabs */}
      <div className="flex flex-col gap-5 pb-4 border-b border-slate-200/60">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div>
            <h1 className="text-2xl font-semibold text-slate-900 tracking-tight flex items-center gap-4">
              HRIS Operations Dashboard
              <span className="text-sm font-semibold text-indigo-600 bg-indigo-50 px-3 py-1 rounded-full uppercase tracking-normal border border-indigo-100">
                Live Intelligence
              </span>
            </h1>
            <p className="text-sm text-slate-500 font-bold uppercase tracking-normal mt-2 flex items-center gap-2">
              <Activity size={14} className="text-indigo-500" />
              Comprehensive manpower tracking and operational oversight
            </p>
          </div>

          <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-lg border border-slate-200">
            <button 
              onClick={() => setActiveTab('overview')}
              className={cn(
                "px-6 py-2.5 rounded-xl text-xs font-semibold uppercase tracking-normal transition-all",
                activeTab === 'overview' ? "bg-white text-indigo-600 shadow-lg shadow-slate-200" : "text-slate-500 hover:text-slate-700"
              )}
            >
              System Overview
            </button>
            <button 
              onClick={() => setActiveTab('insights')}
              className={cn(
                "px-6 py-2.5 rounded-xl text-xs font-semibold uppercase tracking-normal transition-all",
                activeTab === 'insights' ? "bg-white text-indigo-600 shadow-lg shadow-slate-200" : "text-slate-500 hover:text-slate-700"
              )}
            >
              Department Insights
            </button>
          </div>
        </div>

        {activeTab === 'overview' && (
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4 bg-white p-2 rounded-lg shadow-sm shadow-slate-200/50 border border-slate-100">
              <button onClick={handlePrevDay} className="p-2 hover:bg-slate-100 rounded-xl transition-all text-slate-400"><ChevronLeft size={20} /></button>
              <div className="flex flex-col items-center px-4">
                 <p className="text-xs font-semibold text-slate-400 uppercase tracking-wide">Reporting Period</p>
                 <p className="text-sm font-semibold text-slate-900">{format(parseISO(dashboardDate), 'EEEE, dd MMMM yyyy')}</p>
              </div>
              <button onClick={handleNextDay} className="p-2 hover:bg-slate-100 rounded-xl transition-all text-slate-400"><ChevronRight size={20} /></button>
            </div>

            <button 
              onClick={() => recalculate()}
              disabled={isInitializing}
              className={cn(
                "flex items-center gap-2 px-6 py-3 bg-white border border-slate-200 text-slate-600 rounded-lg text-xs font-semibold uppercase tracking-normal hover:bg-slate-50 transition-all shadow-sm",
                isInitializing && "opacity-50"
              )}
            >
              <RefreshCw className={cn("w-4 h-4 text-indigo-500", isInitializing && "animate-spin")} />
              {isInitializing ? 'Synchronizing...' : 'Reload Company Data'}
            </button>
          </div>
        )}
      </div>

      {activeTab === 'overview' ? (
        <>
          {/* Main Stats Bento Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
            <Link to="/employees?status=Active">
              <ExecutiveStat 
                title="Manpower Strength" 
                value={stats.activeEmployees} 
                icon={Users}
                color="indigo" 
              />
            </Link>
            <Link to={`/attendance?status=Present&date=${dashboardDate}`}>
              <ExecutiveStat 
                title="Present" 
                value={stats.present} 
                subValue={`${Math.round((stats.present / stats.activeEmployees) * 100) || 0}% Engagement`} 
                icon={UserCheck}
                color="emerald" 
              />
            </Link>
            <Link to={`/attendance?status=Absent&date=${dashboardDate}`}>
                <ExecutiveStat 
                  title="Absent" 
                  value={stats.absent} 
                  subValue="Manpower Deficit" 
                  icon={UserX}
                  color="rose" 
                />
            </Link>
            <Link to={`/overtime?status=Approved&date=${dashboardDate}`}>
              <ExecutiveStat 
                title="Approved OT" 
                value={`${stats.todaysOT}h`} 
                subValue="Allocated" 
                icon={Clock}
                color="amber" 
              />
            </Link>
            <Link to="/employees">
              <ExecutiveStat 
                title="Contractors" 
                value={stats.contractorCount} 
                subValue="Active Vendors" 
                icon={Building2}
                color="slate" 
              />
            </Link>
          </div>

          <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
              <Link to={`/attendance?status=Late&date=${dashboardDate}`}>
                <CompactStat title="Late Arrivals" value={stats.late} color="amber" icon={Clock} />
              </Link>
              <Link to={`/attendance?status=Early&date=${dashboardDate}`}>
                <CompactStat title="Early Departures" value={stats.early} color="orange" icon={ArrowRight} />
              </Link>
              <Link to={`/attendance?status=SPF&date=${dashboardDate}`}>
                <CompactStat title="Missing Punch" value={stats.spf} color="rose" icon={Fingerprint} />
              </Link>
              <Link to="/employees?otEligible=true">
                <CompactStat title="OT Eligible" value={employees.filter(e => e.otEligible).length} color="indigo" icon={DollarSign} />
              </Link>
              <Link to="/contracts?expiring=true">
                <CompactStat title="Expiring Contracts" value={0} color="slate" icon={CalendarRange} />
              </Link>
              <Link to="/auditor">
                <CompactStat title="Audit Flags" value={auditSummary.total} color="rose" icon={ShieldAlert} />
              </Link>
          </div>

          {/* Weekly Performance & Audit Preview */}
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-5">
            {/* Weekly Attendance Trends - Stacked Bar Chart */}
            <div className="bg-white rounded-lg border border-slate-100 shadow-sm shadow-slate-200/30 overflow-hidden flex flex-col p-5">
              <div className="flex items-center justify-between mb-8">
                <div>
                  <h3 className="text-lg font-semibold text-slate-900 flex items-center gap-2 uppercase tracking-tight">
                    <CalendarClock className="text-indigo-500" size={20} />
                    Weekly Attendance Trends
                  </h3>
                  <p className="text-xs font-semibold text-slate-400 uppercase tracking-normal mt-1">7-Day Punch Performance</p>
                </div>
                <div className="flex gap-4">
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full bg-emerald-500" />
                    <span className="text-xs font-semibold text-slate-500 uppercase">On-Time</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full bg-rose-500" />
                    <span className="text-xs font-semibold text-slate-500 uppercase">Late</span>
                  </div>
                </div>
              </div>
              <div className="h-[300px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={weeklyAttendanceTrends} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                    <XAxis 
                      dataKey="display" 
                      axisLine={false} 
                      tickLine={false} 
                      tick={{fill: '#94a3b8', fontSize: 10, fontWeight: '900'}} 
                    />
                    <YAxis 
                      axisLine={false} 
                      tickLine={false} 
                      tick={{fill: '#94a3b8', fontSize: 10, fontWeight: '900'}} 
                    />
                    <Tooltip 
                      cursor={{fill: '#f8fafc'}}
                      contentStyle={{ 
                        borderRadius: '16px', 
                        border: 'none', 
                        boxShadow: '0 25px 50px -12px rgba(0,0,0,0.15)',
                        padding: '12px'
                      }}
                      itemStyle={{ fontSize: '10px', fontWeight: '900', textTransform: 'uppercase' }}
                    />
                    <Bar dataKey="OnTime" stackId="a" fill="#10b981" radius={[0, 0, 0, 0]} barSize={32} />
                    <Bar dataKey="Late" stackId="a" fill="#ef4444" radius={[6, 6, 0, 0]} barSize={32} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Manual Overrides Quick Look */}
            <div className="bg-white rounded-lg border border-slate-100 shadow-sm shadow-slate-200/30 overflow-hidden flex flex-col p-5">
               <div className="flex items-center justify-between mb-8">
                  <div>
                    <h3 className="text-lg font-semibold text-slate-900 flex items-center gap-2 uppercase tracking-tight">
                      <ShieldAlert className="text-rose-500" size={20} />
                      Recent Manual Overrides
                    </h3>
                    <p className="text-xs font-semibold text-slate-400 uppercase tracking-normal mt-1">Admin modification audit</p>
                  </div>
                  <Link to="/audit-logs" className="text-xs font-semibold text-indigo-600 uppercase tracking-normal hover:underline">View All</Link>
               </div>
               <div className="space-y-4">
                  {auditLogs.length === 0 ? (
                    <div className="flex flex-col items-center justify-center py-12 text-slate-400">
                      <UserCheck size={48} className="opacity-10" />
                      <p className="text-xs font-semibold uppercase mt-4">No recent manual changes</p>
                    </div>
                  ) : (
                    auditLogs.slice(0, 5).map((log) => (
                      <div key={log.id} className="flex items-start gap-4 p-4 rounded-lg bg-slate-50 border border-slate-100">
                        <div className="w-10 h-10 rounded-xl bg-white flex items-center justify-center text-rose-500 shadow-sm border border-slate-100">
                          <Cog size={18} />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-xs font-semibold text-slate-900 uppercase truncate">{log.field} Update</p>
                          <p className="text-xs font-bold text-slate-500 mt-1 uppercase tracking-tight">
                            {employees.find(e => e.id === log.employeeId)?.name || 'Unknown Employee'} ({log.employeeId})
                          </p>
                          <p className="text-xs font-semibold text-indigo-600 mt-2 uppercase tracking-normal">
                            By {log.changedBy} • {format(parseISO(log.timestamp), 'dd MMM, HH:mm')}
                          </p>
                        </div>
                      </div>
                    ))
                  )}
               </div>
            </div>
          </div>

          {/* Primary Analytics Section */}
          <div className="grid grid-cols-1 xl:grid-cols-3 gap-5">
            {/* Daily Summary Pie Chart */}
            <div className="bg-white rounded-lg border border-slate-100 shadow-sm shadow-slate-200/30 overflow-hidden flex flex-col items-center justify-center p-5">
               <h3 className="text-lg font-semibold text-slate-900 mb-6 flex items-center gap-2 self-start w-full">
                  <Activity className="text-indigo-500" size={20} />
                  Daily Distribution
               </h3>
               <div className="w-full h-[250px] relative">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={dailyBreakdownData}
                        cx="50%"
                        cy="50%"
                        innerRadius={60}
                        outerRadius={80}
                        paddingAngle={5}
                        dataKey="value"
                      >
                        {dailyBreakdownData.map((entry, index) => (
                          <Cell 
                            key={`cell-${index}`} 
                            fill={entry.color} 
                            style={{ cursor: 'pointer' }}
                            onClick={() => {
                              const status = entry.name === 'On Leave' ? 'SBL' : entry.name;
                              navigate(`/attendance?status=${status}&date=${dashboardDate}`);
                            }}
                          />
                        ))}
                      </Pie>
                      <Tooltip 
                        contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 25px 50px -12px rgba(0,0,0,0.15)' }} 
                      />
                    </PieChart>
                  </ResponsiveContainer>
                  <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                     <p className="text-3xl font-semibold text-slate-900 leading-none">{stats.activeEmployees}</p>
                     <p className="text-xs font-semibold text-slate-400 uppercase tracking-normal mt-1">Total Strength</p>
                  </div>
               </div>
               <div className="grid grid-cols-3 gap-4 w-full mt-6">
                  {dailyBreakdownData.map((d) => (
                    <div key={d.name} className="text-center">
                       <p className="text-xl font-semibold text-slate-900">{d.value}</p>
                       <p className="text-xs font-semibold text-slate-400 uppercase tracking-normal mt-1 flex items-center justify-center gap-1">
                          <span className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: d.color }} />
                          {d.name}
                       </p>
                    </div>
                  ))}
               </div>
            </div>

            {/* Large Trend Chart */}
            <div className="xl:col-span-2 bg-white rounded-lg border border-slate-100 shadow-sm shadow-slate-200/30 overflow-hidden flex flex-col">
              <div className="p-5 border-b border-slate-50 flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-semibold text-slate-900 flex items-center gap-2">
                    <TrendingUp className="text-indigo-500" size={20} />
                    Operational Velocity
                  </h3>
                  <p className="text-xs font-semibold text-slate-400 uppercase tracking-normal mt-1">30-day attendance & workload trend</p>
                </div>
                <div className="flex gap-4">
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full bg-indigo-500" />
                    <span className="text-xs font-semibold text-slate-500 uppercase">Presence</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full bg-emerald-500" />
                    <span className="text-xs font-semibold text-slate-500 uppercase">OT Demand</span>
                  </div>
                </div>
              </div>
              <div className="p-5 flex-1 h-[400px]">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={chartData}>
                    <defs>
                      <linearGradient id="colorAtt" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#6366f1" stopOpacity={0.1}/>
                        <stop offset="95%" stopColor="#6366f1" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                    <XAxis dataKey="display" axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 10, fontWeight: 'bold'}} />
                    <YAxis axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 10, fontWeight: 'bold'}} />
                    <Tooltip 
                      contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 25px 50px -12px rgba(0,0,0,0.15)' }} 
                      itemStyle={{ fontSize: '12px', fontWeight: '900' }}
                    />
                    <Area type="monotone" dataKey="Attendance" stroke="#6366f1" strokeWidth={3} fillOpacity={1} fill="url(#colorAtt)" />
                    <Area type="monotone" dataKey="OT" stroke="#10b981" strokeWidth={3} fill="transparent" />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* BROADER RECENT ACTIVITY WIDGET */}
            <div className="xl:col-span-1 bg-white rounded-lg border border-slate-100 shadow-sm shadow-slate-200/30 overflow-hidden flex flex-col">
              <div className="p-5 border-b border-slate-50 bg-slate-50/30">
                <h3 className="text-lg font-semibold text-slate-900 flex items-center gap-2">
                  <Activity className="text-indigo-500" size={20} />
                  System Activity
                </h3>
                <p className="text-xs font-semibold text-slate-400 uppercase tracking-normal mt-1">Real-time operational events</p>
              </div>
              <div className="flex-1 overflow-y-auto custom-scrollbar p-2">
                <div className="space-y-1">
                  {recentActivities.map((activity, idx) => {
                    const emp = employees.find(e => e.id === activity.employeeId);
                    const ActIcon = activity.icon;
                    return (
                      <motion.div 
                        key={activity.id} 
                        initial={{ opacity: 0, x: 20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: idx * 0.05 }}
                        onClick={() => activity.employeeId && openEmployeeProfile(activity.employeeId)}
                        className="p-4 rounded-lg hover:bg-slate-50 cursor-pointer group transition-all border border-transparent hover:border-slate-100"
                      >
                        <div className="flex items-center gap-4">
                          <div className={cn(
                            "w-12 h-12 rounded-xl flex items-center justify-center shadow-sm group-hover:scale-110 transition-transform",
                            `bg-${activity.color}-50 text-${activity.color}-600`
                          )}>
                            <ActIcon size={20} />
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2">
                              <p className="text-sm font-semibold text-slate-900 truncate uppercase">{activity.title}</p>
                              {activity.status && (
                                <span className={cn(
                                  "text-xs font-semibold uppercase px-1.5 py-0.5 rounded-full",
                                  activity.status === 'Approved' ? "bg-emerald-50 text-emerald-600" : "bg-slate-100 text-slate-500"
                                )}>
                                  {activity.status}
                                </span>
                              )}
                            </div>
                            <p className="text-xs font-bold text-slate-400 uppercase tracking-normal leading-none mt-1">
                              {emp?.name || 'System'} • {activity.subtitle}
                            </p>
                          </div>
                          <div className="text-right">
                             <p className="text-xs font-semibold text-indigo-600 font-mono tracking-tighter">
                               {activity.timestamp ? format(parseISO(activity.timestamp), 'HH:mm') : '--:--'}
                             </p>
                             <p className="text-xs font-semibold text-slate-300 uppercase tracking-normal mt-1">
                               {activity.timestamp ? format(parseISO(activity.timestamp), 'dd MMM') : ''}
                             </p>
                          </div>
                        </div>
                      </motion.div>
                    );
                  })}
                </div>
              </div>
              <div className="p-6 bg-slate-50/50 border-t border-slate-50">
                <Link 
                  to="/attendance" 
                  className="w-full py-4 flex items-center justify-center gap-2 text-xs font-semibold text-indigo-500 uppercase tracking-normal hover:text-indigo-700 transition-colors bg-white/50 border border-white rounded-lg"
                >
                  Inspect All Transactions
                  <ArrowRight size={14} />
                </Link>
              </div>
            </div>
          </div>

          {/* Audit Block */}
          {auditSummary.total > 0 && (
            <motion.div 
              initial={{ opacity: 0, scale: 0.98 }} 
              animate={{ opacity: 1, scale: 1 }}
              className="enterprise-gradient p-1 rounded-lg shadow-md"
            >
              <div className="bg-white/95 backdrop-blur-md rounded-[1.4rem] p-5 flex flex-col xl:flex-row items-center gap-10">
                <div className="flex items-center gap-6 shrink-0">
                  <div className="w-20 h-20 rounded-lg bg-rose-600 flex items-center justify-center text-white shadow-md shadow-rose-200">
                    <ShieldAlert size={36} />
                  </div>
                  <div>
                    <h3 className="text-2xl font-semibold text-slate-900 italic">Audit Required</h3>
                    <p className="text-sm font-bold text-rose-500 uppercase tracking-normal mt-1 italic">Anomalies detected in biometric data</p>
                  </div>
                </div>

                <div className="flex flex-wrap items-center justify-center gap-10 flex-1">
                  <AuditStat label="SPF" count={auditSummary.spf} color="rose" />
                  <AuditStat label="Missing Out" count={auditSummary.missingOut} color="amber" />
                  <AuditStat label="Shift Mismatch" count={auditSummary.mismatch} color="indigo" />
                  <AuditStat label="System Flags" count={auditSummary.total} color="slate" />
                </div>

                <Link 
                  to={`/auditor?date=${dashboardDate}`}
                  className="px-10 py-5 bg-rose-600 hover:bg-rose-700 text-white rounded-lg font-semibold text-xs uppercase tracking-normal shadow-sm shadow-rose-200 transition-all flex items-center gap-3 active:scale-95"
                >
                  Start Investigation
                  <ChevronRight size={16} strokeWidth={3} />
                </Link>
              </div>
            </motion.div>
          )}
        </>
      ) : (
        <DepartmentInsights />
      )}
    </div>
  );
}

function ExecutiveStat({ title, value, subValue, trend, icon: Icon, color, isCritical }: any) {
  return (
    <div className={cn(
      "p-6 rounded-[2rem] bg-white border border-slate-100 shadow-sm shadow-slate-200/40 relative overflow-hidden group transition-all hover:-translate-y-1",
      isCritical ? 'ring-2 ring-rose-500/20 ring-offset-4 ring-offset-transparent' : ''
    )}>
      <div className="flex items-center justify-between mb-8">
        <div className={cn(
          "p-4 rounded-lg transition-transform group-hover:scale-110",
          `bg-${color}-50 text-${color}-600`
        )}>
          <Icon size={24} />
        </div>
        {trend && (
          <span className="text-xs font-semibold text-emerald-600 bg-emerald-50 px-2.5 py-1 rounded-full uppercase tracking-normal">
            {trend}
          </span>
        )}
      </div>
      <div>
        <p className="text-xs font-semibold text-slate-400 uppercase tracking-wide">{title}</p>
        <p className="text-2xl font-semibold text-slate-900 mt-2 tracking-tighter">{value}</p>
        <p className="text-xs font-bold text-slate-400 mt-1">{subValue}</p>
      </div>
      <div className="absolute top-0 right-0 p-2 opacity-[0.03] group-hover:opacity-[0.08] transition-opacity">
        <Icon size={120} strokeWidth={2} />
      </div>
    </div>
  );
}

function CompactStat({ title, value, color, icon: Icon }: any) {
  return (
    <div className="bg-white p-4 rounded-lg border border-slate-100 shadow-sm hover:shadow-md transition-all cursor-pointer group">
       <div className="flex items-center gap-3">
          <div className={cn(
            "w-10 h-10 rounded-xl flex items-center justify-center transition-transform group-hover:scale-110",
            `bg-${color}-50 text-${color}-600`
          )}>
            <Icon size={18} />
          </div>
          <div>
            <p className="text-xs font-semibold text-slate-400 uppercase tracking-normal leading-none">{title}</p>
            <p className="text-xl font-semibold text-slate-900 mt-1">{value}</p>
          </div>
       </div>
    </div>
  );
}

function AuditStat({ label, count, color }: any) {
  return (
    <div className="text-center group">
      <p className={cn(
        "text-2xl font-semibold transition-transform group-hover:scale-110",
        `text-${color}-600`
      )}>{count}</p>
      <p className="text-xs font-semibold text-slate-400 uppercase tracking-normal mt-2">{label}</p>
    </div>
  );
}
