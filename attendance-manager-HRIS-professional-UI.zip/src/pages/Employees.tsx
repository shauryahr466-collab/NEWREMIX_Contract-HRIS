import React, { useState, useRef, useMemo, useEffect } from 'react';
import { format } from 'date-fns';
import { useAppStore } from '../store';
import { Employee } from '../types';
import { generateId, cn, normalizeEmployeeId } from '../lib/utils';
import { Plus, Search, Edit2, Trash2, FileUp, Download, X, Filter, RefreshCw, ChevronLeft, ChevronRight } from 'lucide-react';
import * as XLSX from 'xlsx';
import { toast } from 'sonner';
import { MultiSelect } from '../components/MultiSelect';

export function Employees() {
  const { 
    employees, 
    setEmployees, 
    deleteEmployeesBatch, 
    updateEmployee, 
    addEmployee, 
    settings, 
    quotaExceeded,
    globalSearchTerm,
    openEmployeeProfile,
    recalculate,
    isInitializing
  } = useAppStore();
  const [searchTerm, setSearchTerm] = useState('');
  const [activeSearch, setActiveSearch] = useState('');

  // Sync active search
  React.useEffect(() => {
    setActiveSearch(searchTerm || globalSearchTerm);
  }, [searchTerm, globalSearchTerm]);

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const [importFile, setImportFile] = useState<File | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [selectedEmployees, setSelectedEmployees] = useState<string[]>([]);
  const [isBulkShiftModalOpen, setIsBulkShiftModalOpen] = useState(false);
  const [bulkShiftId, setBulkShiftId] = useState('');
  const [sortConfig, setSortConfig] = useState<{ key: 'name' | 'department'; direction: 'asc' | 'desc' } | null>(null);
  const [deptFilter, setDeptFilter] = useState<string[]>(['All']);
  const [designationFilter, setDesignationFilter] = useState<string[]>(['All']);
  const [contractorFilter, setContractorFilter] = useState<string[]>(['All']);
  const [errors, setErrors] = useState<{ name?: string; id?: string }>({});
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const [formData, setFormData] = useState<Partial<Employee>>({
    name: '',
    department: '',
    designation: '',
    contractorName: '',
    shiftId: settings.shifts?.[0]?.id || '',
    status: 'Active',
    contactNumber: '',
    weeklyOff: 'Sunday',
    otEligible: true,
    targetWorkingHours: 8
  });

  const departments = useMemo(() => {
    const depts = employees.map(e => e.department).filter(Boolean) as string[];
    return ['All', ...new Set(depts)];
  }, [employees]);

  const contractors = useMemo(() => {
    const cons = employees.map(e => e.contractorName).filter(Boolean) as string[];
    return ['All', ...new Set(cons)];
  }, [employees]);

  const designations = useMemo(() => {
    const des = employees.map(e => e.designation).filter(Boolean) as string[];
    return ['All', ...new Set(des)];
  }, [employees]);

  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 50;

  const filteredEmployees = useMemo(() => {
    const searchLower = activeSearch.toLowerCase();
    const searchNorm = normalizeEmployeeId(activeSearch);

    let result = employees.filter(e => {
      const nameMatch = e.name.toLowerCase().includes(searchLower);
      const idMatch = e.id.toLowerCase().includes(searchLower) || 
                      (searchNorm && normalizeEmployeeId(e.id).includes(searchNorm));
      const deptMatch = e.department.toLowerCase().includes(searchLower);
      const desigMatch = e.designation?.toLowerCase().includes(searchLower);
      
      const matchesSearch = searchLower === '' || nameMatch || idMatch || deptMatch || desigMatch;
      const matchesDept = deptFilter.includes('All') || deptFilter.includes(e.department);
      const matchesDesig = designationFilter.includes('All') || (e.designation && designationFilter.includes(e.designation));
      const matchesContractor = contractorFilter.includes('All') || (e.contractorName && contractorFilter.includes(e.contractorName));

      return matchesSearch && matchesDept && matchesDesig && matchesContractor;
    });

    if (sortConfig) {
      result.sort((a, b) => {
        const valA = String(a[sortConfig.key] || '').toLowerCase();
        const valB = String(b[sortConfig.key] || '').toLowerCase();
        if (valA < valB) return sortConfig.direction === 'asc' ? -1 : 1;
        if (valA > valB) return sortConfig.direction === 'asc' ? 1 : -1;
        return 0;
      });
    }

    return result;
  }, [employees, activeSearch, deptFilter, designationFilter, contractorFilter, sortConfig]);

  const totalPages = Math.ceil(filteredEmployees.length / itemsPerPage);
  const paginatedEmployees = useMemo(() => {
    const start = (currentPage - 1) * itemsPerPage;
    return filteredEmployees.slice(start, start + itemsPerPage);
  }, [filteredEmployees, currentPage]);

  useEffect(() => {
    setCurrentPage(1);
  }, [activeSearch, deptFilter, designationFilter, contractorFilter]);

  const handleSort = (key: 'name' | 'department') => {
    setSortConfig(prev => ({
      key,
      direction: prev?.key === key && prev.direction === 'asc' ? 'desc' : 'asc'
    }));
  };

  const handleBulkDelete = async () => {
    if (quotaExceeded) {
      toast.error('Cannot delete: Database write limit reached. Please wait for daily reset.');
      return;
    }
    if (selectedEmployees.length === 0) return;
    
    if (!confirm(`Are you sure you want to delete ${selectedEmployees.length} selected employees? This action cannot be undone.`)) {
      return;
    }

    const tId = toast.loading(`Deleting ${selectedEmployees.length} employees...`);
    try {
      await deleteEmployeesBatch(selectedEmployees);
      toast.success('Employees deleted successfully', { id: tId });
      setSelectedEmployees([]);
    } catch (e: any) {
      toast.error(e.message || 'Failed to delete employees', { id: tId });
    }
  };

  const handlePurgeAll = async () => {
    if (quotaExceeded) {
      toast.error('Cannot purge: Database write limit reached.');
      return;
    }
    
    const count = employees.length;
    if (count === 0) return;

    if (!confirm(`CRITICAL: This will permanently delete ALL ${count} employees from the directory. Are you sure you want to proceed?`)) {
      return;
    }

    const confirmation = prompt(`FINAL WARNING: This is irreversible. Type "PURGE" to confirm.`);
    if (confirmation !== 'PURGE') {
      return;
    }

    const tId = toast.loading(`Purging all ${count} records...`);
    try {
      await deleteEmployeesBatch(employees.map(e => e.id));
      toast.success('Directory purged successfully. You can now re-import.', { id: tId });
      setSelectedEmployees([]);
    } catch (e: any) {
      toast.error(e.message || 'Purge failed', { id: tId });
    }
  };

  const handleBulkStatusToggle = async () => {
    if (quotaExceeded) return;
    const updatedEmployees = employees.map(emp => {
      if (selectedEmployees.includes(emp.id)) {
        return { ...emp, status: emp.status === 'Active' ? 'Inactive' : 'Active' as 'Active' | 'Inactive' };
      }
      return emp;
    });
    await setEmployees(updatedEmployees);
    toast.success(`Updated status for ${selectedEmployees.length} employees`);
    setSelectedEmployees([]);
  };

  const handleExportCSV = () => {
    const exportData = filteredEmployees.map((emp, i) => ({
      'S.No': i + 1,
      'Emp ID': emp.id,
      'Name': emp.name,
      'Department': emp.department,
      'Designation': emp.designation,
      'Shift': settings.shifts?.find(s => s.id === emp.shiftId)?.name || '-',
      'OT Eligible': emp.otEligible ? 'Yes' : 'No',
      'Weekly Off': emp.weeklyOff,
      'Status': emp.status
    }));

    const worksheet = XLSX.utils.json_to_sheet(exportData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Employees');
    XLSX.writeFile(workbook, `Employee_Directory_${format(new Date(), 'yyyy-MM-dd')}.csv`);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (quotaExceeded) {
      alert('Cannot save: Database write limit reached.');
      return;
    }

    const newErrors: { name?: string; id?: string } = {};
    if (!formData.name?.trim()) newErrors.name = 'Employee name is required';
    if (!formData.id?.trim()) newErrors.id = 'Employee ID is required';
    
    // Check for duplicate ID if adding new
    if (!editingId && formData.id && employees.some(emp => emp.id === formData.id)) {
      newErrors.id = 'Employee ID already exists';
    }

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    if (editingId) {
      await updateEmployee(editingId, formData);
      toast.success('Employee updated successfully');
    } else {
      const newEmp: Employee = {
        ...formData,
        id: formData.id!.trim(),
        joiningDate: formData.joiningDate || new Date().toISOString().split('T')[0],
      } as Employee;
      await addEmployee(newEmp);
      toast.success('Employee added successfully');
    }
    setIsModalOpen(false);
    resetForm();
  };

  const resetForm = () => {
    setFormData({ 
      name: '', 
      department: '', 
      designation: '', 
      contractorName: '',
      shiftId: settings.shifts?.[0]?.id || '', 
      status: 'Active', 
      contactNumber: '',
      weeklyOff: 'Sunday',
      otEligible: true,
      targetWorkingHours: 8 
    });
    setEditingId(null);
    setErrors({});
  };

  const editEmp = (emp: Employee) => {
    setFormData(emp);
    setEditingId(emp.id);
    setIsModalOpen(true);
  };

  const deleteEmp = async (id: string) => {
    if (quotaExceeded) return;
    if (confirm('Are you sure you want to delete this employee?')) {
      try {
        await deleteEmployeesBatch([id]);
        setSelectedEmployees(prev => prev.filter(eid => eid !== id));
        toast.success('Employee deleted successfully');
      } catch (err: any) {
        toast.error("Failed to delete employee: " + err.message);
      }
    }
  };

  const handleBulkShiftUpdate = async () => {
    if (quotaExceeded) return;
    if (!bulkShiftId) return;
    const updatedEmployees = employees.map(emp => 
      selectedEmployees.includes(emp.id) ? { ...emp, shiftId: bulkShiftId } : emp
    );
    await setEmployees(updatedEmployees);
    setIsBulkShiftModalOpen(false);
    setSelectedEmployees([]);
    setBulkShiftId('');
  };

  const toggleSelectAll = () => {
    if (selectedEmployees.length === filteredEmployees.length) {
      setSelectedEmployees([]);
    } else {
      setSelectedEmployees(filteredEmployees.map(e => e.id));
    }
  };

  const toggleSelectEmployee = (id: string) => {
    setSelectedEmployees(prev => 
      prev.includes(id) ? prev.filter(eid => eid !== id) : [...prev, id]
    );
  };

  const downloadTemplate = () => {
    const template = [
      {
        'Employee ID': 'EMP001',
        'Name': 'John Doe',
        'Department': 'Operations',
        'Designation': 'Machine Operator',
        'Contractor': 'ABC Manpower',
        'Shift': 'Day Shift',
        'Weekly Off': 'Sunday',
        'OT Eligible (Yes/No)': 'Yes',
        'Target Working Hours': 8
      }
    ];
    const ws = XLSX.utils.json_to_sheet(template);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Employees");
    XLSX.writeFile(wb, "Employee_Import_Template.xlsx");
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setImportFile(file);
    }
  };

  const handleUpload = async () => {
    if (!importFile) {
      toast.error("Please select a file first");
      return;
    }
    
    if (quotaExceeded) {
      toast.error('Cannot import: Database write limit reached.');
      return;
    }

    setIsUploading(true);
    const tId = toast.loading('Processing employee data...');

    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const data = new Uint8Array(event.target?.result as ArrayBuffer);
        const workbook = XLSX.read(data, { type: 'array' });
        const worksheet = workbook.Sheets[workbook.SheetNames[0]];
        const json = XLSX.utils.sheet_to_json(worksheet) as any[];

        const importedEmps: Employee[] = json.map(row => {
          const rawId = row['Employee ID'] || row['Emp ID'] || row['EMP ID'] || row['ID'] || row['Employee No'] || row['AC-No.'] || row['Employee No.'] || generateId();
          const id = String(rawId).trim();
          const shiftName = String(row['Shift'] || row['Shift Name'] || 'Day Shift').trim();
          const shift = settings.shifts?.find(s => s.name.toLowerCase() === shiftName.toLowerCase());
          
          return {
            id,
            name: String(row['Name'] || row['Employee Name'] || row['Emp Name'] || 'Unknown').trim(),
            department: String(row['Department'] || row['Dept'] || '').trim(),
            designation: String(row['Designation'] || row['Desig'] || '').trim(),
            contractorName: String(row['Contractor'] || row['Contractor Name'] || row['Contract'] || '').trim(),
            shiftId: shift?.id || settings.shifts?.[0]?.id || '',
            status: 'Active',
            joiningDate: new Date().toISOString().split('T')[0],
            weeklyOff: row['Weekly Off'] || 'Sunday',
            otEligible: String(row['OT Eligible (Yes/No)'] || row['OT Eligible'] || 'No').toLowerCase().includes('yes'),
            targetWorkingHours: Number(row['Target Working Hours'] || row['Target Hours']) || 8
          } as Employee;
        });

        // Try to handle shift name mapping more robustly if initial mapping failed
        importedEmps.forEach(emp => {
          if (!emp.shiftId || emp.shiftId === settings.shifts?.[0]?.id) {
            const rawRow = json.find(r => String(r['Employee ID'] || r['Emp ID'] || r['ID'] || '').trim() === emp.id);
            if (rawRow) {
              const sName = String(rawRow['Shift'] || rawRow['Shift Name'] || '').trim().toLowerCase();
              if (sName) {
                // If user says "Day" but we have "Day Shift", let's try to match
                const match = settings.shifts?.find(s => 
                  s.name.toLowerCase().includes(sName) || 
                  sName.includes(s.name.toLowerCase())
                );
                if (match) emp.shiftId = match.id;
              }
            }
          }
        });

        const existingIds = new Set(employees.map(e => e.id.trim()));
        const existingNormIds = new Set(employees.map(e => normalizeEmployeeId(e.id)).filter(Boolean));

        const newUniqueEmps = importedEmps.filter(e => {
          if (!e.id) return false;
          const trimmedId = e.id.trim();
          const normId = normalizeEmployeeId(trimmedId);
          
          // Avoid duplicates by exact ID OR by normalized similarity
          return !existingIds.has(trimmedId) && (!normId || !existingNormIds.has(normId));
        });
        
        if (newUniqueEmps.length === 0) {
          toast.info("No new unique employees found in file", { id: tId });
          setIsUploading(false);
          return;
        }

        await setEmployees([...employees, ...newUniqueEmps]);
        toast.success(`Successfully imported ${newUniqueEmps.length} new employees.`, { id: tId });
        setIsImportModalOpen(false);
        setImportFile(null);
      } catch (err) {
        toast.error("Failed to parse Excel file. Please ensure it follows the template format.", { id: tId });
      } finally {
        setIsUploading(false);
      }
    };
    reader.readAsArrayBuffer(importFile);
  };



  return (
    <div className="space-y-6 pb-8">
      <div className="flex flex-col gap-6 bg-white p-5 rounded-[2rem] border border-slate-200/60 shadow-sm shadow-slate-200/30">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 pb-6 border-b border-slate-100">
          <div>
            <h2 className="text-3xl font-semibold text-slate-900 tracking-tight">Employee Directory</h2>
            <p className="text-sm font-bold text-slate-500 uppercase tracking-normal mt-1 italic">
              Access and manage {employees.length} enterprise identities
            </p>
            {quotaExceeded && (
              <div className="mt-4 p-3 bg-rose-50 border border-rose-100 rounded-xl flex items-center gap-3 animate-pulse">
                <div className="w-2 h-2 bg-rose-500 rounded-full" />
                <p className="text-xs font-semibold text-rose-600 uppercase tracking-normal">
                  Database Quota Exceeded - Writes are currently disabled
                </p>
              </div>
            )}
          </div>
          <div className="flex flex-wrap items-center gap-3">
            <button 
              onClick={() => recalculate()}
              disabled={isInitializing}
              className={cn(
                "flex items-center gap-2 px-6 py-3 bg-white border border-slate-200 text-slate-600 rounded-lg text-xs font-semibold uppercase tracking-normal hover:bg-slate-50 transition-all shadow-sm",
                isInitializing && "opacity-50"
              )}
            >
              <RefreshCw className={cn("w-4 h-4 text-indigo-500", isInitializing && "animate-spin")} />
              {isInitializing ? 'Syncing...' : 'Sync Data'}
            </button>
            <button 
              onClick={handleExportCSV}
              className="flex items-center gap-2 px-6 py-3 bg-white border border-slate-200 text-slate-600 rounded-lg text-xs font-semibold uppercase tracking-normal hover:bg-slate-50 transition-all shadow-sm"
            >
              <Download className="w-4 h-4" /> Export CSV
            </button>
            <button 
              onClick={() => setIsImportModalOpen(true)}
              className="flex items-center gap-2 px-6 py-3 bg-white border border-slate-200 text-slate-600 rounded-lg text-xs font-semibold uppercase tracking-normal hover:bg-slate-50 transition-all shadow-sm"
            >
              <FileUp className="w-4 h-4" /> Bulk Import
            </button>
            {employees.length > 0 && (
              <button 
                onClick={handlePurgeAll}
                className="flex items-center gap-2 px-6 py-3 bg-rose-50 border border-rose-200 text-rose-600 rounded-lg text-xs font-semibold uppercase tracking-normal hover:bg-rose-100 transition-all shadow-sm"
              >
                <Trash2 className="w-4 h-4" /> Purge All
              </button>
            )}
            <button 
              onClick={() => {
                 if (quotaExceeded) return;
                 resetForm();
                 setIsModalOpen(true);
              }}
              disabled={quotaExceeded}
              className="flex items-center gap-2 px-8 py-3 bg-indigo-600 text-white rounded-lg text-xs font-semibold uppercase tracking-normal hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-200 disabled:opacity-50"
            >
              <Plus className="w-4 h-4" /> New Identity
            </button>
          </div>
        </div>

        <div className="flex flex-col xl:flex-row items-center gap-6">
          <div className="w-full relative group">
            <Search className="w-5 h-5 text-slate-400 absolute left-4 top-1/2 -translate-y-1/2 group-focus-within:text-indigo-500 transition-colors" />
            <input 
              type="text" 
              placeholder="Search by Name, Department, or Employee ID..." 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-12 pr-4 py-4 bg-slate-50 border-none rounded-lg text-sm font-bold focus:ring-2 focus:ring-indigo-500/20 transition-all font-sans placeholder:text-slate-400"
            />
            {searchTerm && (
              <button 
                onClick={() => setSearchTerm('')}
                className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 hover:text-rose-500 transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          <div className="flex flex-wrap items-center gap-4 w-full xl:w-auto shrink-0">
            <div className="w-full sm:w-48">
              <MultiSelect 
                options={departments}
                selected={deptFilter}
                onChange={setDeptFilter}
                placeholder="All Departments"
              />
            </div>

            <div className="w-full sm:w-48">
              <MultiSelect 
                options={designations}
                selected={designationFilter}
                onChange={setDesignationFilter}
                placeholder="All Designations"
              />
            </div>

            <div className="flex items-center gap-2">
              <div className="w-full sm:w-48">
                <MultiSelect 
                  options={contractors}
                  selected={contractorFilter}
                  onChange={setContractorFilter}
                  placeholder="All Contractors"
                />
              </div>
              
              {(deptFilter.length > 1 || designationFilter.length > 1 || contractorFilter.length > 1 || searchTerm) && (
                <button 
                  onClick={() => {
                    setSearchTerm('');
                    setDeptFilter(['All']);
                    setDesignationFilter(['All']);
                    setContractorFilter(['All']);
                  }}
                  className="p-3 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-xl transition-all"
                  title="Clear All Filters"
                >
                  <RefreshCw className="w-5 h-5" />
                </button>
              )}
            </div>
          </div>
        </div>

        {selectedEmployees.length > 0 && (
          <div className="flex items-center gap-2 pt-4 animate-in fade-in slide-in-from-top-1 border-t border-slate-50 mt-2">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-normal mr-2">{selectedEmployees.length} Selected:</span>
            <button 
              onClick={() => setIsBulkShiftModalOpen(true)}
              className="flex items-center gap-2 px-4 py-2 bg-indigo-50 text-indigo-600 border border-indigo-100 rounded-xl text-xs font-semibold uppercase tracking-normal hover:bg-indigo-100 transition-all shadow-sm"
            >
              <Edit2 className="w-3.5 h-3.5" /> Batch Shift
            </button>
            <button 
              onClick={handleBulkStatusToggle}
              className="flex items-center gap-2 px-4 py-2 bg-slate-50 text-slate-600 border border-slate-100 rounded-xl text-xs font-semibold uppercase tracking-normal hover:bg-slate-100 transition-all shadow-sm"
            >
              <RefreshCw className="w-3.5 h-3.5" /> Toggle Status
            </button>
            <button 
              onClick={handleBulkDelete}
              className="flex items-center gap-2 px-4 py-2 bg-rose-50 text-rose-600 border border-rose-100 rounded-xl text-xs font-semibold uppercase tracking-normal hover:bg-rose-100 transition-all shadow-sm"
            >
              <Trash2 className="w-3.5 h-3.5" /> Purge Records
            </button>
          </div>
        )}
      </div>

      <div className="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse table-fixed min-w-[800px]">
            <thead className="bg-slate-50">
              <tr className="text-xs font-semibold text-slate-500 uppercase border-b border-slate-200 text-xs tracking-wider">
                <th className="px-4 py-4 w-12 text-center">
                  <input 
                    type="checkbox" 
                    checked={selectedEmployees.length > 0 && selectedEmployees.length === filteredEmployees.length}
                    onChange={toggleSelectAll}
                    className="w-4 h-4 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500 cursor-pointer"
                  />
                </th>
                <th className="px-4 py-4 w-12 text-center">S.No</th>
                <th className="px-6 py-4 w-32">Emp ID</th>
                <th className="px-6 py-4 cursor-pointer hover:bg-slate-100 transition-colors" onClick={() => handleSort('name')}>
                  <div className="flex items-center gap-1">
                    Name {sortConfig?.key === 'name' && (sortConfig.direction === 'asc' ? '↑' : '↓')}
                  </div>
                </th>
                <th className="px-6 py-4 cursor-pointer hover:bg-slate-100 transition-colors" onClick={() => handleSort('department')}>
                  <div className="flex items-center gap-1">
                    Department {sortConfig?.key === 'department' && (sortConfig.direction === 'asc' ? '↑' : '↓')}
                  </div>
                </th>
                <th className="px-6 py-4">Contractor</th>
                <th className="px-6 py-4 w-32">Shift</th>
                <th className="px-6 py-4 w-20 text-center">TWH</th>
                <th className="px-6 py-4 w-28 text-center text-xs">OT Eligible</th>
                <th className="px-6 py-4 w-32">Weekly Off</th>
                <th className="px-6 py-4 w-24 text-center">Status</th>
                <th className="px-6 py-4 w-32 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-sm">
              {paginatedEmployees.length > 0 ? paginatedEmployees.map((emp, index) => {
                const shift = settings.shifts?.find(s => s.id === emp.shiftId);
                const sNo = (currentPage - 1) * itemsPerPage + index + 1;
                return (
                <tr 
                  key={emp.id} 
                  onClick={() => openEmployeeProfile(emp.id)}
                  className={`hover:bg-slate-50/50 transition-all cursor-pointer group ${selectedEmployees.includes(emp.id) ? 'bg-indigo-50/30' : ''}`}
                >
                  <td className="px-4 py-3 text-center" onClick={(e) => e.stopPropagation()}>
                    <input 
                      type="checkbox" 
                      checked={selectedEmployees.includes(emp.id)}
                      onChange={() => toggleSelectEmployee(emp.id)}
                      className="w-4 h-4 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500 cursor-pointer"
                    />
                  </td>
                  <td className="px-4 py-3 text-center text-slate-400 font-mono text-xs">{sNo}</td>
                  <td className="px-6 py-3 font-mono text-slate-600 font-medium group-hover:text-indigo-600 transition-colors">{emp.id}</td>
                  <td className="px-6 py-3">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-xs font-bold text-slate-400 uppercase tracking-tighter">
                        {emp.name.charAt(0)}
                      </div>
                      <span className="font-medium text-slate-900 leading-none">{emp.name}</span>
                    </div>
                  </td>
                  <td className="px-6 py-3 text-slate-600">{emp.department || '-'}</td>
                  <td className="px-6 py-3 text-slate-500 font-medium">{emp.contractorName || '-'}</td>
                  <td className="px-6 py-3">
                    <span className="inline-flex px-2 py-1 rounded bg-slate-100 text-slate-600 text-xs font-bold">
                      {shift?.name || '-'}
                    </span>
                  </td>
                  <td className="px-6 py-3 text-center font-bold text-slate-600">
                    {emp.targetWorkingHours || 8}
                  </td>
                  <td className="px-6 py-3 text-center">
                    <span className={`inline-flex px-2 py-0.5 rounded text-xs font-bold ${emp.otEligible ? 'bg-indigo-50 text-indigo-600' : 'bg-slate-100 text-slate-400'}`}>
                      {emp.otEligible ? 'YES' : 'NO'}
                    </span>
                  </td>
                  <td className="px-6 py-3 text-slate-600">{emp.weeklyOff || 'Sunday'}</td>
                  <td className="px-6 py-3 text-center">
                    <span className={`inline-flex px-2 py-1 rounded-full text-xs font-bold ${emp.status === 'Active' ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700'}`}>
                      {emp.status}
                    </span>
                  </td>
                  <td className="px-6 py-3 text-right" onClick={(e) => e.stopPropagation()}>
                    <div className="flex items-center justify-end gap-2 text-slate-400">
                      <button onClick={() => editEmp(emp)} className="hover:text-indigo-600 transition-colors p-1.5 hover:bg-slate-100 rounded-lg"><Edit2 className="w-4 h-4" /></button>
                      <button onClick={() => deleteEmp(emp.id)} className="hover:text-red-500 transition-colors p-1.5 hover:bg-slate-100 rounded-lg"><Trash2 className="w-4 h-4" /></button>
                    </div>
                  </td>
                </tr>
                );
              }) : (
                <tr>
                  <td colSpan={11} className="px-6 py-12 text-center text-slate-400 font-medium italic">
                    No employees found matching the filters.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination Controls */}
        {totalPages > 1 && (
          <div className="px-6 py-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-normal">
              Showing {Math.min(filteredEmployees.length, (currentPage - 1) * itemsPerPage + 1)}-{Math.min(filteredEmployees.length, currentPage * itemsPerPage)} of {filteredEmployees.length}
            </span>
            <div className="flex items-center gap-2">
              <button 
                onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                disabled={currentPage === 1}
                className="p-2 bg-white border border-slate-200 rounded-lg text-slate-400 hover:text-indigo-600 hover:border-indigo-100 disabled:opacity-50 disabled:cursor-not-allowed transition-all shadow-sm"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <div className="flex items-center gap-1">
                {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                  let pageNum = 1;
                  if (totalPages <= 5) pageNum = i + 1;
                  else if (currentPage <= 3) pageNum = i + 1;
                  else if (currentPage >= totalPages - 2) pageNum = totalPages - 4 + i;
                  else pageNum = currentPage - 2 + i;

                  return (
                    <button
                      key={pageNum}
                      onClick={() => setCurrentPage(pageNum)}
                      className={`w-8 h-8 rounded-lg text-xs font-bold transition-all shadow-sm ${currentPage === pageNum ? 'bg-indigo-600 text-white' : 'bg-white border border-slate-200 text-slate-600 hover:border-indigo-100 hover:text-indigo-600'}`}
                    >
                      {pageNum}
                    </button>
                  );
                })}
              </div>
              <button 
                onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                disabled={currentPage === totalPages}
                className="p-2 bg-white border border-slate-200 rounded-lg text-slate-400 hover:text-indigo-600 hover:border-indigo-100 disabled:opacity-50 disabled:cursor-not-allowed transition-all shadow-sm"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Bulk Shift Modal */}
      {isBulkShiftModalOpen && (
        <div className="fixed inset-0 bg-slate-900/50 flex items-center justify-center p-4 z-[100] backdrop-blur-sm">
          <div className="bg-white rounded-lg shadow-md max-w-md w-full p-5">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-bold text-slate-900">Bulk Update Shift</h3>
              <button onClick={() => setIsBulkShiftModalOpen(false)} className="p-2 hover:bg-slate-100 rounded-lg text-slate-400"><X /></button>
            </div>
            <p className="text-sm text-slate-500 mb-6 font-medium">Updating shift for <span className="text-indigo-600 font-bold">{selectedEmployees.length}</span> selected employees.</p>
            
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase mb-2">Select New Shift</label>
                <div className="grid grid-cols-1 gap-2">
                  {settings.shifts?.map(shift => (
                    <button 
                      key={shift.id}
                      onClick={() => setBulkShiftId(shift.id)}
                      className={`p-4 text-left border rounded-xl transition-all ${bulkShiftId === shift.id ? 'border-indigo-600 bg-indigo-50 ring-2 ring-indigo-500/20' : 'border-slate-200 hover:bg-slate-50'}`}
                    >
                      <div className="flex items-center justify-between">
                        <p className="font-bold text-slate-900">{shift.name}</p>
                        <span className="text-xs font-mono bg-white px-2 py-0.5 rounded border border-slate-100">{shift.startTime} - {shift.endTime}</span>
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex justify-end gap-3 mt-8">
                <button 
                  onClick={() => setIsBulkShiftModalOpen(false)}
                  className="px-6 py-2 text-sm font-medium text-slate-600 hover:bg-slate-100 rounded-lg"
                >
                  Cancel
                </button>
                <button 
                  onClick={handleBulkShiftUpdate}
                  disabled={!bulkShiftId}
                  className="px-6 py-2 bg-indigo-600 text-white rounded-lg text-sm font-bold shadow-lg hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Update Shifts
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Manual ENTRY Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-slate-900/50 flex items-center justify-center p-4 z-[100] backdrop-blur-sm">
          <div className="bg-white rounded-lg shadow-md max-w-xl w-full p-5 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-bold text-slate-900">{editingId ? 'Edit' : 'Add'} Employee</h3>
              <button onClick={() => setIsModalOpen(false)} className="p-2 hover:bg-slate-100 rounded-lg text-slate-400"><X /></button>
            </div>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div className="col-span-1">
                  <label className="block text-xs font-semibold text-slate-500 uppercase mb-1">Employee ID *</label>
                  <input 
                    type="text" 
                    value={formData.id || ''} 
                    onChange={e => {
                      setFormData({...formData, id: e.target.value});
                      if (errors.id) setErrors(prev => ({ ...prev, id: undefined }));
                    }} 
                    className={`w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 ${errors.id ? 'border-red-500 bg-red-50' : 'border-slate-300 bg-white'}`}
                    placeholder="E.g. EMP001"
                  />
                  {errors.id && <p className="text-xs text-red-500 font-bold mt-1 uppercase">{errors.id}</p>}
                </div>
                <div className="col-span-1">
                  <label className="block text-xs font-semibold text-slate-500 uppercase mb-1">Full Name *</label>
                  <input 
                    type="text" 
                    value={formData.name || ''} 
                    onChange={e => {
                      setFormData({...formData, name: e.target.value});
                      if (errors.name) setErrors(prev => ({ ...prev, name: undefined }));
                    }} 
                    className={`w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 ${errors.name ? 'border-red-500 bg-red-50' : 'border-slate-300 bg-white'}`} 
                  />
                  {errors.name && <p className="text-xs text-red-500 font-bold mt-1 uppercase">{errors.name}</p>}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-500 uppercase mb-1">Department</label>
                  <input type="text" value={formData.department || ''} onChange={e => setFormData({...formData, department: e.target.value})} className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500" />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-500 uppercase mb-1">Designation</label>
                  <input type="text" value={formData.designation || ''} onChange={e => setFormData({...formData, designation: e.target.value})} className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500" />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-500 uppercase mb-1">Contractor Name</label>
                  <input type="text" value={formData.contractorName || ''} onChange={e => setFormData({...formData, contractorName: e.target.value})} className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500" />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-500 uppercase mb-1">Shift</label>
                  <select 
                    value={formData.shiftId} 
                    onChange={e => setFormData({...formData, shiftId: e.target.value})} 
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  >
                    <option value="">Select Shift</option>
                    {settings.shifts?.map(s => <option key={s.id} value={s.id}>{s.name} ({s.startTime}-{s.endTime})</option>)}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-500 uppercase mb-1">Weekly Off</label>
                  <select value={formData.weeklyOff} onChange={e => setFormData({...formData, weeklyOff: e.target.value})} className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500">
                    {['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'].map(day => <option key={day} value={day}>{day}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-500 uppercase mb-1">Working Hours</label>
                  <input type="number" value={formData.targetWorkingHours} onChange={e => setFormData({...formData, targetWorkingHours: Number(e.target.value)})} className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500" />
                </div>
                <div className="flex items-center gap-2 pt-6">
                  <input 
                    type="checkbox" 
                    id="otEligible"
                    checked={formData.otEligible} 
                    onChange={e => setFormData({...formData, otEligible: e.target.checked})} 
                    className="w-4 h-4 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500"
                  />
                  <label htmlFor="otEligible" className="text-sm font-semibold text-slate-700">OT Eligible</label>
                </div>
              </div>

              <div className="flex justify-end gap-3 mt-8">
                <button type="button" onClick={() => setIsModalOpen(false)} className="px-6 py-2 text-sm font-medium text-slate-600 hover:bg-slate-100 rounded-lg transition-colors">Cancel</button>
                <button type="submit" className="px-6 py-2 bg-indigo-600 text-white rounded-lg text-sm font-bold shadow-lg hover:bg-indigo-700 transition-colors">Save Employee</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* IMPORT Modal */}
      {isImportModalOpen && (
        <div className="fixed inset-0 bg-slate-900/50 flex items-center justify-center p-4 z-[100] backdrop-blur-sm">
          <div className="bg-white rounded-lg shadow-md max-w-md w-full p-5">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-bold text-slate-900">Bulk Import Employees</h3>
              <button 
                onClick={() => {
                  setIsImportModalOpen(false);
                  setImportFile(null);
                }} 
                className="p-2 hover:bg-slate-100 rounded-lg text-slate-400"
              >
                <X />
              </button>
            </div>
            
            <div className="space-y-6">
              <div className={cn(
                "p-6 border-2 border-dashed rounded-xl text-center space-y-4 transition-all",
                importFile ? "border-indigo-500 bg-indigo-50/30" : "border-slate-200"
              )}>
                <div className="flex justify-center">
                  <FileUp className={cn("w-10 h-10 transition-colors", importFile ? "text-indigo-600" : "text-indigo-400")} />
                </div>
                <div className="text-sm text-slate-500 font-medium">
                  {importFile ? (
                    <div className="space-y-1">
                      <p className="text-slate-900 font-bold">{importFile.name}</p>
                      <p className="text-xs uppercase tracking-normal text-slate-400">File Loaded Successfully</p>
                    </div>
                  ) : (
                    "Select an Excel file to import employee master data."
                  )}
                </div>
                <input 
                  type="file" 
                  ref={fileInputRef} 
                  onChange={handleFileChange} 
                  accept=".xlsx, .xls" 
                  className="hidden" 
                />
                
                <div className="flex flex-col gap-2 pt-2">
                  <button 
                    onClick={() => fileInputRef.current?.click()}
                    className={cn(
                      "px-4 py-2.5 rounded-xl text-xs font-semibold uppercase tracking-normal transition-all",
                      importFile 
                        ? "bg-white border border-slate-200 text-slate-600 hover:bg-slate-50" 
                        : "bg-indigo-600 text-white shadow-lg shadow-indigo-200 hover:bg-indigo-700"
                    )}
                  >
                    {importFile ? "Change File (Load)" : "Choose File (Load)"}
                  </button>
                  
                  {importFile && (
                    <button 
                      onClick={handleUpload}
                      disabled={isUploading}
                      className="px-4 py-2.5 bg-emerald-600 text-white rounded-xl text-xs font-semibold uppercase tracking-normal shadow-lg shadow-emerald-200 hover:bg-emerald-700 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
                    >
                      {isUploading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <FileUp className="w-4 h-4" />}
                      {isUploading ? "Uploading..." : "Upload & Process"}
                    </button>
                  )}
                </div>
              </div>

              <div className="bg-slate-50 p-4 rounded-xl space-y-3">
                <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider">Instructions</h4>
                <p className="text-xs text-slate-600 leading-relaxed font-medium">
                  1. Use our standard template for best results.<br/>
                  2. Required fields: Employee ID (unique), Name.<br/>
                  3. Existing IDs in directory will be skipped.
                </p>
                <button 
                  onClick={downloadTemplate}
                  className="flex items-center gap-2 text-indigo-600 text-xs font-semibold hover:underline uppercase tracking-tighter"
                >
                  <Download className="w-3 h-3" /> Download Template
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
