import React, { useState, useMemo } from 'react';
import { useAppStore } from '../store';
import { format, parseISO } from 'date-fns';
import { UserCheck, Search, Plus, Save, Clock, Calendar, FileText, ChevronRight } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { toast } from 'sonner';

export default function ForceAttendance() {
  const { employees, forceAttendanceRecords, addForceAttendance, addAuditLog, addPunch } = useAppStore();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  const [formData, setFormData] = useState({
    employeeId: '',
    date: '',
    inTime: '',
    outTime: '',
    reason: '',
    remarks: ''
  });

  const filteredRecords = useMemo(() => {
    return forceAttendanceRecords.filter(record => {
      const emp = employees.find(e => e.id === record.employeeId);
      return !searchTerm || 
        emp?.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
        record.employeeId.toLowerCase().includes(searchTerm.toLowerCase());
    });
  }, [forceAttendanceRecords, employees, searchTerm]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.employeeId || !formData.date || !formData.inTime || !formData.outTime) {
      toast.error('Please fill all required fields');
      return;
    }

    try {
      // 1. Save Force Attendance Record
      await addForceAttendance({
        ...formData,
        approvedBy: 'Admin'
      });

      // 2. Add Audit Log
      const emp = employees.find(e => e.id === formData.employeeId);
      await addAuditLog({
        employeeId: formData.employeeId,
        employeeName: emp?.name || 'Unknown',
        date: formData.date,
        field: 'Force Attendance',
        oldValue: 'None',
        newValue: `IN: ${formData.inTime}, OUT: ${formData.outTime}`,
        changedBy: 'Admin',
        remarks: `Manual Entry: ${formData.reason}`
      });

      // 3. Inject simulated punches into the attendance system
      const dateBase = formData.date;
      await addPunch({ employeeId: formData.employeeId, punchDatetime: `${dateBase}T${formData.inTime}:00` });
      await addPunch({ employeeId: formData.employeeId, punchDatetime: `${dateBase}T${formData.outTime}:00` });

      toast.success('Force attendance applied and synchronized');
      setIsModalOpen(false);
      setFormData({ employeeId: '', date: '', inTime: '', outTime: '', reason: '', remarks: '' });
    } catch (error) {
      toast.error('Failed to apply force attendance');
    }
  };

  return (
    <div className="space-y-6 pb-20">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-semibold text-slate-900 tracking-tight flex items-center gap-2">
            <UserCheck className="w-6 h-6 text-emerald-600" />
            Force Attendance
          </h2>
          <p className="text-sm text-slate-500 font-bold uppercase tracking-normal mt-1">Manual Override & Correction</p>
        </div>
        <button 
          onClick={() => setIsModalOpen(true)}
          className="flex items-center gap-2 bg-emerald-600 text-white px-5 py-2.5 rounded-xl font-bold text-sm transition-all shadow-lg shadow-emerald-100 hover:bg-emerald-700"
        >
          <Plus className="w-4 h-4" />
          New Adjustment
        </button>
      </div>

      <div className="bg-white p-4 rounded-lg border border-slate-200 shadow-sm space-y-4">
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input 
            type="text" 
            placeholder="Search adjustments..."
            className="w-full pl-10 pr-4 py-2 bg-slate-50 border-none rounded-xl text-sm focus:ring-2 focus:ring-emerald-500/20"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>

        <div className="overflow-x-auto rounded-xl border border-slate-100">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50/50 text-xs font-semibold text-slate-400 uppercase tracking-normal">
                <th className="px-6 py-4">Employee</th>
                <th className="px-6 py-4">Adjustment Date</th>
                <th className="px-6 py-4">Punch Duration</th>
                <th className="px-6 py-4">Reason</th>
                <th className="px-6 py-4">Processed At</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {filteredRecords.map((record, idx) => {
                const emp = employees.find(e => e.id === record.employeeId);
                return (
                  <tr key={record.id} className="hover:bg-slate-50/50 transition-colors">
                    <td className="px-6 py-4">
                      <p className="text-sm font-semibold text-slate-900 leading-none">{emp?.name || 'Unknown'}</p>
                      <p className="text-xs font-bold text-slate-400 mt-1 uppercase">{record.employeeId}</p>
                    </td>
                    <td className="px-6 py-4 text-sm font-bold text-slate-600">
                      {format(parseISO(record.date), 'dd MMM yyyy')}
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-semibold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded italic">{record.inTime}</span>
                        <ChevronRight className="w-3 h-3 text-slate-300" />
                        <span className="text-xs font-semibold text-rose-600 bg-rose-50 px-2 py-0.5 rounded italic">{record.outTime}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-xs font-bold text-slate-500 max-w-xs">{record.reason}</td>
                    <td className="px-6 py-4 text-xs font-bold text-slate-400 uppercase">
                      {format(parseISO(record.timestamp), 'dd MMM HH:mm')}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      <AnimatePresence>
        {isModalOpen && (
          <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="bg-white w-full max-w-lg rounded-lg shadow-md overflow-hidden"
            >
              <form onSubmit={handleSubmit}>
                <div className="bg-emerald-600 p-6 text-white">
                  <h3 className="text-xl font-semibold flex items-center gap-2">
                    <UserCheck className="w-6 h-6" />
                    Force Attendance Entry
                  </h3>
                  <p className="text-emerald-100 text-xs font-bold uppercase tracking-normal mt-1">Directly inject attendance records</p>
                </div>

                <div className="p-5 space-y-5">
                  <div className="space-y-2">
                    <label className="text-xs font-semibold text-slate-400 uppercase tracking-normal ml-1">Employee</label>
                    <select 
                      className="w-full px-4 py-3 bg-slate-50 border-none rounded-xl text-sm font-bold focus:ring-2 focus:ring-emerald-500/20"
                      value={formData.employeeId}
                      onChange={(e) => setFormData({ ...formData, employeeId: e.target.value })}
                      required
                    >
                      <option value="">Select Employee</option>
                      {employees.map(e => <option key={e.id} value={e.id}>{e.name} ({e.id})</option>)}
                    </select>
                  </div>

                  <div className="space-y-2">
                    <label className="text-xs font-semibold text-slate-400 uppercase tracking-normal ml-1">Date</label>
                    <input 
                      type="date" 
                      className="w-full px-4 py-3 bg-slate-50 border-none rounded-xl text-sm font-bold focus:ring-2 focus:ring-emerald-500/20"
                      value={formData.date}
                      onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                      required
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label className="text-xs font-semibold text-slate-400 uppercase tracking-normal ml-1">Manual IN Time</label>
                      <input 
                        type="time" 
                        className="w-full px-4 py-3 bg-slate-50 border-none rounded-xl text-sm font-bold focus:ring-2 focus:ring-emerald-500/20"
                        value={formData.inTime}
                        onChange={(e) => setFormData({ ...formData, inTime: e.target.value })}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-semibold text-slate-400 uppercase tracking-normal ml-1">Manual OUT Time</label>
                      <input 
                        type="time" 
                        className="w-full px-4 py-3 bg-slate-50 border-none rounded-xl text-sm font-bold focus:ring-2 focus:ring-emerald-500/20"
                        value={formData.outTime}
                        onChange={(e) => setFormData({ ...formData, outTime: e.target.value })}
                        required
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-xs font-semibold text-slate-400 uppercase tracking-normal ml-1">Adjustment Reason</label>
                    <select 
                      className="w-full px-4 py-3 bg-slate-50 border-none rounded-xl text-sm font-bold focus:ring-2 focus:ring-emerald-500/20"
                      value={formData.reason}
                      onChange={(e) => setFormData({ ...formData, reason: e.target.value })}
                      required
                    >
                      <option value="">Select Reason</option>
                      <option value="Biometric Machine Miss">Biometric Machine Miss</option>
                      <option value="Forgot to Punch">Forgot to Punch</option>
                      <option value="Device Issue">Device Issue</option>
                      <option value="On Duty / Outstation">On Duty / Outstation</option>
                      <option value="Approved Manual Adjustment">Approved Manual Adjustment</option>
                    </select>
                  </div>

                  <div className="pt-4 flex gap-3">
                    <button 
                      type="button" 
                      onClick={() => setIsModalOpen(false)}
                      className="flex-1 px-6 py-4 bg-slate-100 text-slate-600 rounded-lg font-semibold text-sm hover:bg-slate-200 transition-all uppercase tracking-normal"
                    >
                      Cancel
                    </button>
                    <button 
                      type="submit"
                      className="flex-[2] px-6 py-4 bg-emerald-600 text-white rounded-lg font-semibold text-sm hover:bg-emerald-700 transition-all uppercase tracking-normal shadow-sm shadow-emerald-100 flex items-center justify-center gap-2"
                    >
                      <Save className="w-5 h-5" />
                      Apply Force View
                    </button>
                  </div>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
