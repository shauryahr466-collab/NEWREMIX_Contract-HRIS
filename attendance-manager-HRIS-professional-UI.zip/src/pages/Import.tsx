import React, { useState, useMemo } from 'react';
import * as XLSX from 'xlsx';
import { UploadCloud, CheckCircle2, AlertCircle, Trash2, History, Database, Download, Filter, CalendarDays, ClipboardList } from 'lucide-react';
import { useAppStore } from '../store';
import { RawPunch, ShiftAssignment } from '../types';
import { generateId, cn, normalizeEmployeeId } from '../lib/utils';
import { processPunches } from '../lib/engine';
import { useNavigate } from 'react-router-dom';
import { format, parse, parseISO } from 'date-fns';
import { toast } from 'sonner';
import { processRosterUpload, generateRosterTemplate } from '../lib/roster';

export function Import() {
  const { 
    punches, setPunches, deletePunch, deletePunchBatch, clearPunches, 
    employees, setEmployees, settings, shiftAssignments, setShiftAssignments, 
    calculationSource, setCalculationSource, quotaExceeded, recalculate 
  } = useAppStore();
  const [importType, setImportType] = useState<'punch' | 'roster'>('punch');
  const [isDragging, setIsDragging] = useState(false);
  const [file, setFile] = useState<File | null>(null);
  const [status, setStatus] = useState<'idle' | 'processing' | 'success' | 'error'>('idle');
  const [message, setMessage] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [viewMode, setViewMode] = useState<'sessions' | 'recent'>('sessions');
  const [sessionStartDate, setSessionStartDate] = useState('');
  const [sessionEndDate, setSessionEndDate] = useState('');
  const [isConfirmingPurge, setIsConfirmingPurge] = useState(false);
  const [purgeConfirmationInput, setPurgeConfirmationInput] = useState('');
  const [showOnlyRegistered, setShowOnlyRegistered] = useState(true);
  const navigate = useNavigate();

  const downloadSample = () => {
    if (importType === 'punch') {
      const sampleData = [
        {
          "Employee No.": "3058",
          "Name": "Mukesh Kumar",
          "Department": "RA Energy",
          "Date": "5/28/2026",
          "Time.1": "09:00 AM",
          "Time.2": "06:01 PM"
        },
        {
          "Employee No.": "1246",
          "Name": "Hemant Dahal",
          "Department": "HR/Admin",
          "Date": "5/30/2026",
          "Time.1": "10:00 PM",
          "Time.2": "06:00 AM",
          "Time.3": "06:15 AM"
        }
      ];

      const ws = XLSX.utils.json_to_sheet(sampleData);
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, "Raw Punches");
      XLSX.writeFile(wb, "Raw_Punch_Template.xlsx");
    } else {
      const wb = generateRosterTemplate();
      XLSX.writeFile(wb, "Roster_Import_Template.xlsx");
    }
  };

  const sessions = useMemo(() => {
    const sessionsMap = new Map<string, { id: string; count: number; date: string; format: string; fileName?: string }>();
    punches.forEach(p => {
      if (p.importId) {
        const existing = sessionsMap.get(p.importId);
        if (existing) {
          existing.count++;
          if (p.fileName && !existing.fileName) existing.fileName = p.fileName;
        } else {
          sessionsMap.set(p.importId, {
            id: p.importId!,
            count: 1,
            date: p.importDate || p.punchDatetime, 
            format: p.importFormat || 'standard',
            fileName: p.fileName || 'Imported File'
          });
        }
      }
    });

    return Array.from(sessionsMap.values())
      .filter(s => {
        const dateStr = s.date.split('T')[0];
        if (sessionStartDate && dateStr < sessionStartDate) return false;
        if (sessionEndDate && dateStr > sessionEndDate) return false;
        return true;
      })
      .sort((a, b) => b.date.localeCompare(a.date));
  }, [punches, sessionStartDate, sessionEndDate]);

  const orphansCount = useMemo(() => {
    return punches.filter(p => !p.importId).length;
  }, [punches]);

  const sortedPunches = useMemo(() => {
    const existingEmpIds = new Set(employees.map(e => e.id));
    return [...punches]
      .filter(p => {
        const matchesSearch = !searchTerm || p.employeeId.toLowerCase().includes(searchTerm.toLowerCase());
        const isRegistered = existingEmpIds.has(p.employeeId);
        if (showOnlyRegistered && !isRegistered) return false;
        return matchesSearch;
      })
      .sort((a, b) => b.punchDatetime.localeCompare(a.punchDatetime))
      .slice(0, 100);
  }, [punches, searchTerm, showOnlyRegistered, employees]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (quotaExceeded) {
      setStatus('error');
      setMessage('Cannot upload: Database write quota reached.');
      return;
    }
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
      setStatus('idle');
    }
  };

  const processFile = async () => {
    if (quotaExceeded) return;
    if (!file) return;
    setStatus('processing');
    setMessage('Reading file...');

    const reader = new FileReader();
    reader.onload = async (e) => {
      try {
        const data = new Uint8Array(e.target?.result as ArrayBuffer);
        const workbook = XLSX.read(data, { type: 'array' });
        const firstSheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheetName];

        if (importType === 'punch') {
          const json = XLSX.utils.sheet_to_json(worksheet) as any[];

          setMessage(`Parsing ${json.length} records...`);

          // Yield to browser to update UI
          await new Promise(resolve => setTimeout(resolve, 10));

          const batchId = `BATCH_${Date.now()}`;
          const importDate = new Date().toISOString();
          const finalNewPunchesRaw: RawPunch[] = [];
          
          // Map for faster lookup with multiple normalization strategies
          const employeeIdMap = new Map<string, string>(); // Normalized -> Actual ID
          const failedMatches = new Set<string>();
          
          const getNormalized = (id: any) => {
            const str = String(id).trim();
            const numeric = normalizeEmployeeId(str);
            const lowercase = str.toLowerCase();
            return { original: str, numeric, lowercase };
          };
          
          employees.forEach(e => {
            const norm = getNormalized(e.id);
            employeeIdMap.set(norm.original, e.id);
            employeeIdMap.set(norm.lowercase, e.id);
            if (norm.numeric) {
              // Only map numeric if it's unique enough or we prioritize it
              if (!employeeIdMap.has(norm.numeric)) {
                employeeIdMap.set(norm.numeric, e.id);
              }
            }
          });

          // Helper for deterministic IDs to prevent duplicates on re-import
          const makePunchId = (empId: string, dt: string) => `p_${empId}_${dt}`.replace(/[^a-zA-Z0-9]/g, '_');

          json.forEach((row) => {
            const keys = Object.keys(row);
            
            const rawIdKey = keys.find(k => k === 'Employee No.' || k === 'Emp ID' || k === 'EMP ID' || k.toLowerCase().includes('ac-no') || k.toLowerCase().includes('employee no'));
            const dateTimeKey = keys.find(k => k === 'Date/Time' || k === 'DateTime' || k.toLowerCase().includes('date/time'));
            const dateKey = keys.find(k => k === 'Date');
            
            // Find all Time columns (Time.1, Time.2, etc. or just "Time")
            const timeKeys = keys.filter(k => k.toLowerCase().startsWith('time') || k.toLowerCase().includes('punch'));

            if (rawIdKey && (dateTimeKey || (dateKey && timeKeys.length > 0))) {
              const rawEmpIdInput = String(row[rawIdKey]).trim();
              const normInput = getNormalized(rawEmpIdInput);
              
              // FLEXIBLE MATCHING: Exact -> Lowercase -> Numeric part (handles 1257 vs EMP1257)
              let matchedId = employeeIdMap.get(normInput.original) || 
                              employeeIdMap.get(normInput.lowercase) || 
                              (normInput.numeric ? employeeIdMap.get(normInput.numeric) : undefined);

              // ONLY process if employee exists in directory
              if (!matchedId) {
                failedMatches.add(rawEmpIdInput);
                return;
              }

              const rawEmpId = matchedId;

              if (dateTimeKey) {
                const rawDT = row[dateTimeKey];
                let punchIso = '';
                if (typeof rawDT === 'number') {
                  const dateObj = new Date(Math.round((rawDT - 25569) * 864e5));
                  punchIso = dateObj.toISOString();
                } else if (typeof rawDT === 'string') {
                  const parsed = new Date(rawDT);
                  if (!isNaN(parsed.getTime())) {
                    punchIso = parsed.toISOString();
                  }
                }
                
                if (punchIso) {
                  finalNewPunchesRaw.push({
                    id: makePunchId(rawEmpId, punchIso),
                    employeeId: rawEmpId,
                    punchDatetime: punchIso,
                    importFormat: 'standard',
                    importId: batchId,
                    importDate: importDate,
                    fileName: file.name
                  });
                }
              } else if (dateKey) {
                let datePart = '';
                const rawDate = row[dateKey];
                if (typeof rawDate === 'number') {
                  const dateObj = new Date(Math.round((rawDate - 25569) * 864e5));
                  datePart = format(dateObj, 'yyyy-MM-dd');
                } else if (typeof rawDate === 'string') {
                  try {
                    const parsedDate = new Date(rawDate);
                    if (!isNaN(parsedDate.getTime())) {
                      datePart = format(parsedDate, 'yyyy-MM-dd');
                    }
                  } catch (e) {}
                }

                if (datePart) {
                  // Process all time columns for this row
                  timeKeys.forEach(tKey => {
                    const rawTime = row[tKey];
                    if (!rawTime) return;

                    let times: string[] = [];
                    if (typeof rawTime === 'string') {
                      // Split by comma or semicolon first to preserve AM/PM spaces
                      times = rawTime.split(/[,;]/).map(t => t.trim()).filter(Boolean);
                    } else if (typeof rawTime === 'number') {
                      times = [String(rawTime)];
                    }

                    times.forEach(tStr => {
                      let pIso = '';
                      if (isNaN(Number(tStr))) {
                        // It's a string time like "1:10 PM" or "13:10"
                        const parsed = new Date(`${datePart} ${tStr}`);
                        if (!isNaN(parsed.getTime())) pIso = parsed.toISOString();
                      } else {
                        // It's an Excel numeric time
                        const t = Number(tStr);
                        const hours = Math.floor(t * 24);
                        const minutes = Math.floor((t * 24 - hours) * 60);
                        const seconds = Math.floor(((t * 24 - hours) * 60 - minutes) * 60);
                        const parsed = new Date(`${datePart} ${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`);
                        if (!isNaN(parsed.getTime())) pIso = parsed.toISOString();
                      }
                      if (pIso) {
                        finalNewPunchesRaw.push({
                          id: makePunchId(rawEmpId, pIso),
                          employeeId: rawEmpId,
                          punchDatetime: pIso,
                          importFormat: 'multi-time',
                          importId: batchId,
                          importDate: importDate,
                          fileName: file.name
                        });
                      }
                    });
                  });
                }
              }
            }
          });

          if (finalNewPunchesRaw.length === 0) {
            toast.error("No punches found for existing employees in directory. Ensure Employee No. matches the Directory.");
            setStatus('error');
            setMessage("Import failed: No matching employees found.");
            return;
          }

          // Deduplicate new punches based on ID
          const uniqueNewPunchesMap = new Map();
          finalNewPunchesRaw.forEach(p => uniqueNewPunchesMap.set(p.id, p));
          const finalNewPunches = Array.from(uniqueNewPunchesMap.values());

          setMessage(`Saving ${finalNewPunches.length} punches to database...`);
          await setPunches(finalNewPunches, (msg) => setMessage(msg));
          
          setMessage('Finalizing import...');
          setCalculationSource('all');
          // Removed manual recalculate() as onSnapshot handles it more efficiently
          setStatus('success');
          setMessage(`Successfully imported ${finalNewPunches.length} records for matching employees.`);
          toast.success(`Successfully imported ${finalNewPunches.length} records.`);
        } else {
          // Roster Import
          const aoa = XLSX.utils.sheet_to_json(worksheet, { header: 1 }) as any[][];
          setMessage(`Processing horizontal matrix of ${aoa.length} rows...`);
          
          const rosterRecords = await processRosterUpload(aoa);
          setMessage(`Generated ${rosterRecords.length} normalized assignments...`);

          // Map shift codes to shift IDs if possible, or use standard mapping
          const newAssignments: ShiftAssignment[] = rosterRecords.map(r => {
            // Find shift in master data if possible
            let shiftId = '';
            const matchingShift = settings.shifts?.find(s => 
              s.name.toUpperCase() === r.shiftCode || 
              s.name.toUpperCase().includes(r.shiftCode) ||
              s.id === r.shiftCode ||
              (s.startTime === r.shiftIn && s.endTime === r.shiftOut)
            );

            if (matchingShift) {
              shiftId = matchingShift.id;
            } else if (r.shiftCode === 'DO' || r.shiftCode === 'OFF') {
              shiftId = 'OFF';
            } else if (r.shiftCode === 'G') {
              // Try to find Day Shift shift
              const dayShift = settings.shifts?.find(s => s.name.toUpperCase().includes('DAY SHIFT'));
              shiftId = dayShift ? dayShift.id : r.shiftCode;
            } else {
              // Try finding by name if the code matches ShiftMaster names in screenshot
              const commonNames: Record<string, string> = {
                'A': 'A Shift',
                'B': 'B Shift',
                'C': 'C Shift',
                'N': 'Night Shift',
                'D': 'Day Shift',
                'NIGHT': 'Night Shift',
                'DAY': 'Day Shift',
                'GSD': 'GSD Shift',
                'GSN': 'GSN Shift',
                'OFFICE': 'Office Shift'
              };
              const mappedName = commonNames[r.shiftCode] || r.shiftCode;
              const byName = settings.shifts?.find(s => s.name.toUpperCase() === mappedName.toUpperCase());
              shiftId = byName ? byName.id : (matchingShift ? matchingShift.id : r.shiftCode);
            }

            return {
              employeeId: r.employeeId,
              date: r.date,
              shiftId: shiftId
            };
          });

          if (newAssignments.length === 0) {
            throw new Error("No valid roster data extracted from sheet.");
          }

          setMessage(`Syncing ${newAssignments.length} roster assignments with database...`);
          await setShiftAssignments(newAssignments);
          
          setStatus('success');
          setMessage(`Successfully imported roster for ${newAssignments.length} employee-days.`);
          toast.success(`Roster Import Complete: ${newAssignments.length} assignments updated.`);
        }
      } catch (err: any) {
        setStatus('error');
        setMessage(err.message || 'Error processing file.');
      }
    };
    reader.onerror = () => {
      setStatus('error');
      setMessage('Error reading file.');
    };
    reader.readAsArrayBuffer(file);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-8">
          <div>
            <h2 className="text-2xl font-bold text-slate-900 tracking-tight">External Data Import</h2>
            <p className="text-slate-500 mt-1 text-sm">Synchronize biometric logs or shift rosters from Excel files.</p>
          </div>
          
          <div className="flex bg-slate-100 p-1 rounded-xl items-center">
            <button 
              onClick={() => { setImportType('punch'); setFile(null); setStatus('idle'); }}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-semibold uppercase tracking-tight transition-all ${importType === 'punch' ? 'bg-white text-indigo-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
            >
              <CalendarDays className="w-4 h-4" /> Punch Logs
            </button>
            <button 
              onClick={() => { setImportType('roster'); setFile(null); setStatus('idle'); }}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-semibold uppercase tracking-tight transition-all ${importType === 'roster' ? 'bg-white text-indigo-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
            >
              <ClipboardList className="w-4 h-4" /> Shift Roster
            </button>
          </div>
        </div>

        <div className="flex justify-between items-center mb-6">
          <div className="flex items-center gap-3">
             <div className="w-10 h-10 bg-indigo-50 rounded-xl flex items-center justify-center">
                {importType === 'punch' ? <Database className="text-indigo-600 w-5 h-5" /> : <CalendarDays className="text-indigo-600 w-5 h-5" />}
             </div>
             <div>
                <p className="text-sm font-bold text-slate-900 leading-none">{importType === 'punch' ? 'Biometric Punch Processing' : 'Master Roster Mapping'}</p>
                <p className="text-xs text-slate-500 mt-1 uppercase font-semibold tracking-normal">{importType === 'punch' ? 'Source: Device Logs' : 'Source: Horizontal Matrix'}</p>
             </div>
          </div>
          <button 
            onClick={downloadSample}
            className="flex items-center gap-2 px-4 py-2 bg-slate-50 text-slate-700 border border-slate-200 rounded-lg text-xs font-bold hover:bg-slate-100 transition-all shadow-sm"
          >
            <Download className="w-4 h-4" /> Download {importType === 'punch' ? 'Punch' : 'Roster'} Format
          </button>
        </div>

        {quotaExceeded && (
          <div className="p-4 bg-amber-50 border border-amber-200 rounded-xl flex gap-3 text-amber-800 mb-6">
            <AlertCircle className="w-5 h-5 flex-shrink-0" />
            <div className="text-xs">
              <span className="font-bold block">Database Write-Lock Active</span>
              You have reached the free tier write limit. You can still view and export data, but importing new records is disabled until the daily reset.
            </div>
          </div>
        )}

        <div 
          className={`border-2 border-dashed rounded-xl p-10 text-center transition-colors ${
            quotaExceeded ? 'border-slate-200 bg-slate-50 cursor-not-allowed opacity-60' :
            isDragging ? 'border-indigo-500 bg-indigo-50' : 'border-slate-300 hover:border-slate-400 bg-slate-50'
          }`}
          onDragOver={(e) => { 
            if (quotaExceeded) return;
            e.preventDefault(); 
            setIsDragging(true); 
          }}
          onDragLeave={() => setIsDragging(false)}
          onDrop={(e) => {
            if (quotaExceeded) return;
            e.preventDefault();
            setIsDragging(false);
            if (e.dataTransfer.files && e.dataTransfer.files[0]) {
              setFile(e.dataTransfer.files[0]);
              setStatus('idle');
            }
          }}
        >
          <UploadCloud className="w-12 h-12 text-indigo-400 mx-auto mb-4" />
          <h3 className="text-lg font-bold text-slate-900 mb-1">
            {file ? file.name : `Drag & drop ${importType === 'punch' ? 'Punch' : 'Roster'} Excel file here`}
          </h3>
          <p className="text-sm text-slate-500 mb-6 font-medium">
            {file ? `${(file.size / 1024).toFixed(1)} KB` : 'or click to browse from your computer'}
          </p>
          
          <input 
            type="file" 
            id="file-upload" 
            className="hidden" 
            accept=".xlsx, .xls, .csv" 
            onChange={handleFileChange}
            disabled={quotaExceeded}
          />
          <label 
            htmlFor="file-upload" 
            className={`inline-flex items-center justify-center px-6 py-2.5 bg-indigo-600 text-white rounded-xl text-xs font-semibold uppercase tracking-normal shadow-lg shadow-indigo-100 transition-all ${quotaExceeded ? 'opacity-50 cursor-not-allowed bg-slate-400' : 'hover:bg-indigo-700 cursor-pointer active:scale-95'}`}
          >
            {file ? 'Change File (Loaded)' : 'Choose File (Load)'}
          </label>
        </div>

        {status !== 'idle' && (
          <div className={`mt-6 p-4 rounded-xl flex items-center gap-3 ${
            status === 'processing' ? 'bg-indigo-50 text-indigo-800 border border-indigo-100' :
            status === 'success' ? 'bg-emerald-50 text-emerald-800 border border-emerald-100' :
            'bg-rose-50 text-rose-800 border border-rose-100'
          }`}>
            {status === 'success' && <CheckCircle2 className="w-5 h-5 flex-shrink-0" />}
            {status === 'error' && <AlertCircle className="w-5 h-5 flex-shrink-0" />}
            {status === 'processing' && <div className="w-5 h-5 border-2 border-indigo-600 border-t-transparent rounded-full animate-spin flex-shrink-0" />}
            <span className="text-xs font-bold uppercase tracking-tight">{message}</span>
          </div>
        )}

        <div className="flex justify-end gap-3 pt-6 mt-6 border-t border-slate-100">
          <button 
            className="px-6 py-2.5 text-xs font-semibold text-slate-500 hover:text-slate-700 hover:bg-slate-50 rounded-xl transition-all uppercase tracking-normal"
            onClick={() => { setFile(null); setStatus('idle'); }}
            disabled={status === 'processing'}
          >
            Cancel
          </button>
          <button 
            onClick={processFile}
            disabled={!file || status === 'processing' || status === 'success' || quotaExceeded}
            className="px-8 py-2.5 bg-slate-900 text-white rounded-xl text-xs font-semibold uppercase tracking-normal hover:bg-slate-800 transition-all disabled:opacity-30 disabled:cursor-not-allowed shadow-sm shadow-slate-200"
          >
            {quotaExceeded ? 'Quota Locked' : status === 'processing' ? 'Uploading...' : `Upload & Process ${importType === 'punch' ? 'Punches' : 'Roster'}`}
          </button>
        </div>
        
        {status === 'success' && (
           <div className="flex justify-end mt-4">
             <button onClick={() => navigate('/attendance')} className="flex items-center gap-2 px-6 py-3 bg-emerald-600 text-white rounded-xl text-xs font-semibold uppercase tracking-normal hover:bg-emerald-700 shadow-sm shadow-emerald-100 transition-all">
               <CheckCircle2 className="w-4 h-4" /> Go to Attendance
             </button>
           </div>
        )}
      </div>

      {importType === 'punch' && (
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-slate-100 rounded-lg">
                <History className="w-5 h-5 text-slate-500" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-slate-800 tracking-tight">Import History</h3>
                <p className="text-xs text-slate-500">Manage your imported data batches</p>
              </div>
            </div>
            <div className="flex bg-slate-100 p-1 rounded-lg">
              <button 
                onClick={() => setViewMode('sessions')}
                className={`px-3 py-1.5 rounded-md text-xs font-bold transition-all ${viewMode === 'sessions' ? 'bg-white text-indigo-600 shadow-sm' : 'text-slate-500'}`}
              >
                Sessions
              </button>
              <button 
                onClick={() => setViewMode('recent')}
                className={`px-3 py-1.5 rounded-md text-xs font-bold transition-all ${viewMode === 'recent' ? 'bg-white text-indigo-600 shadow-sm' : 'text-slate-500'}`}
              >
                Recent Records
              </button>
            </div>
          </div>

          <div className="mb-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex flex-wrap items-center gap-3">
              {orphansCount > 0 && (
                <div className="flex items-center gap-2 px-3 py-1 bg-amber-50 border border-amber-200 rounded-lg text-xs font-bold text-amber-700 animate-pulse">
                  <AlertCircle className="w-3 h-3 text-amber-500" />
                  <span>Found {orphansCount} legacy records without session IDs</span>
                  <button 
                    onClick={async () => {
                      const orphans = punches.filter(p => !p.importId);
                      if (window.confirm(`Delete all ${orphans.length} legacy records? Records within named sessions will NOT be affected.`)) {
                        setStatus('processing');
                        setMessage(`Cleaning ${orphans.length} legacy records...`);
                        try {
                          const { db } = await import('../lib/firebase');
                          const { doc, writeBatch } = await import('firebase/firestore');
                          
                          const batchSize = 500;
                          for (let i = 0; i < orphans.length; i += batchSize) {
                            const chunk = orphans.slice(i, i + batchSize);
                            const b = writeBatch(db);
                            chunk.forEach(p => b.delete(doc(db, 'punches', p.id)));
                            await b.commit();
                          }
                          window.location.reload();
                        } catch (e: any) {
                          setStatus('error');
                          setMessage(e.message);
                        }
                      }
                    } }
                    className="ml-2 underline hover:text-amber-900"
                  >
                    Clear Now
                  </button>
                </div>
              )}
              {viewMode === 'sessions' && (
                <div className="flex items-center gap-2 bg-slate-50 p-1 rounded-lg border border-slate-200">
                  <Filter className="w-3 h-3 text-slate-400 ml-1.5" />
                  <input 
                    type="date" 
                    value={sessionStartDate}
                    onChange={(e) => setSessionStartDate(e.target.value)}
                    className="bg-transparent text-xs font-bold text-slate-600 focus:outline-none"
                  />
                  <span className="text-xs text-slate-300">to</span>
                  <input 
                    type="date" 
                    value={sessionEndDate}
                    onChange={(e) => setSessionEndDate(e.target.value)}
                    className="bg-transparent text-xs font-bold text-slate-600 focus:outline-none"
                  />
                  {(sessionStartDate || sessionEndDate) && (
                    <button 
                      onClick={() => { setSessionStartDate(''); setSessionEndDate(''); }}
                      className="p-1 hover:bg-slate-200 rounded text-slate-400"
                    >
                      <Trash2 className="w-2.5 h-2.5" />
                    </button>
                  )}
                </div>
              )}
              {viewMode === 'recent' && (
                <div className="flex items-center gap-3">
                  <div className="relative">
                    <input 
                      type="text" 
                      placeholder="Search Emp ID..." 
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-3 pr-8 py-1.5 border border-slate-200 rounded-lg text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500 w-32 sm:w-40 bg-slate-50"
                    />
                    {searchTerm && <button onClick={() => setSearchTerm('')} className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"><Trash2 className="w-3 h-3" /></button>}
                  </div>
                  <label className="flex items-center gap-2 cursor-pointer group">
                    <div 
                      onClick={() => setShowOnlyRegistered(!showOnlyRegistered)}
                      className={cn(
                        "w-8 h-4 rounded-full transition-colors relative",
                        showOnlyRegistered ? "bg-indigo-600" : "bg-slate-200"
                      )}
                    >
                      <div className={cn(
                        "absolute top-0.5 left-0.5 w-3 h-3 bg-white rounded-full transition-transform",
                        showOnlyRegistered ? "translate-x-4" : ""
                      )} />
                    </div>
                    <span className="text-xs font-semibold text-slate-500 uppercase tracking-tight group-hover:text-indigo-600 transition-colors">
                      Directory Only
                    </span>
                  </label>
                </div>
              )}
              <div className="text-xs text-slate-400 font-medium italic">
                Total {punches.length} records in database
              </div>
            </div>
            <button 
              onClick={() => {
                if (quotaExceeded) return;
                setIsConfirmingPurge(true);
              }}
              disabled={quotaExceeded}
              className="flex items-center gap-2 px-3 py-1.5 bg-red-50 text-red-600 border border-red-100 rounded-lg text-xs font-bold hover:bg-red-100 transition-all shadow-sm disabled:opacity-50"
            >
              <Database className="w-3.5 h-3.5" /> Purge Everything
            </button>
          </div>

          <div className="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden min-h-[100px]">
            {viewMode === 'sessions' ? (
              sessions.length > 0 ? (
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse table-fixed">
                    <thead className="bg-slate-50">
                      <tr className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                        <th className="px-6 py-3 w-48">Import Date</th>
                        <th className="px-6 py-3">Format</th>
                        <th className="px-6 py-3 w-32">Record Count</th>
                        <th className="px-6 py-3 w-20 text-right">Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 text-xs">
                      {sessions.map((s) => (
                        <tr key={s.id} className="hover:bg-slate-50 transition-colors">
                          <td className="px-6 py-4">
                            <div className="flex flex-col">
                              <span className="text-slate-900 font-bold truncate max-w-[150px]" title={s.fileName}>{s.fileName}</span>
                              <span className="text-slate-500 font-mono text-xs mt-0.5">
                                {format(parseISO(s.date), 'yyyy-MM-dd hh:mm a')}
                              </span>
                            </div>
                          </td>
                          <td className="px-6 py-4">
                            <span className={`px-2 py-0.5 rounded text-xs font-bold uppercase ${s.format === 'multi-time' ? 'bg-amber-50 text-amber-600' : 'bg-indigo-50 text-indigo-600'}`}>
                              {s.format || 'Standard'}
                            </span>
                          </td>
                          <td className="px-6 py-3 font-bold text-slate-900">{s.count} records</td>
                          <td className="px-6 py-3 text-right">
                            <div className="flex items-center justify-end gap-2">
                              <button 
                                onClick={() => {
                                  const batchPunches = punches.filter(p => p.importId === s.id);
                                  const ws = XLSX.utils.json_to_sheet(batchPunches);
                                  const wb = XLSX.utils.book_new();
                                  XLSX.utils.book_append_sheet(wb, ws, "Punches");
                                  XLSX.writeFile(wb, `Import_Batch_${format(parseISO(s.date), 'yyyyMMdd_HHmm')}.xlsx`);
                                }}
                                className="p-1.5 bg-indigo-50 text-indigo-600 rounded-md hover:bg-indigo-100 transition-colors"
                                title="Export Batch"
                              >
                                <Download className="w-3.5 h-3.5" />
                              </button>
                              <button 
                                onClick={async () => {
                                  if (window.confirm(`Are you sure you want to delete this entire import session (${s.count} records)?\n\nThis will permanently purge all biometric logs from this specific batch.`)) {
                                    setStatus('processing');
                                    setMessage(`Deleting session batch (${s.count} records)...`);
                                    try {
                                      await deletePunchBatch(s.id);
                                      setStatus('success');
                                      setMessage(`Batch deleted successfully.`);
                                      // Reset status to idle after a delay
                                      setTimeout(() => setStatus('idle'), 3000);
                                    } catch (e: any) {
                                      setStatus('error');
                                      setMessage(e.message);
                                    }
                                  }
                                }}
                                className="p-1.5 bg-red-50 text-red-600 rounded-md hover:bg-red-100 transition-colors"
                                title="Delete Batch"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center py-12 text-slate-400">
                  <History className="w-8 h-8 opacity-20 mb-3" />
                  <p className="text-sm font-medium">No import sessions found.</p>
                </div>
              )
            ) : sortedPunches.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse table-fixed">
                  <thead className="bg-slate-50">
                    <tr className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                      <th className="px-6 py-3 w-32">Emp ID</th>
                      <th className="px-6 py-3">Employee Name</th>
                      <th className="px-6 py-3 w-48">Datetime</th>
                      <th className="px-6 py-3 w-28">Format</th>
                      <th className="px-6 py-3 w-20 text-right">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-xs">
                    {sortedPunches.map((p) => {
                      const emp = employees.find(e => e.id === p.employeeId);
                      return (
                        <tr key={p.id} className="hover:bg-slate-50 transition-colors">
                          <td className="px-6 py-3 font-mono font-bold text-slate-600">{p.employeeId}</td>
                          <td className="px-6 py-3 font-semibold text-slate-900 truncate">{emp?.name || '--'}</td>
                          <td className="px-6 py-3 text-slate-500 font-mono">{format(parseISO(p.punchDatetime), 'yyyy-MM-dd hh:mm:ss a')}</td>
                          <td className="px-6 py-3">
                            <span className={`px-2 py-0.5 rounded text-xs font-bold uppercase ${p.importFormat === 'multi-time' ? 'bg-amber-50 text-amber-600' : 'bg-indigo-50 text-indigo-600'}`}>
                              {p.importFormat || 'Standard'}
                            </span>
                          </td>
                          <td className="px-6 py-3 text-right">
                            <button 
                              onClick={async () => {
                                if (window.confirm(`Permanently delete this individual punch log for ${p.employeeId}?`)) {
                                  try {
                                    await deletePunch(p.id);
                                  } catch (e: any) {
                                    alert(`Error: ${e.message}`);
                                  }
                                }
                              }}
                              className="p-1.5 hover:bg-red-50 hover:text-red-500 transition-colors text-slate-400 rounded-md"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center py-12 text-slate-400">
                <History className="w-8 h-8 opacity-20 mb-3" />
                <p className="text-sm font-medium">No punch records found.</p>
              </div>
            )}
          </div>
        </div>
      )}

      {importType === 'roster' && (
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm space-y-6">
           <div className="flex items-center gap-3">
              <div className="p-2 bg-indigo-50 rounded-lg">
                <ClipboardList className="w-5 h-5 text-indigo-600" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-slate-800 tracking-tight">Roster Mapping Rules</h3>
                <p className="text-xs text-slate-500">How shift codes in the Excel mapping are processed</p>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
               {[
                 { code: 'A', label: 'A Shift', time: '06:00 - 14:00', icon: '🌅' },
                 { code: 'B', label: 'B Shift', time: '14:00 - 22:00', icon: '🌇' },
                 { code: 'C', label: 'C Shift', time: '22:00 - 06:00', icon: '🌙', cross: true },
                 { code: 'DAY', label: 'Day Shift', time: '08:00 - 20:00', icon: '☀️' },
                 { code: 'NIGHT', label: 'Night Shift', time: '20:00 - 08:00', icon: '🌌', cross: true },
                 { code: 'GSD', label: 'GSD Shift', time: '06:00 - 18:00', icon: '☀️' },
                 { code: 'GSN', label: 'GSN Shift', time: '18:00 - 06:00', icon: '🌙', cross: true },
                 { code: 'DO', label: 'Day Off', time: 'No Duty', icon: '🏠' }
               ].map(rule => (
                 <div key={rule.code} className="p-4 bg-slate-50 border border-slate-100 rounded-xl flex items-center gap-4">
                    <div className="text-2xl">{rule.icon}</div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-slate-900">{rule.code}</span>
                        <span className="text-xs font-bold text-slate-400 uppercase tracking-normal">{rule.label}</span>
                      </div>
                      <p className="text-xs font-bold text-indigo-600">{rule.time}</p>
                      {rule.cross && <p className="text-xs text-rose-500 font-bold uppercase mt-0.5">Crossover Enabled</p>}
                    </div>
                 </div>
               ))}
            </div>

            <div className="p-4 bg-indigo-50/30 border border-indigo-100 rounded-xl">
               <p className="text-xs font-medium text-indigo-900 flex items-center gap-2">
                 <AlertCircle className="w-4 h-4" />
                 Processing Logic: The system uses an Upsert mechanism. If an assignment for the same Employee & Date exists, it will be overwritten.
               </p>
            </div>
        </div>
      )}

      {/* Verification Dialog Overlay */}
      {isConfirmingPurge && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg shadow-md border border-slate-200 max-w-md w-full overflow-hidden animate-in zoom-in-95 duration-200">
            <div className="p-6">
              <div className="flex items-center gap-3 mb-4 text-red-600">
                <AlertCircle className="w-6 h-6" />
                <h4 className="text-lg font-bold">Destroy All Attendance Data</h4>
              </div>
              <p className="text-sm text-slate-600 leading-relaxed mb-6">
                You are about to wipe <span className="font-bold text-red-600 uppercase">all {punches.length} records</span> from the database. This action is final and cannot be undone.
              </p>
              
              <div className="space-y-3">
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-normal">
                  Type <span className="text-red-600 select-all underline decoration-red-200">DELETE</span> to authorize purge
                </label>
                <input 
                  type="text"
                  autoFocus
                  placeholder="Type DELETE"
                  value={purgeConfirmationInput}
                  onChange={(e) => setPurgeConfirmationInput(e.target.value)}
                  className="w-full px-4 py-3 bg-slate-50 border-2 border-slate-100 rounded-xl text-center font-semibold tracking-normal text-slate-900 focus:border-red-500 focus:bg-white outline-none transition-all placeholder:text-slate-300 placeholder:font-normal placeholder:tracking-normal"
                />
              </div>
            </div>
            <div className="bg-slate-50 p-4 border-t border-slate-100 flex gap-3">
              <button 
                onClick={() => {
                  setIsConfirmingPurge(false);
                  setPurgeConfirmationInput('');
                }}
                className="flex-1 px-4 py-2.5 bg-white border border-slate-200 text-slate-600 rounded-xl text-sm font-bold hover:bg-slate-100 transition-colors"
              >
                Cancel
              </button>
              <button 
                onClick={async () => {
                  if (purgeConfirmationInput !== 'DELETE') return;
                  setIsConfirmingPurge(false);
                  setPurgeConfirmationInput('');
                  setStatus('processing');
                  setMessage('Starting full database purge...');
                  try {
                    await clearPunches((msg) => setMessage(msg));
                    setStatus('success');
                    setMessage('All punch records deleted successfully.');
                  } catch (e: any) {
                    setStatus('error');
                    setMessage(e.message);
                  }
                }}
                disabled={purgeConfirmationInput !== 'DELETE'}
                className="flex-[2] px-4 py-2.5 bg-red-600 text-white rounded-xl text-sm font-bold hover:bg-red-700 transition-all disabled:opacity-30 disabled:cursor-not-allowed shadow-lg shadow-red-200"
              >
                Authorize System Purge
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
