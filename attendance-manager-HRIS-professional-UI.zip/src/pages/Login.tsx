import React, { useState } from 'react';
import { LogIn, Shield, CheckCircle2, ArrowRight, Github, Mail, Lock, Key, Loader2 } from 'lucide-react';
import { signInWithGoogle as googleSignInFn, emailSignIn } from '../lib/firebase';
import { motion, AnimatePresence } from 'motion/react';
import { toast } from 'sonner';
import { useNavigate, Link } from 'react-router-dom';
import { useAppStore } from '../store';

type LoginStep = 'credentials' | 'otp';

const ADMIN_EMAILS = ['hr.sandiprajak466@gmail.com', 'shauryahr466@gmail.com'];

export function Login() {
  const { setIsOtpVerified } = useAppStore();
  const [step, setStep] = useState<LoginStep>('credentials');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [otp, setOtp] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();

  const isUserAdmin = (emailAddress: string) => {
    return ADMIN_EMAILS.some(adminEmail => emailAddress.toLowerCase() === adminEmail.toLowerCase());
  };

  const handleGoogleLogin = async () => {
    setIsLoading(true);
    try {
      const result = await googleSignInFn();
      if (result) {
        if (isUserAdmin(result.user.email || '')) {
          setIsOtpVerified(true);
          toast.success('Admin access granted');
          return;
        }
        await sendOtp(result.user.email!);
      }
    } catch (error: any) {
      console.error("Login failed:", error);
      if (error.code === 'auth/network-request-failed') {
        toast.error('Network request failed. Please check your internet connection and ensure the domain is authorized in Firebase Console.', {
          duration: 10000,
        });
      } else {
        toast.error(error.message || "Google Sign-In failed");
      }
      setIsLoading(false);
    }
  };

  const handleCredentialsLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    try {
      await emailSignIn(email, password);
      if (isUserAdmin(email)) {
        setIsOtpVerified(true);
        toast.success('Admin access granted');
        return;
      }
      await sendOtp(email);
    } catch (error: any) {
      console.error("Login failed:", error);
      if (error.code === 'auth/operation-not-allowed') {
        toast.error('Email/Password login is not enabled in Firebase. Please enable it in the Firebase Console.', {
          duration: 10000,
        });
      } else if (error.code === 'auth/network-request-failed') {
        toast.error('Network request failed. Please check your internet connection or try opening the app in a new tab.', {
          duration: 10000,
        });
      } else {
        toast.error(error.message || "Invalid credentials");
      }
      setIsLoading(false);
    }
  };

  const sendOtp = async (targetEmail: string) => {
    try {
      const response = await fetch('/api/auth/send-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: targetEmail }),
      });
      const data = await response.json();
      if (response.ok) {
        setEmail(targetEmail);
        setStep('otp');
        toast.success('Verification code sent to your email');
        if (data.debugOtp) {
          console.log(`[DEBUG] OTP: ${data.debugOtp}`);
          toast.info(`Debug OTP (Logged to console): ${data.debugOtp}`);
        }
      } else {
        throw new Error(data.error);
      }
    } catch (error: any) {
      toast.error(error.message || 'Failed to send OTP');
    } finally {
      setIsLoading(false);
    }
  };

  const handleVerifyOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    try {
      const response = await fetch('/api/auth/verify-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, code: otp }),
      });
      if (response.ok) {
        setIsOtpVerified(true);
        toast.success('Authentication successful');
        // The auth state change listener in App.tsx will handle the redirect
      } else {
        const data = await response.json();
        throw new Error(data.error);
      }
    } catch (error: any) {
      toast.error(error.message || 'Invalid verification code');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#0F172A] flex items-center justify-center p-6 relative overflow-hidden">
      {/* Decorative background elements */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none">
        <div className="absolute -top-[10%] -left-[10%] w-[40%] h-[40%] bg-indigo-500/10 rounded-full blur-[120px]" />
        <div className="absolute -bottom-[10%] -right-[10%] w-[40%] h-[40%] bg-blue-500/10 rounded-full blur-[120px]" />
      </div>

      <div className="max-w-5xl w-full grid grid-cols-1 md:grid-cols-2 bg-white/5 backdrop-blur-xl rounded-[2.5rem] border border-white/10 shadow-md overflow-hidden relative z-10">
        
        {/* Left Side: Branding & Features */}
        <div className="hidden md:flex flex-col justify-between p-12 bg-gradient-to-br from-indigo-600 to-blue-700 text-white">
          <div className="space-y-6">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-white/20 backdrop-blur-md rounded-xl flex items-center justify-center">
                <Shield className="w-6 h-6 text-white" />
              </div>
              <span className="text-xl font-semibold tracking-tight">CONTRACTOR HRIS</span>
            </div>
            
            <div className="space-y-4">
              <h2 className="text-2xl font-semibold leading-tight tracking-tighter">
                Manage your workforce with <span className="text-indigo-200 underline decoration-indigo-300/30">precision</span>.
              </h2>
              <p className="text-indigo-100 text-lg font-medium leading-relaxed">
                Enterprise-grade attendance tracking, shift management, and automated reporting in one unified platform.
              </p>
            </div>

            <div className="space-y-3 pt-6">
              {[
                "Real-time Shift Tracking",
                "Automated Overtime Calculation",
                "Cloud-Powered Data Persistence",
                "Advanced Audit Logging"
              ].map((feature, i) => (
                <div key={i} className="flex items-center gap-3 text-sm font-bold text-indigo-50">
                  <CheckCircle2 className="w-5 h-5 text-indigo-300" />
                  {feature}
                </div>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-4 pt-8">
             <div className="flex -space-x-3">
               {[1,2,3,4].map(i => (
                 <img key={i} src={`https://api.dicebear.com/7.x/avataaars/svg?seed=user${i}`} className="w-8 h-8 rounded-full border-2 border-indigo-600 bg-indigo-500" alt="user" />
               ))}
             </div>
             <p className="text-xs font-bold text-indigo-200">Trusted by over 500+ managers</p>
          </div>
        </div>

        {/* Right Side: Login Action */}
        <div className="p-5 md:p-16 flex flex-col justify-center bg-white">
          <AnimatePresence mode="wait">
            {step === 'credentials' ? (
              <motion.div 
                key="credentials"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="max-w-sm mx-auto w-full space-y-8"
              >
                <div className="space-y-3">
                  <h3 className="text-3xl font-semibold text-slate-900 tracking-tight">Welcome Back</h3>
                  <p className="text-slate-500 text-sm font-medium">Please sign in to access your dashboard.</p>
                </div>

                <form onSubmit={handleCredentialsLogin} className="space-y-4">
                  <div className="space-y-2">
                    <label className="text-xs font-semibold text-slate-400 uppercase tracking-normal ml-1">Email Address</label>
                    <div className="relative">
                      <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                      <input 
                        type="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="w-full pl-12 pr-4 py-4 bg-slate-50 border border-slate-100 rounded-lg text-sm font-bold focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
                        placeholder="name@company.com"
                        required
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-xs font-semibold text-slate-400 uppercase tracking-normal ml-1">Password</label>
                    <div className="relative">
                      <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                      <input 
                        type="password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        className="w-full pl-12 pr-4 py-4 bg-slate-50 border border-slate-100 rounded-lg text-sm font-bold focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
                        placeholder="••••••••"
                        required
                      />
                    </div>
                  </div>

                  <button 
                    type="submit"
                    disabled={isLoading}
                    className="w-full flex items-center justify-center gap-3 py-4 bg-slate-900 text-white rounded-lg font-bold hover:bg-slate-800 transition-all shadow-sm shadow-slate-200 disabled:opacity-70 group"
                  >
                    {isLoading ? <Loader2 className="w-5 h-5 animate-spin" /> : <>Sign In <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" /></>}
                  </button>
                </form>

                <div className="relative flex items-center py-4">
                  <div className="flex-grow border-t border-slate-100"></div>
                  <span className="flex-shrink mx-4 text-xs font-semibold text-slate-300 uppercase tracking-normal">Or continue with</span>
                  <div className="flex-grow border-t border-slate-100"></div>
                </div>

                <button 
                  onClick={handleGoogleLogin}
                  disabled={isLoading}
                  className="w-full flex items-center justify-center gap-4 px-6 py-4 bg-white border border-slate-200 text-slate-600 rounded-lg font-bold hover:bg-slate-50 transition-all shadow-sm active:scale-[0.98] disabled:opacity-70"
                >
                  <img src="https://www.google.com/favicon.ico" className="w-5 h-5" alt="Google" />
                  Google Account
                </button>

                <div className="text-center pt-4">
                  <p className="text-sm font-bold text-slate-400">
                    Don't have an account? <Link to="/signup" className="text-indigo-600 hover:underline">Sign Up</Link>
                  </p>
                </div>
              </motion.div>
            ) : (
              <motion.div 
                key="otp"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="max-w-sm mx-auto w-full space-y-8"
              >
                <div className="space-y-3 text-center">
                  <div className="w-16 h-16 bg-indigo-50 rounded-full flex items-center justify-center mx-auto mb-6">
                    <Key className="w-8 h-8 text-indigo-600" />
                  </div>
                  <h3 className="text-3xl font-semibold text-slate-900 tracking-tight">Verify Identity</h3>
                  <p className="text-slate-500 text-sm font-medium">We've sent a 6-digit code to <span className="text-indigo-600 font-bold">{email}</span></p>
                </div>

                <form onSubmit={handleVerifyOtp} className="space-y-6">
                  <div className="space-y-2">
                    <label className="text-xs font-semibold text-slate-400 uppercase tracking-normal ml-1">Verification Code</label>
                    <input 
                      type="text"
                      maxLength={6}
                      value={otp}
                      onChange={(e) => setOtp(e.target.value.replace(/\D/g, ''))}
                      className="w-full px-4 py-6 bg-slate-50 border border-slate-100 rounded-lg text-3xl font-semibold text-center tracking-[0.5em] focus:ring-2 focus:ring-indigo-500 outline-none transition-all placeholder:text-slate-200"
                      placeholder="000000"
                      required
                    />
                  </div>

                  <button 
                    type="submit"
                    disabled={isLoading || otp.length !== 6}
                    className="w-full flex items-center justify-center gap-3 py-4 bg-slate-900 text-white rounded-lg font-bold hover:bg-slate-800 transition-all shadow-sm shadow-slate-200 disabled:opacity-70 group"
                  >
                    {isLoading ? <Loader2 className="w-5 h-5 animate-spin" /> : <>Verify & Complete <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" /></>}
                  </button>

                  <button 
                    type="button"
                    onClick={() => setStep('credentials')}
                    className="w-full text-sm font-bold text-slate-400 hover:text-slate-600 transition-colors"
                  >
                    Back to login
                  </button>
                </form>
              </motion.div>
            )}
          </AnimatePresence>

          <div className="pt-8 text-center border-t border-slate-100 mt-12">
            <div className="flex items-center justify-center gap-2 mb-4">
              <Shield className="w-3 h-3 text-emerald-500" />
              <span className="text-xs font-semibold text-emerald-600 uppercase tracking-wide">Authorized Access Only</span>
            </div>
            <p className="text-xs font-semibold text-slate-400 uppercase tracking-normal">
              Authorized Administrators:
            </p>
            <p className="text-xs font-bold text-indigo-600 mt-1">
              {ADMIN_EMAILS.join(' • ')}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

