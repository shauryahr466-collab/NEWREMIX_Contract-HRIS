import React, { useMemo, useState } from 'react';
import { useAppStore } from '../store';
import { format, parseISO, isWithinInterval } from 'date-fns';
import { 
  Clock, Search, CheckCircle2, AlertCircle, Download, 
  RefreshCw, Plus, Save, Eye, Edit2, CheckCircle, XCircle, Calendar, Trash2
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { toast } from 'sonner';
import * as XLSX from 'xlsx';
import { OTAuditLog } from '../components/OTAuditLog';
import { OvertimeRecord } from '../types';

export default function Overtime() {
  const { 
    overtimeRecords, employees, processedData, settings,
    updateOvertime, addOvertime, deleteOvertime, user, openEmployeeProfile, globalSearchTerm 
  } = useAppStore();
  
  const [searchTerm, setSearchTerm] = useState('');
  const activeSearch = searchTerm || globalSearchTerm;
  const [statusFilter, setStatusFilter] = useState<'All' | 'Pending' | 'Approved' | 'Rejected'>('All');
  const [designationFilter, setDesignationFilter] = useState<string>('All');
  const [contractorFilter, setContractorFilter] = useState<string>('All');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [selectedRecord, setSelectedRecord] = useState<OvertimeRecord | null>(null);
  const [dateRange, setDateRange] = useState({
    start: format(new Date(), 'yyyy-MM-01'),
    end: format(new Date(), 'yyyy-MM-dd')
  });

  const [formData, setFormData] = useState({
    employeeId: '',
    date: format(new Date(), 'yyyy-MM-dd'),
    supervisorOtHours: 0,
    otStartTime: '',
    otEndTime: '',
    type: 'Regular' as 'Regular' | 'Holiday' | 'Weekly Off',
    remarks: ''
  });

  const [selectedIds, setSelectedIds] = useState<string[]>([]);

  const handleSelect = (id: string) => {
    setSelectedIds(prev => prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]);
  };

  const handleBulkDelete = async () => {
    if (selectedIds.length === 0) return;
    if (!window.confirm(`Are you sure you want to delete ${selectedIds.length} selected records?`)) return;

    const tId = toast.loading('Deleting records...');
    try {
      for (const id of selectedIds) {
        await deleteOvertime(id);
      }
      setSelectedIds([]);
      toast.success(`Successfully deleted ${selectedIds.length} records`, { id: tId });
    } catch (e) {
      toast.error('Bulk delete failed', { id: tId });
    }
  };

  const filteredRecords = useMemo(() => {
    return overtimeRecords.filter(record => {
      const emp = employees.find(e => e.id === record.employeeId);
      const matchesSearch = !activeSearch || 
        emp?.name.toLowerCase().includes(activeSearch.toLowerCase()) || 
        record.employeeId.toLowerCase().includes(activeSearch.toLowerCase()) ||
        emp?.designation?.toLowerCase().includes(activeSearch.toLowerCase());
      const matchesStatus = statusFilter === 'All' || record.status === statusFilter;
      const matchesDesignation = designationFilter === 'All' || emp?.designation === designationFilter;
      const matchesContractor = contractorFilter === 'All' || emp?.contractorName === contractorFilter;
      const matchesDate = isWithinInterval(parseISO(record.date), {
        start: parseISO(dateRange.start),
        end: parseISO(dateRange.end)
      });
      return matchesSearch && matchesStatus && matchesDate && matchesDesignation && matchesContractor;
    }).sort((a, b) => a.date.localeCompare(b.date));
  }, [overtimeRecords, employees, activeSearch, statusFilter, dateRange, designationFilter, contractorFilter]);

  const stats = useMemo(() => ({
    total: overtimeRecords.length,
    pending: overtimeRecords.filter(r => r.status === 'Pending').length,
    approved: overtimeRecords.filter(r => r.status === 'Approved').length,
    totalHours: overtimeRecords.reduce((acc, curr) => acc + (Number(curr.hours) || 0), 0)
  }), [overtimeRecords]);

  const handleSyncAttendance = async () => {
    toast.loading('Syncing attendance data...', { id: 'sync' });
    try {
      let added = 0;
      let updated = 0;

      for (const att of processedData) {
        // Only sync records within selected date range
        if (!isWithinInterval(parseISO(att.date), {
          start: parseISO(dateRange.start),
          end: parseISO(dateRange.end)
        })) continue;

        const emp = employees.find(e => e.id === att.employeeId);
        const standardDutyHours = Number(emp?.targetWorkingHours) || Number(att.expectedHours) || 8;
        const workingHours = Number(att.workingHours) || 0;
        const bioOtHours = Math.max(0, workingHours - standardDutyHours);
        
        // Only create records for meaningful entries (Bio OT > 0 or Status Present)
        if (bioOtHours <= 0 && att.status !== 'Present') continue;

        const existing = overtimeRecords.find(r => r.employeeId === att.employeeId && r.date === att.date);
        
        if (existing) {
          // Update Bio OT if changed
          if (existing.bioOtHours !== bioOtHours || existing.standardDutyHours !== standardDutyHours) {
            const supOt = Number(existing.supervisorOtHours) || 0;
            const finalOtEligible = Math.min(bioOtHours, supOt);
            const hrSaving = Math.max(0, bioOtHours - finalOtEligible);
            await updateOvertime(existing.id, {
              bioOtHours: Number(bioOtHours.toFixed(2)),
              standardDutyHours: Number(standardDutyHours.toFixed(2)),
              hours: Number(finalOtEligible.toFixed(2)),
              hrSaving: Number(hrSaving.toFixed(2))
            });
            updated++;
          }
        } else {
          // Create new record
          const supervisorOtHours = 0; // Default
          const finalOtEligible = Math.min(bioOtHours, supervisorOtHours);
          const hrSaving = Math.max(0, bioOtHours - finalOtEligible);

          await addOvertime({
            employeeId: att.employeeId,
            date: att.date,
            bioOtHours: Number(bioOtHours.toFixed(2)),
            supervisorOtHours,
            standardDutyHours: Number(standardDutyHours.toFixed(2)),
            hours: Number(finalOtEligible.toFixed(2)),
            hrSaving: Number(hrSaving.toFixed(2)),
            type: att.status === 'Weekly Off' ? 'Weekly Off' : 'Regular',
            status: 'Pending',
            remarks: '',
            shiftId: att.shiftId || null
          });
          added++;
        }
      }
      toast.success(`Sync complete: ${added} added, ${updated} updated`, { id: 'sync' });
    } catch (e) {
      toast.error('Sync failed', { id: 'sync' });
    }
  };

  const handleStatusChange = async (id: string, status: 'Approved' | 'Rejected') => {
    try {
      await updateOvertime(id, { 
        status, 
        reviewedBy: user?.username || 'Admin',
        reviewedDate: new Date().toISOString()
      });
      toast.success(`OT ${status.toLowerCase()} successfully`);
    } catch (e) {
      toast.error('Operation failed');
    }
  };

  const handleSaveSupervisorOT = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedRecord) return;

    try {
      const bioOt = Number(selectedRecord.bioOtHours) || 0;
      const supOt = Number(formData.supervisorOtHours) || 0;
      const finalOt = Math.min(bioOt, supOt);
      const hrSaving = Math.max(0, bioOt - finalOt);

      await updateOvertime(selectedRecord.id, {
        supervisorOtHours: Number(supOt.toFixed(2)),
        hours: Number(finalOt.toFixed(2)),
        hrSaving: Number(hrSaving.toFixed(2)),
        otStartTime: formData.otStartTime,
        otEndTime: formData.otEndTime,
        remarks: formData.remarks,
        type: formData.type
      });

      toast.success('Supervisor OT saved successfully');
      toast.info('OT recalculated successfully');
      setIsEditModalOpen(false);
    } catch (e) {
      toast.error('Failed to save record');
    }
  };

  const handleManualAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.employeeId || !formData.date) return;

    try {
      const bioOt = 0; // Manual entry starting point
      const supOt = Number(formData.supervisorOtHours) || 0;
      const finalOt = Math.min(bioOt, supOt);
      const hrSaving = Math.max(0, bioOt - finalOt);

      await addOvertime({
        employeeId: formData.employeeId,
        date: formData.date,
        type: formData.type,
        remarks: formData.remarks,
        otStartTime: formData.otStartTime,
        otEndTime: formData.otEndTime,
        bioOtHours: bioOt,
        supervisorOtHours: supOt,
        standardDutyHours: 8, // Manual entry default
        hours: finalOt,
        hrSaving: hrSaving,
        status: 'Pending',
        shiftId: null 
      });
      toast.success('OT record added successfully');
      setIsModalOpen(false);
    } catch (e) {
      toast.error('Failed to add record');
    }
  };

  const handleExportCSV = () => {
    try {
      const data = filteredRecords.map(record => {
        const emp = employees.find(e => e.id === record.employeeId);
        const att = processedData.find(p => p.employeeId === record.employeeId && p.date === record.date);
        const shift = settings.shifts?.find(s => s.id === record.shiftId);

        return {
          'Employee ID': record.employeeId,
          'Employee Name': emp?.name || 'Unknown',
          'Department': emp?.department || '-',
          'Date': record.date,
          'Shift': shift?.name || '-',
          'Standard Duty Hours': record.standardDutyHours || 8,
          'In Time': att?.firstPunch ? format(parseISO(att.firstPunch), 'HH:mm') : '-',
          'Out Time': att?.lastPunch ? format(parseISO(att.lastPunch), 'HH:mm') : '-',
          'Working Hours': att?.workingHours || 0,
          'Bio OT': record.bioOtHours,
          'Supervisor OT': record.supervisorOtHours,
          'Final OT Eligible': record.hours,
          'HR Saving': record.hrSaving,
          'OT Remarks': record.remarks || '',
          'Approval Status': record.status,
          'Reviewed By': record.reviewedBy || '-',
          'Reviewed Date': record.reviewedDate ? format(parseISO(record.reviewedDate), 'dd MMM yyyy') : '-'
        };
      });

      const ws = XLSX.utils.json_to_sheet(data);
      const csvContent = XLSX.utils.sheet_to_csv(ws);
      
      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const link = document.createElement('a');
      const url = URL.createObjectURL(blob);
      link.setAttribute('href', url);
      link.setAttribute('download', `OT_Audit_Log_${dateRange.start}_to_${dateRange.end}.csv`);
      link.style.visibility = 'hidden';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      
      toast.success('OT Audit Log exported as CSV');
    } catch (error) {
      toast.error('Failed to export CSV');
    }
  };

  const openEditModal = (record: OvertimeRecord) => {
    setSelectedRecord(record);
    setFormData({
      employeeId: record.employeeId,
      date: record.date,
      supervisorOtHours: record.supervisorOtHours,
      otStartTime: record.otStartTime || '',
      otEndTime: record.otEndTime || '',
      type: record.type,
      remarks: record.remarks
    });
    setIsEditModalOpen(true);
  };

  const handleDeleteRecord = async (id: string) => {
    try {
      await deleteOvertime(id);
      toast.success('Record deleted successfully');
    } catch (e) {
      toast.error('Failed to delete record');
    }
  };

  return (
    <div className="space-y-6 pb-20">
      <div className="flex flex-col xl:flex-row xl:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-semibold text-slate-900 tracking-tight flex items-center gap-2">
            <Clock className="w-6 h-6 text-indigo-600" />
            OT Audit Log
          </h2>
          <p className="text-sm text-slate-500 font-bold uppercase tracking-normal mt-1">Biometric vs Supervisor Verification</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <div className="flex items-center gap-2 bg-white border border-slate-200 rounded-xl px-3 py-1.5 shadow-sm">
            <Calendar className="w-4 h-4 text-slate-400" />
            <input 
              type="date" 
              value={dateRange.start} 
              onChange={e => setDateRange(prev => ({ ...prev, start: e.target.value }))}
              className="text-xs font-bold text-slate-600 border-none p-0 focus:ring-0 bg-transparent"
            />
            <span className="text-slate-300">to</span>
            <input 
              type="date" 
              value={dateRange.end} 
              onChange={e => setDateRange(prev => ({ ...prev, end: e.target.value }))}
              className="text-xs font-bold text-slate-600 border-none p-0 focus:ring-0 bg-transparent"
            />
          </div>
          <button 
            onClick={handleSyncAttendance}
            className="flex items-center gap-2 bg-slate-900 text-white px-4 py-2 rounded-xl text-sm font-semibold hover:bg-slate-800 transition-all shadow-lg shadow-slate-100"
          >
            <RefreshCw className="w-4 h-4" />
            Sync Attendance
          </button>
          <button 
            onClick={() => setIsModalOpen(true)}
            className="flex items-center gap-2 bg-indigo-600 text-white px-4 py-2 rounded-xl text-sm font-semibold shadow-lg shadow-indigo-100 hover:bg-indigo-700 transition-all"
          >
            <Plus className="w-4 h-4" />
            Manual Entry
          </button>
          <button 
            onClick={handleExportCSV}
            className="flex items-center gap-2 bg-white border border-slate-200 px-4 py-2 rounded-xl text-sm font-semibold text-slate-600 hover:bg-slate-50 transition-all shadow-sm"
          >
            <Download className="w-4 h-4" />
            Download Audit Log (CSV)
          </button>
          {selectedIds.length > 0 && (
            <button 
              onClick={handleBulkDelete}
              className="flex items-center gap-2 bg-rose-600 text-white px-4 py-2 rounded-xl text-sm font-semibold shadow-lg shadow-rose-100 hover:bg-rose-700 transition-all"
            >
              <Trash2 className="w-4 h-4" />
              Delete Selected ({selectedIds.length})
            </button>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard 
          label="Total Records" 
          value={stats.total} 
          icon={<Clock className="w-5 h-5 text-indigo-500" />} 
          color="indigo" 
          onClick={() => setStatusFilter('All')}
        />
        <StatCard 
          label="Pending HR" 
          value={stats.pending} 
          icon={<AlertCircle className="w-5 h-5 text-amber-500" />} 
          color="amber" 
          onClick={() => setStatusFilter('Pending')}
        />
        <StatCard 
          label="Approved OT" 
          value={stats.approved} 
          icon={<CheckCircle2 className="w-5 h-5 text-emerald-500" />} 
          color="emerald" 
          onClick={() => setStatusFilter('Approved')}
        />
        <StatCard label="Eligible Hours" value={`${Math.round(stats.totalHours)}h`} icon={<RefreshCw className="w-5 h-5 text-sky-500" />} color="sky" />
      </div>

      <div className="bg-white dark:bg-slate-900/50 dark:backdrop-blur-xl p-4 rounded-lg border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
        <div className="flex flex-wrap items-center gap-4">
          <div className="relative flex-1 min-w-[240px]">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input 
              type="text" 
              placeholder="Search employee or ID..."
              className="w-full pl-10 pr-4 py-2.5 bg-slate-50 dark:bg-slate-800 border-none rounded-xl text-sm focus:ring-2 focus:ring-indigo-500/20 dark:text-white"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          
          <select 
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value as any)}
            className="px-4 py-2.5 bg-slate-50 dark:bg-slate-800 border-none rounded-xl text-sm font-bold text-slate-600 dark:text-slate-300 focus:ring-2 focus:ring-indigo-500/20"
          >
            <option value="All">All Status</option>
            <option value="Pending">Pending Review</option>
            <option value="Approved">Approved</option>
            <option value="Rejected">Rejected</option>
          </select>

          <select 
            value={designationFilter}
            onChange={(e) => setDesignationFilter(e.target.value)}
            className="px-4 py-2.5 bg-slate-50 border-none rounded-xl text-sm font-bold text-slate-600 focus:ring-2 focus:ring-indigo-500/20"
          >
            <option value="All">All Designations</option>
            {[...new Set(employees.map(e => e.designation).filter(Boolean))].map(d => (
              <option key={d} value={d}>{d}</option>
            ))}
          </select>

          <select 
            value={contractorFilter}
            onChange={(e) => setContractorFilter(e.target.value)}
            className="px-4 py-2.5 bg-slate-50 border-none rounded-xl text-sm font-bold text-slate-600 focus:ring-2 focus:ring-indigo-500/20"
          >
            <option value="All">All Contractors</option>
            {[...new Set(employees.map(e => e.contractorName).filter(Boolean))].map(c => (
              <option key={c} value={c}>{c}</option>
            ))}
          </select>
        </div>

        <OTAuditLog 
          records={filteredRecords}
          employees={employees}
          attendanceData={processedData}
          shifts={settings.shifts || []}
          onEdit={openEditModal}
          onApprove={(id) => handleStatusChange(id, 'Approved')}
          onReject={(id) => handleStatusChange(id, 'Rejected')}
          onDelete={handleDeleteRecord}
          onOpenProfile={openEmployeeProfile}
          selectedIds={selectedIds}
          onSelect={handleSelect}
          onSelectAll={setSelectedIds}
        />
      </div>
      
      {/* Edit Modal (Supervisor Entry) */}
      <AnimatePresence>
        {isEditModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsEditModalOpen(false)}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-md"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="relative w-full max-w-xl bg-white rounded-[2rem] shadow-md overflow-hidden"
            >
              <div className="p-5 border-b border-slate-100 flex items-center justify-between">
                <div>
                  <h3 className="text-xl font-semibold text-slate-900">Supervisor OT Verification</h3>
                  <p className="text-xs font-bold text-slate-400 uppercase tracking-normal mt-1">
                    Employee: {employees.find(e => e.id === selectedRecord?.employeeId)?.name} ({selectedRecord?.employeeId})
                  </p>
                </div>
                <button onClick={() => setIsEditModalOpen(false)} className="p-2 hover:bg-slate-100 rounded-xl transition-colors">
                  <Plus className="w-6 h-6 rotate-45 text-slate-400" />
                </button>
              </div>

              <form onSubmit={handleSaveSupervisorOT} className="p-5 space-y-6">
                <div className="grid grid-cols-2 gap-6 p-4 bg-indigo-50/50 rounded-lg border border-indigo-100/50">
                  <div className="text-center">
                    <p className="text-xs font-semibold text-indigo-400 uppercase">Biometric OT</p>
                    <p className="text-3xl font-semibold text-indigo-600">{selectedRecord?.bioOtHours}h</p>
                  </div>
                  <div className="text-center border-l border-indigo-100">
                    <p className="text-xs font-semibold text-indigo-400 uppercase">Duty Status</p>
                    <p className="text-sm font-semibold text-indigo-900 mt-2 uppercase tracking-tight">
                      {processedData.find(p => p.employeeId === selectedRecord?.employeeId && p.date === selectedRecord?.date)?.status || 'Present'}
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-xs font-semibold text-slate-400 uppercase tracking-normal ml-1">Supervisor OT Hours</label>
                    <input 
                      type="number"
                      step="0.1"
                      required
                      value={formData.supervisorOtHours}
                      onChange={e => setFormData({ ...formData, supervisorOtHours: parseFloat(e.target.value) })}
                      className="w-full px-5 py-4 bg-slate-50 border-2 border-transparent rounded-lg text-base font-semibold text-slate-900 focus:border-indigo-500/20 focus:ring-0 transition-all"
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-xs font-semibold text-slate-400 uppercase tracking-normal ml-1">Final OT Category</label>
                    <select 
                      value={formData.type}
                      onChange={e => setFormData({ ...formData, type: e.target.value as any })}
                      className="w-full px-5 py-4 bg-slate-50 border-2 border-transparent rounded-lg text-sm font-semibold text-slate-900 focus:border-indigo-500/20 focus:ring-0"
                    >
                      <option value="Regular">Regular</option>
                      <option value="Holiday">Holiday</option>
                      <option value="Weekly Off">Weekly Off</option>
                    </select>
                  </div>

                  <div className="space-y-2">
                    <label className="text-xs font-semibold text-slate-400 uppercase tracking-normal ml-1">OT Start Time</label>
                    <input 
                      type="time"
                      value={formData.otStartTime}
                      onChange={e => setFormData({ ...formData, otStartTime: e.target.value })}
                      className="w-full px-5 py-4 bg-slate-50 border-2 border-transparent rounded-lg text-sm font-semibold text-slate-900 focus:border-indigo-500/20 focus:ring-0"
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-xs font-semibold text-slate-400 uppercase tracking-normal ml-1">OT End Time</label>
                    <input 
                      type="time"
                      value={formData.otEndTime}
                      onChange={e => setFormData({ ...formData, otEndTime: e.target.value })}
                      className="w-full px-5 py-4 bg-slate-50 border-2 border-transparent rounded-lg text-sm font-semibold text-slate-900 focus:border-indigo-500/20 focus:ring-0"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-semibold text-slate-400 uppercase tracking-normal ml-1">Process Remarks</label>
                  <textarea 
                    value={formData.remarks}
                    onChange={e => setFormData({ ...formData, remarks: e.target.value })}
                    className="w-full px-5 py-4 bg-slate-50 border-2 border-transparent rounded-lg text-sm font-bold text-slate-900 focus:border-indigo-500/20 focus:ring-0 min-h-[100px]"
                    placeholder="Provide justification for OT verification..."
                  />
                </div>

                <div className="flex gap-4 pt-4">
                  <button 
                    type="submit"
                    className="flex-1 py-4 bg-indigo-600 text-white rounded-lg text-sm font-semibold shadow-sm shadow-indigo-100 hover:bg-indigo-700 transition-all flex items-center justify-center gap-2"
                  >
                    <Save className="w-4 h-4" />
                    Save Supervisor OT
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Add Modal (Manual Entry) */}
      <AnimatePresence>
        {isModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsModalOpen(false)}
              className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="relative w-full max-w-lg bg-white rounded-lg shadow-md overflow-hidden"
            >
              <div className="px-8 py-6 border-b border-slate-100 flex items-center justify-between">
                <div>
                  <h3 className="text-xl font-semibold text-slate-900">Add Manual OT</h3>
                  <p className="text-xs font-bold text-slate-400 uppercase tracking-normal mt-0.5">Special Exception Entry</p>
                </div>
                <button onClick={() => setIsModalOpen(false)} className="p-2 bg-slate-50 rounded-xl">
                  <Plus className="w-5 h-5 rotate-45 text-slate-400" />
                </button>
              </div>

              <form onSubmit={handleManualAdd} className="p-5 space-y-6">
                <div className="space-y-2">
                  <label className="text-xs font-semibold text-slate-400 uppercase tracking-normal ml-1">Staff Member</label>
                  <select 
                    required
                    value={formData.employeeId}
                    onChange={e => setFormData({ ...formData, employeeId: e.target.value })}
                    className="w-full px-4 py-3 bg-slate-50 border-none rounded-lg text-sm font-bold text-slate-900 focus:ring-2 focus:ring-indigo-500/20"
                  >
                    <option value="">Choose Staff...</option>
                    {employees.map(emp => (
                      <option key={emp.id} value={emp.id}>{emp.name} ({emp.id})</option>
                    ))}
                  </select>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-xs font-semibold text-slate-400 uppercase tracking-normal ml-1">Work Date</label>
                    <input 
                      type="date"
                      required
                      value={formData.date}
                      onChange={e => setFormData({ ...formData, date: e.target.value })}
                      className="w-full px-4 py-3 bg-slate-50 border-none rounded-lg text-sm font-bold text-slate-900 focus:ring-2 focus:ring-indigo-500/20"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-semibold text-slate-400 uppercase tracking-normal ml-1">OT Hours</label>
                    <input 
                      type="number"
                      step="0.5"
                      required
                      value={formData.supervisorOtHours}
                      onChange={e => setFormData({ ...formData, supervisorOtHours: parseFloat(e.target.value) })}
                      className="w-full px-4 py-3 bg-slate-50 border-none rounded-lg text-sm font-bold text-slate-900 focus:ring-2 focus:ring-indigo-500/20"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-semibold text-slate-400 uppercase tracking-normal ml-1">Remarks</label>
                  <textarea 
                    value={formData.remarks}
                    onChange={e => setFormData({ ...formData, remarks: e.target.value })}
                    className="w-full px-4 py-3 bg-slate-50 border-none rounded-lg text-sm font-bold text-slate-900 focus:ring-2 focus:ring-indigo-500/20 min-h-[80px]"
                    placeholder="Reason for manual entry..."
                  />
                </div>

                <button 
                  type="submit"
                  className="w-full py-4 bg-indigo-600 text-white rounded-lg text-sm font-semibold hover:bg-indigo-700 transition-all flex items-center justify-center gap-2"
                >
                  <Save className="w-4 h-4" />
                  Save Manual OT
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

function StatCard({ label, value, icon, color, onClick }: any) {
  const colors: any = {
    indigo: 'bg-indigo-50/50 text-indigo-600 border-indigo-100/50 hover:bg-indigo-100/50',
    amber: 'bg-amber-50/50 text-amber-600 border-amber-100/50 hover:bg-amber-100/50',
    emerald: 'bg-emerald-50/50 text-emerald-600 border-emerald-100/50 hover:bg-emerald-100/50',
    sky: 'bg-sky-50/50 text-sky-600 border-sky-100/50 hover:bg-sky-100/50',
  };
  return (
    <div 
      onClick={onClick}
      className={`p-6 rounded-[2rem] border shadow-sm ${colors[color]} backdrop-blur-sm transition-all ${onClick ? 'cursor-pointer active:scale-95' : ''}`}
    >
       <div className="flex items-center justify-between mb-4">
          <div className="w-12 h-12 bg-white dark:bg-slate-800 rounded-lg flex items-center justify-center shadow-sm border border-white/50 dark:border-slate-700">{icon}</div>
          <span className="text-3xl font-semibold tracking-tight">{value}</span>
       </div>
       <p className="text-xs font-semibold uppercase tracking-wide opacity-50 ml-1">{label}</p>
    </div>
  );
}
