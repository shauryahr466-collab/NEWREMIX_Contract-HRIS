import { useState, useMemo } from 'react';
import { useAppStore } from '../store';
import { format, parseISO, startOfMonth, subDays } from 'date-fns';
import * as XLSX from 'xlsx';
import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';
import { Download, FileText, Calendar, Filter, Archive, FileSpreadsheet, Loader2, Info } from 'lucide-react';
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, CartesianGrid, BarChart, Bar } from 'recharts';
import { googleSignIn, getAccessToken } from '../lib/firebase';
import { createSpreadsheet, appendDataToSheet, formatSpreadsheet } from '../lib/sheets';
import { MultiSelect } from '../components/MultiSelect';

import { formatAMPM, formatDuration, formatMinutes } from '../lib/utils';
import { processPunches } from '../lib/engine';
import { getNepaliDate } from '../utils/dateHelper';

export function Reports() {
  const { processedData, employees, settings, calculationSource, setCalculationSource, punches, shiftAssignments, setProcessedData, overtimeRecords, globalSearchTerm } = useAppStore();
  const [reportType, setReportType] = useState('daily');
  const [startDate, setStartDate] = useState(format(startOfMonth(new Date()), 'yyyy-MM-dd'));
  const [endDate, setEndDate] = useState(format(new Date(), 'yyyy-MM-dd'));
  const [deptFilter, setDeptFilter] = useState<string[]>(['All']);
  const [designationFilter, setDesignationFilter] = useState<string[]>(['All']);
  const [contractorFilter, setContractorFilter] = useState<string[]>(['All']);
  const [searchTerm, setSearchTerm] = useState('');
  const [sortBy, setSortBy] = useState<'id' | 'name'>('name');

  const activeSearch = searchTerm || globalSearchTerm;

  const reprocess = (source: 'all' | 'standard' | 'multi-time') => {
    setCalculationSource(source);
    // Recalculation is handled by store's useMemo reacting to setCalculationSource
  };

  const departments = useMemo(() => {
    const depts = employees.map(e => e.department).filter(Boolean) as string[];
    return ['All', ...new Set(depts)];
  }, [employees]);

  const designations = useMemo(() => {
    const des = employees.map(e => e.designation).filter(Boolean) as string[];
    return ['All', ...new Set(des)];
  }, [employees]);

  const contractors = useMemo(() => {
    const cons = employees.map(e => e.contractorName).filter(Boolean) as string[];
    return ['All', ...new Set(cons)];
  }, [employees]);

  const [isSyncing, setIsSyncing] = useState(false);

  const handleSyncToSheets = async () => {
    const filtered = getFilteredData();
    if (filtered.length === 0) {
      alert("No data available for the selected filters.");
      return;
    }

    setIsSyncing(true);
    try {
      let token = await getAccessToken();
      if (!token) {
        const result = await googleSignIn();
        if (!result) return;
        token = result.accessToken;
      }

      const title = `${settings.companyName} - ${reportType.charAt(0).toUpperCase() + reportType.slice(1)} Report (${startDate} to ${endDate})`;
      const ss = await createSpreadsheet(token, title);
      const spreadsheetId = ss.spreadsheetId;

      let headers: string[] = [];
      let rows: any[][] = [];

      if (reportType === 'daily') {
        headers = ['Gregorian Date', 'Nepali Date', 'Day', 'Employee ID', 'Name', 'Department', 'Designation', 'Contractor', 'Weekly Off', 'Shift', 'In Time', 'Out Time', 'Punch Count', 'Late Timing', 'Early Out', 'Work Hours', 'Overtime', 'Status'];
        rows = filtered.map(d => {
          const emp = employees.find(e => e.id === d.employeeId);
          const assignment = shiftAssignments.find(a => a.employeeId === d.employeeId && a.date === d.date);
          const shift = settings.shifts?.find(s => s.id === (assignment?.shiftId || emp?.shiftId));
          return [
            d.date,
            getNepaliDate(d.date),
            format(parseISO(d.date), 'EEEE'),
            d.employeeId,
            emp?.name || '',
            emp?.department || '',
            emp?.designation || '',
            emp?.contractorName || '',
            emp?.weeklyOff || '',
            shift?.name || 'Default',
            formatAMPM(d.firstPunch),
            (d.lastPunch && d.lastPunch !== d.firstPunch) ? formatAMPM(d.lastPunch) : '',
            (d.rawLogs || d.logs).length,
            formatMinutes(d.lateMinutes),
            formatMinutes(d.earlyMinutes),
            formatDuration(d.workingHours),
            formatDuration(d.overtime),
            d.status
          ];
        });
      } else if (reportType === 'missing') {
        headers = ['Gregorian Date', 'Nepali Date', 'Employee ID', 'Name', 'Department', 'Designation', 'Contractor', 'Punch Time', 'All Logs', 'Status'];
        rows = filtered.map(d => {
          const emp = employees.find(e => e.id === d.employeeId);
          return [
            d.date,
            getNepaliDate(d.date),
            d.employeeId,
            emp?.name || '',
            emp?.department || '',
            emp?.designation || '',
            emp?.contractorName || '',
            formatAMPM(d.firstPunch),
            (d.rawLogs || d.logs).map(l => formatAMPM(l)).join(', '),
            'Missing Out Punch'
          ];
        });
      } else if (reportType === 'overtime') {
        headers = ['Gregorian Date', 'Nepali Date', 'Employee ID', 'Name', 'Department', 'Designation', 'Work Hours', 'Overtime (Hrs)', 'Logs'];
        rows = filtered.map(d => {
          const emp = employees.find(e => e.id === d.employeeId);
          return [
            d.date,
            getNepaliDate(d.date),
            d.employeeId,
            emp?.name || '',
            emp?.department || '',
            emp?.designation || '',
            formatDuration(d.workingHours),
            formatDuration(d.overtime),
            (d.rawLogs || d.logs).map(l => formatAMPM(l)).join(', ')
          ];
        });
      }

      await appendDataToSheet(token, spreadsheetId, 'Sheet1!A1', [headers, ...rows]);
      
      // Apply professional styling
      const sheetId = ss.sheets[0].properties.sheetId;
      await formatSpreadsheet(token, spreadsheetId, sheetId, rows.length + 1, headers.length);
      
      const confirmOpen = window.confirm("Report synced to Google Sheets successfully with professional styling! Would you like to open it?");
      if (confirmOpen) {
        window.location.href = `https://docs.google.com/spreadsheets/d/${spreadsheetId}/edit`;
      }
    } catch (error: any) {
      console.error('Sheet Sync Error:', error);
      alert(`Failed to sync to Google Sheets: ${error.message}`);
    } finally {
      setIsSyncing(false);
    }
  };

  const getFilteredData = () => {
    let filtered = processedData.filter(d => {
      const emp = employees.find(e => e.id === d.employeeId);
      
      const recordDate = d.date;
      const matchesDate = (!startDate || recordDate >= startDate) && (!endDate || recordDate <= endDate);
      const matchesDept = deptFilter.includes('All') || (emp?.department && deptFilter.includes(emp.department));
      const matchesDesignation = designationFilter.includes('All') || (emp?.designation && designationFilter.includes(emp.designation));
      const matchesContractor = contractorFilter.includes('All') || (emp?.contractorName && contractorFilter.includes(emp.contractorName));
      const matchesSearch = !activeSearch || 
        emp?.name.toLowerCase().includes(activeSearch.toLowerCase()) || 
        d.employeeId.toLowerCase().includes(activeSearch.toLowerCase()) ||
        emp?.designation?.toLowerCase().includes(activeSearch.toLowerCase());
      
      let matchesType = true;
      if (reportType === 'missing') matchesType = d.status === 'SPF';
      else if (reportType === 'overtime') matchesType = d.overtime > 0;
      
      return matchesDate && matchesDept && matchesType && matchesSearch && matchesDesignation && matchesContractor;
    });

    return filtered.sort((a, b) => {
      if (sortBy === 'name') {
        const empA = employees.find(e => e.id === a.employeeId)?.name || '';
        const empB = employees.find(e => e.id === b.employeeId)?.name || '';
        return empA.localeCompare(empB);
      }
      return a.employeeId.localeCompare(b.employeeId);
    });
  };

  const attendanceTrends = useMemo(() => {
    const last7Days = Array.from({ length: 7 }).map((_, i) => {
      const d = format(subDays(new Date(), i), 'yyyy-MM-dd');
      return d;
    }).reverse();

    return last7Days.map(date => ({
      date: format(parseISO(date), 'MMM dd'),
      present: processedData.filter(d => d.date === date && d.status === 'Present').length,
    }));
  }, [processedData]);

  const deptOTData = useMemo(() => {
    const depts = Array.from(new Set(employees.map(e => e.department)));
    return depts.map(dept => {
      const deptEmps = employees.filter(e => e.department === dept).map(e => e.id);
      const otHours = overtimeRecords
        ? overtimeRecords
            .filter(r => deptEmps.includes(r.employeeId) && r.status === 'Approved')
            .reduce((sum, r) => sum + r.hours, 0)
        : 0;
      
      return { name: dept, hours: Math.round((otHours as number) * 10) / 10 };
    }).sort((a, b) => (b.hours || 0) - (a.hours || 0));
  }, [employees, overtimeRecords]);

  const handleExport = () => {
    const filtered = getFilteredData();
    let dataToExport: any[] = [];

    if (reportType === 'daily') {
      dataToExport = filtered.map(d => {
        const emp = employees.find(e => e.id === d.employeeId);
        const assignment = shiftAssignments.find(a => a.employeeId === d.employeeId && a.date === d.date);
        const shift = settings.shifts?.find(s => s.id === (assignment?.shiftId || emp?.shiftId));
        return {
          'Gregorian Date': d.date,
          'Nepali Date (B.S.)': getNepaliDate(d.date),
          'Day': format(parseISO(d.date), 'EEEE'),
          'Employee ID': d.employeeId,
          'Name': emp?.name || '',
          'Department': emp?.department || '',
          'Designation': emp?.designation || '',
          'Contractor': emp?.contractorName || '',
          'Weekly Off': emp?.weeklyOff || '',
          'Shift': shift?.name || 'Default',
          'In Time': formatAMPM(d.firstPunch),
          'Out Time': (d.lastPunch && d.lastPunch !== d.firstPunch) ? formatAMPM(d.lastPunch) : '',
          'Punch Count': (d.rawLogs || d.logs).length,
          'Late Timing': formatMinutes(d.lateMinutes),
          'Early Out': formatMinutes(d.earlyMinutes),
          'Work Hours': formatDuration(d.workingHours),
          'Overtime': formatDuration(d.overtime),
          'Actual Logs': (d.rawLogs || d.logs).map(l => formatAMPM(l)).join(', '),
          'Status': d.status
        };
      });
    } else if (reportType === 'missing') {
      dataToExport = filtered.map(d => {
        const emp = employees.find(e => e.id === d.employeeId);
        return {
          'Gregorian Date': d.date,
          'Nepali Date (B.S.)': getNepaliDate(d.date),
          'Employee ID': d.employeeId,
          'Name': emp?.name || '',
          'Department': emp?.department || '',
          'Designation': emp?.designation || '',
          'Punch Time': formatAMPM(d.firstPunch),
          'All Logs': d.logs.map(l => formatAMPM(l)).join(', '),
          'Status': 'Missing Out Punch'
        };
      });
    } else if (reportType === 'overtime') {
      dataToExport = filtered.map(d => {
        const emp = employees.find(e => e.id === d.employeeId);
        return {
          'Gregorian Date': d.date,
          'Nepali Date (B.S.)': getNepaliDate(d.date),
          'Employee ID': d.employeeId,
          'Name': emp?.name || '',
          'Department': emp?.department || '',
          'Designation': emp?.designation || '',
          'Work Hours': formatDuration(d.workingHours),
          'Overtime (Hrs)': formatDuration(d.overtime),
          'Logs': d.logs.map(l => formatAMPM(l)).join(', ')
        };
      });
    }

    if (dataToExport.length === 0) {
      alert("No data available for the selected filters.");
      return;
    }

    const ws = XLSX.utils.json_to_sheet(dataToExport);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Report");
    XLSX.writeFile(wb, `${settings.companyName}_${reportType}_report.xlsx`);
  };

  const handleExportCSV = () => {
    const filtered = getFilteredData();
    let dataToExport: any[] = [];

    if (reportType === 'daily' || reportType === 'missing' || reportType === 'overtime') {
      dataToExport = filtered.map(d => {
        const emp = employees.find(e => e.id === d.employeeId);
        const assignment = shiftAssignments.find(a => a.employeeId === d.employeeId && a.date === d.date);
        const shift = settings.shifts?.find(s => s.id === (assignment?.shiftId || emp?.shiftId));
        
        return {
          'Gregorian Date': d.date,
          'Nepali Date (B.S.)': getNepaliDate(d.date),
          'Employee ID': d.employeeId,
          'Legal Name': emp?.name || '',
          'Department ID': emp?.department || '',
          'Contractor Name': emp?.contractorName || '',
          'Designation': emp?.designation || '',
          'Shift Type': shift?.name || 'Day Shift',
          'Clock In': formatAMPM(d.firstPunch),
          'Clock Out': (d.lastPunch && d.lastPunch !== d.firstPunch) ? formatAMPM(d.lastPunch) : '',
          'Total Hours': d.workingHours.toFixed(2),
          'OT Hours': d.overtime.toFixed(2),
          'Late Timing': formatMinutes(d.lateMinutes),
          'Early Out': formatMinutes(d.earlyMinutes),
          'Punch Count': (d.rawLogs || d.logs).length,
          'Attendance Status': d.status
        };
      });
    }

    if (dataToExport.length === 0) {
      alert("No data found for the selected filters.");
      return;
    }

    const ws = XLSX.utils.json_to_sheet(dataToExport);
    const csvContent = XLSX.utils.sheet_to_csv(ws);
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `${settings.companyName}_${reportType}_Payroll_Report.csv`);
    link.click();
  };

  const handlePrintPDF = () => {
    const unfiltered = getFilteredData();
    if (unfiltered.length === 0) {
      alert("No data available for the selected filters.");
      return;
    }

    // Date Order: Ascending (Earliest Date First)
    const filtered = [...unfiltered].sort((a, b) => a.date.localeCompare(b.date));

    const doc = new jsPDF({
      orientation: 'landscape',
      unit: 'mm',
      format: 'a4'
    });
    
    const pageWidth = doc.internal.pageSize.getWidth();
    
    // Requirement 4: Compact Header Design
    // Company Name: 14px Bold
    doc.setFontSize(14);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(30, 41, 59); 
    doc.text(settings.companyName.toUpperCase(), pageWidth / 2, 10, { align: 'center' });
    
    // Report Title: 11px Bold
    doc.setFontSize(11);
    doc.text('Attendance Audit Report', pageWidth / 2, 16, { align: 'center' });
    doc.text('Employee Attendance Summary', pageWidth / 2, 21, { align: 'center' });

    // Date Range: 9px Regular
    doc.setFontSize(9);
    doc.setFont('helvetica', 'normal');
    doc.text(`Period: ${startDate} to ${endDate}`, pageWidth / 2, 26, { align: 'center' });
    
    // Generation Date: 8px Gray
    doc.setFontSize(8);
    doc.setTextColor(120, 120, 120);
    doc.text(`Generated On: ${format(new Date(), 'dd/MM/yyyy HH:mm')}`, 8, 32);
    
    doc.setDrawColor(200, 200, 200);
    doc.line(8, 34, pageWidth - 8, 34);

    let head: string[][] = [];
    let body: string[][] = [];

    if (reportType === 'daily') {
      head = [['Day', 'Date', 'Date (B.S.)', 'Emp ID', 'Employee Name', 'WO', 'Shift', 'Clock In', 'Clock Out', 'Late', 'Early', 'Work', 'OT', 'Status']];
      body = filtered.map(d => {
        const emp = employees.find(e => e.id === d.employeeId);
        const shiftAssigned = shiftAssignments.find(a => a.employeeId === d.employeeId && a.date === d.date);
        const shiftDetails = settings.shifts?.find(s => s.id === (shiftAssigned?.shiftId || emp?.shiftId));
        
        return [
          format(parseISO(d.date), 'EEE'),
          d.date,
          getNepaliDate(d.date),
          d.employeeId,
          emp?.name || '',
          emp?.weeklyOff?.substring(0, 3) || '-',
          shiftDetails?.name || 'Day Shift',
          formatAMPM(d.firstPunch),
          (d.lastPunch && d.lastPunch !== d.firstPunch) ? formatAMPM(d.lastPunch) : '-',
          formatMinutes(d.lateMinutes),
          formatMinutes(d.earlyMinutes),
          formatDuration(d.workingHours),
          formatDuration(d.overtime),
          d.status
        ];
      });
    } else if (reportType === 'missing') {
      head = [['Date', 'Date (B.S.)', 'Emp ID', 'Employee Name', 'Department', 'Contractor', 'Raw Logs', 'Status']];
      body = filtered.map(d => {
        const emp = employees.find(e => e.id === d.employeeId);
        return [
          d.date,
          getNepaliDate(d.date),
          d.employeeId,
          emp?.name || '',
          emp?.department || '',
          emp?.contractorName || '-',
          (d.rawLogs || d.logs).map(l => formatAMPM(l)).join(', '),
          'Missing Out'
        ];
      });
    } else if (reportType === 'overtime') {
      head = [['Date', 'Date (B.S.)', 'Emp ID', 'Employee Name', 'Reg Hours', 'OT Hours', 'Status']];
      body = filtered.map(d => {
        const emp = employees.find(e => e.id === d.employeeId);
        return [
          d.date,
          getNepaliDate(d.date),
          d.employeeId,
          emp?.name || '',
          formatDuration(d.workingHours),
          formatDuration(d.overtime),
          d.status
        ];
      });
    }

    const getColumnStyles = (): any => {
      if (reportType === 'daily') {
        const styles: any = {
          0: { cellWidth: 10, halign: 'center' }, // Day
          1: { cellWidth: 18, halign: 'center' }, // Date
          2: { cellWidth: 18, halign: 'center' }, // Date BS
          3: { cellWidth: 15, halign: 'center' }, // ID
          4: { cellWidth: 'auto', minCellWidth: 40 }, // Name
          5: { cellWidth: 10, halign: 'center' }, // WO
          6: { cellWidth: 16, halign: 'center' }, // Shift
          7: { cellWidth: 16, halign: 'center' }, // In
          8: { cellWidth: 16, halign: 'center' }, // Out
          9: { cellWidth: 11, halign: 'center' }, // Late
          10: { cellWidth: 11, halign: 'center' }, // Early
          11: { cellWidth: 12, halign: 'center' }, // Work
          12: { cellWidth: 12, halign: 'center' }, // OT
          13: { cellWidth: 20, halign: 'center', fontStyle: 'bold' } // Status
        };
        return styles;
      } else if (reportType === 'missing') {
        const styles: any = {
          0: { cellWidth: 22, halign: 'center' }, // Date
          1: { cellWidth: 22, halign: 'center' }, // Date BS
          2: { cellWidth: 18, halign: 'center' }, // ID
          3: { cellWidth: 'auto' }, // Name
          4: { cellWidth: 30 }, // Dept
          5: { cellWidth: 30 }, // Contractor
          6: { cellWidth: 40 }, // Logs
          7: { cellWidth: 22, halign: 'center', fontStyle: 'bold' } // Status
        };
        return styles;
      } else {
        const styles: any = {
          0: { cellWidth: 22, halign: 'center' }, // Date
          1: { cellWidth: 22, halign: 'center' }, // Date BS
          2: { cellWidth: 18, halign: 'center' }, // ID
          3: { cellWidth: 'auto', minCellWidth: 40 }, // Name
          4: { cellWidth: 25, halign: 'center' }, // Work
          5: { cellWidth: 25, halign: 'center' }, // OT
          6: { cellWidth: 25, halign: 'center', fontStyle: 'bold' } // Status
        };
        return styles;
      }
    };

    autoTable(doc, {
      startY: 38,
      head: head,
      body: body,
      theme: 'striped',
      headStyles: { 
        fillColor: [15, 23, 42], // Deep Navy
        textColor: [255, 255, 255],
        fontSize: 8, 
        fontStyle: 'bold',
        halign: 'center',
        valign: 'middle',
        cellPadding: 1,
        lineColor: [200, 200, 200],
        lineWidth: 0.1
      },
      bodyStyles: { 
        fontSize: 7, 
        textColor: [30, 41, 59],
        cellPadding: 0.8,
        valign: 'middle',
        lineColor: [220, 220, 220],
        lineWidth: 0.1
      },
      alternateRowStyles: {
        fillColor: [248, 250, 252]
      },
      columnStyles: getColumnStyles(),
      margin: { left: 8, right: 8, top: 10, bottom: 15 },
      styles: {
        font: 'helvetica',
        overflow: 'linebreak'
      },
      didParseCell: (data) => {
        if (data.section === 'body') {
          const lastIndex = head[0].length - 1;
          if (data.column.index === lastIndex) {
            const status = String(data.cell.raw).trim();
            data.cell.styles.fontStyle = 'bold';
            
            const presentStatuses = ['Present', 'PWO', 'Late', 'Early', 'On Time', 'Overtime'];
            if (presentStatuses.includes(status)) data.cell.styles.textColor = [0, 128, 0]; 
            else if (status === 'Absent') data.cell.styles.textColor = [220, 0, 0]; 
            else if (status === 'SPF' || status === 'Missing Out') data.cell.styles.textColor = [255, 140, 0]; 
            else if (status === 'Weekly Off' || status === 'Leave') data.cell.styles.textColor = [0, 0, 255]; 
            else if (status === 'Holiday') data.cell.styles.textColor = [128, 0, 128]; 
          }
        }
      },
      showHead: 'everyPage',
    });

    // Add footer with total page counts
    const pageCount = (doc as any).internal.getNumberOfPages();
    for (let i = 1; i <= pageCount; i++) {
      doc.setPage(i);
      doc.setFontSize(8);
      doc.setTextColor(100, 100, 100);
      const footerY = doc.internal.pageSize.getHeight() - 10;
      doc.text(`Generated By: Contractor HRIS`, 8, footerY);
      doc.text(`Page ${i} of ${pageCount}`, pageWidth - 8, footerY, { align: 'right' });
    }

    doc.save(`${settings.companyName}_Attendance_Audit_${format(new Date(), 'yyyyMMdd_HHmm')}.pdf`);
  };



  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <h2 className="text-2xl font-bold text-slate-900 tracking-tight">Generate Reports</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-1 bg-white rounded-xl border border-slate-200 shadow-sm p-6 space-y-6">
          <div className="space-y-4">
             <h3 className="text-sm font-bold text-slate-700">Report Configuration</h3>

             <div className="flex bg-slate-100 p-1 rounded-lg">
                <button 
                  onClick={() => reprocess('standard')}
                  className={`flex-1 px-2 py-1 rounded-md text-xs font-bold transition-all ${calculationSource === 'standard' ? 'bg-white text-indigo-600 shadow-sm' : 'text-slate-500'}`}
                >
                  Format A
                </button>
                <button 
                  onClick={() => reprocess('multi-time')}
                  className={`flex-1 px-2 py-1 rounded-md text-xs font-bold transition-all ${calculationSource === 'multi-time' ? 'bg-white text-indigo-600 shadow-sm' : 'text-slate-500'}`}
                >
                  Format B
                </button>
                <button 
                  onClick={() => reprocess('all')}
                  className={`flex-1 px-2 py-1 rounded-md text-xs font-bold transition-all ${calculationSource === 'all' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-400'}`}
                >
                  All
                </button>
             </div>
             
             <div className="space-y-4">
               <div>
                  <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">Type</label>
                  <select 
                    value={reportType} 
                    onChange={e => setReportType(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white"
                  >
                    <option value="daily">Daily Attendance</option>
                    <option value="missing">Missing Punches (SPF)</option>
                    <option value="overtime">Overtime Report</option>
                  </select>
               </div>

               <div>
                   <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">Search Employee</label>
                   <input 
                     type="text" 
                     placeholder="Name or ID..." 
                     value={searchTerm}
                     onChange={e => setSearchTerm(e.target.value)}
                     className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white"
                   />
                </div>

                <div>
                   <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">Sort By</label>
                   <select 
                     value={sortBy} 
                     onChange={e => setSortBy(e.target.value as 'id' | 'name')}
                     className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white"
                   >
                     <option value="name">Employee Name</option>
                     <option value="id">Employee ID</option>
                   </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">Department</label>
                  <MultiSelect 
                    options={departments}
                    selected={deptFilter}
                    onChange={setDeptFilter}
                    placeholder="All Departments"
                  />
                </div>
               
               <div className="space-y-2">
                  <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider">Date Range</label>
                  <div className="grid grid-cols-2 gap-2">
                    <div className="relative">
                      <Calendar className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
                      <input 
                        type="date" 
                        value={startDate}
                        onChange={(e) => setStartDate(e.target.value)}
                        className="w-full pl-8 pr-2 py-2 border border-slate-300 rounded-lg text-xs text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      />
                    </div>
                    <div className="relative">
                      <Calendar className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
                      <input 
                        type="date" 
                        value={endDate}
                        onChange={(e) => setEndDate(e.target.value)}
                        className="w-full pl-8 pr-2 py-2 border border-slate-300 rounded-lg text-xs text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      />
                    </div>
                  </div>
               </div>
             </div>
          </div>

          <div className="pt-6 border-t border-slate-100 flex flex-col gap-3">
            <div className="grid grid-cols-2 gap-3">
              <button 
                onClick={handleExport}
                className="flex items-center justify-center gap-2 bg-indigo-600 text-white px-4 py-2 rounded-lg text-sm font-bold shadow-sm hover:bg-indigo-700 transition"
              >
                <Download className="w-4 h-4" /> Excel
              </button>
              <button 
                onClick={handleExportCSV}
                className="flex items-center justify-center gap-2 bg-slate-800 text-white px-4 py-2 rounded-lg text-sm font-bold shadow-sm hover:bg-slate-900 transition"
              >
                <FileSpreadsheet className="w-4 h-4" /> CSV
              </button>
            </div>
            <button 
              onClick={handlePrintPDF}
              className="w-full flex items-center justify-center gap-2 border border-slate-200 text-slate-700 px-4 py-2 rounded-lg text-sm font-medium hover:bg-slate-50 transition"
            >
              <FileText className="w-4 h-4" /> Export PDF
            </button>
            <button 
              onClick={handleSyncToSheets}
              disabled={isSyncing}
              className="w-full flex items-center justify-center gap-2 bg-green-600 text-white px-4 py-2 rounded-lg text-sm font-bold shadow-sm hover:bg-green-700 transition disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isSyncing ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" /> Syncing...
                </>
              ) : (
                <>
                  <FileSpreadsheet className="w-4 h-4" /> Sync to Google Sheets
                </>
              )}
            </button>
            
            <button 
              onClick={() => {
                setStartDate('1970-01-01');
                setEndDate('2099-12-31');
              }}
              className="w-full flex items-center justify-center gap-2 text-indigo-600 px-4 py-2 rounded-lg text-xs font-bold hover:bg-indigo-50 transition border border-transparent"
            >
              <Archive className="w-3.5 h-3.5" /> Select All Date Records
            </button>
          </div>
        </div>
        
        <div className="md:col-span-2 space-y-6">
          <div className="bg-white p-6 rounded-lg border border-slate-200 shadow-sm">
            <h3 className="text-sm font-semibold text-slate-900 uppercase tracking-normal mb-6">Efficiency Trends</h3>
            <div className="h-[250px]">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={attendanceTrends}>
                  <defs>
                    <linearGradient id="colorPresent" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#4f46e5" stopOpacity={0.1}/>
                      <stop offset="95%" stopColor="#4f46e5" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                  <XAxis dataKey="date" axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: '#64748b', fontWeight: 600 }} />
                  <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: '#64748b', fontWeight: 600 }} />
                  <Tooltip contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }} />
                  <Area type="monotone" dataKey="present" stroke="#4f46e5" fillOpacity={1} fill="url(#colorPresent)" strokeWidth={3} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="bg-white p-6 rounded-lg border border-slate-200 shadow-sm">
            <h3 className="text-sm font-semibold text-slate-900 uppercase tracking-normal mb-6">OT by Department (Approved)</h3>
            <div className="h-[250px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={deptOTData} layout="vertical">
                  <CartesianGrid strokeDasharray="3 3" horizontal={true} vertical={false} stroke="#f1f5f9" />
                  <XAxis type="number" axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: '#64748b', fontWeight: 600 }} />
                  <YAxis dataKey="name" type="category" axisLine={false} tickLine={false} width={100} tick={{ fontSize: 10, fill: '#64748b', fontWeight: 600 }} />
                  <Tooltip 
                    contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                    cursor={{ fill: '#f8fafc' }}
                  />
                  <Bar dataKey="hours" fill="#4f46e5" radius={[0, 4, 4, 0]} barSize={20} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
