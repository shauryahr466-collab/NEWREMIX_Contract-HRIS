import React, { useMemo, useState } from 'react';
import { useAppStore } from '../store';
import { format, parseISO } from 'date-fns';
import { CalendarRange, Search, CheckCircle2, AlertCircle, Download, Clock, Info, Plus, Save, ShieldCheck, ShieldAlert, Trash2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { toast } from 'sonner';
import * as XLSX from 'xlsx';

export default function SBL() {
  const { sblRecords, employees, updateSBL, addSBL, deleteSBL, globalSearchTerm } = useAppStore();
  const [searchTerm, setSearchTerm] = useState('');
  const activeSearch = searchTerm || globalSearchTerm;
  const [statusFilter, setStatusFilter] = useState<'All' | 'Pending' | 'Approved' | 'Rejected' | 'Final Confirmed'>('All');
  const [designationFilter, setDesignationFilter] = useState<string>('All');
  const [contractorFilter, setContractorFilter] = useState<string>('All');
  const [isModalOpen, setIsModalOpen] = useState(false);

  const [formData, setFormData] = useState({
    employeeId: '',
    date: format(new Date(), 'yyyy-MM-dd'),
    leaveType: 'SBL' as 'SBL' | 'Comp Leave',
    duration: 'Full Day',
    reason: ''
  });

  const [selectedIds, setSelectedIds] = useState<string[]>([]);

  const handleSelect = (id: string) => {
    setSelectedIds(prev => prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]);
  };

  const handleBulkDelete = async () => {
    if (selectedIds.length === 0) return;
    if (!window.confirm(`Are you sure you want to delete ${selectedIds.length} selected SBL records?`)) return;

    const tId = toast.loading('Deleting records...');
    try {
      for (const id of selectedIds) {
        await deleteSBL(id);
      }
      setSelectedIds([]);
      toast.success(`Successfully deleted ${selectedIds.length} records`, { id: tId });
    } catch (e) {
      toast.error('Bulk delete failed', { id: tId });
    }
  };

  const handleDeleteSBL = async (id: string) => {
    try {
      await deleteSBL(id);
      toast.success('SBL record deleted');
    } catch (e) {
      toast.error('Delete failed');
    }
  };

  const filteredRecords = useMemo(() => {
    return sblRecords.filter(record => {
      const emp = employees.find(e => e.id === record.employeeId);
      const matchesSearch = !activeSearch || 
        emp?.name.toLowerCase().includes(activeSearch.toLowerCase()) || 
        record.employeeId.toLowerCase().includes(activeSearch.toLowerCase()) ||
        emp?.designation?.toLowerCase().includes(activeSearch.toLowerCase());
      const matchesStatus = statusFilter === 'All' || record.status === statusFilter;
      const matchesDesignation = designationFilter === 'All' || emp?.designation === designationFilter;
      const matchesContractor = contractorFilter === 'All' || emp?.contractorName === contractorFilter;
      return matchesSearch && matchesStatus && matchesDesignation && matchesContractor;
    }).sort((a, b) => a.date.localeCompare(b.date));
  }, [sblRecords, employees, activeSearch, statusFilter, designationFilter, contractorFilter]);

  const stats = useMemo(() => ({
    total: sblRecords.length,
    pending: sblRecords.filter(r => r.status === 'Pending').length,
    approved: sblRecords.filter(r => r.status === 'Approved').length,
  }), [sblRecords]);

  const handleStatusChange = async (id: string, status: 'Approved' | 'Rejected' | 'Final Confirmed' | 'Not Approved') => {
    try {
      await updateSBL(id, { status, approvedBy: 'Admin' });
      toast.success(`Status updated to ${status}`);
    } catch (e) {
      toast.error('Operation failed');
    }
  };

  const handleAddSBL = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.employeeId || !formData.date || !formData.reason) {
      toast.error('Please fill all required fields');
      return;
    }

    try {
      await addSBL({
        ...formData,
        status: 'Approved',
        approvedBy: 'Admin'
      });
      toast.success('SBL record added successfully');
      setIsModalOpen(false);
      setFormData({
        employeeId: '',
        date: format(new Date(), 'yyyy-MM-dd'),
        leaveType: 'SBL',
        duration: 'Full Day',
        reason: ''
      });
    } catch (e) {
      toast.error('Failed to add record');
    }
  };

  const handleExport = () => {
    try {
      const data = filteredRecords.map(record => {
        const emp = employees.find(e => e.id === record.employeeId);
        return {
          'Employee Name': emp?.name || 'Unknown',
          'Employee ID': record.employeeId,
          'Department': emp?.department || '-',
          'Designation': emp?.designation || '-',
          'Contractor': emp?.contractorName || '-',
          'Date': format(parseISO(record.date), 'dd MMM yyyy'),
          'Leave Type': record.leaveType,
          'Duration': record.duration,
          'Status': record.status,
          'Approved By': record.approvedBy || '-',
          'Reason': record.reason || ''
        };
      });

      const ws = XLSX.utils.json_to_sheet(data);
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, 'SBL Summary');
      
      const fileName = `SBL_Summary_${format(new Date(), 'yyyy-MM-dd')}.xlsx`;
      XLSX.writeFile(wb, fileName);
      toast.success('SBL Summary exported successfully');
    } catch (error) {
      toast.error('Failed to export summary');
    }
  };

  const handleExportConfirmed = () => {
    try {
      const confirmedRecords = sblRecords.filter(r => r.status === 'Final Confirmed');
      if (confirmedRecords.length === 0) {
        toast.error('No confirmed records to export');
        return;
      }

      const data = confirmedRecords.map(record => {
        const emp = employees.find(e => e.id === record.employeeId);
        return {
          'Employee Name': emp?.name || 'Unknown',
          'Employee ID': record.employeeId,
          'Department': emp?.department || '-',
          'Date': format(parseISO(record.date), 'dd MMM yyyy'),
          'Leave Type': record.leaveType,
          'Duration': record.duration,
          'Audit Status': 'Final Confirmed',
          'Export Date': format(new Date(), 'dd MMM yyyy')
        };
      });

      const ws = XLSX.utils.json_to_sheet(data);
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, 'Final Confirmed SBL');
      
      const fileName = `Confirmed_SBL_${format(new Date(), 'MMMM_yyyy')}.xlsx`;
      XLSX.writeFile(wb, fileName);
      toast.success('Monthly Final Report exported');
    } catch (error) {
      toast.error('Export failed');
    }
  };

  return (
    <div className="space-y-6 pb-20">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-semibold text-slate-900 tracking-tight flex items-center gap-2">
            <CalendarRange className="w-6 h-6 text-sky-600" />
            SBL Management
          </h2>
          <p className="text-sm text-slate-500 font-bold uppercase tracking-normal mt-1">Short Break Leave Tracking</p>
        </div>
        <div className="flex gap-2">
          <button 
            onClick={() => setIsModalOpen(true)}
            className="flex items-center gap-2 bg-sky-600 text-white px-4 py-2 rounded-xl text-sm font-semibold shadow-lg shadow-sky-100 hover:bg-sky-700 transition-all"
          >
            <Plus className="w-4 h-4" />
            New SBL Request
          </button>
          <button 
            onClick={handleExportConfirmed}
            className="flex items-center gap-2 bg-emerald-600 text-white px-4 py-2 rounded-xl text-sm font-semibold shadow-lg shadow-emerald-100 hover:bg-emerald-700 transition-all"
          >
            <ShieldCheck className="w-4 h-4" />
            Confirmed Summary
          </button>
          <button 
            onClick={handleExport}
            className="flex items-center gap-2 bg-white border border-slate-200 px-4 py-2 rounded-xl text-sm font-semibold text-slate-600 hover:bg-slate-50 transition-all shadow-sm"
          >
            <Download className="w-4 h-4" />
            Export SBL Summary
          </button>
          {selectedIds.length > 0 && (
            <button 
              onClick={handleBulkDelete}
              className="flex items-center gap-2 bg-rose-600 text-white px-4 py-2 rounded-xl text-sm font-semibold shadow-lg shadow-rose-100 hover:bg-rose-700 transition-all font-sans"
            >
              <Trash2 className="w-4 h-4" />
              Delete Selected ({selectedIds.length})
            </button>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <StatCard 
          label="Total Requests" 
          value={stats.total} 
          icon={<CalendarRange className="w-5 h-5 text-sky-500" />} 
          color="sky" 
          onClick={() => setStatusFilter('All')}
        />
        <StatCard 
          label="Awaiting Approval" 
          value={stats.pending} 
          icon={<Clock className="w-5 h-5 text-amber-500" />} 
          color="amber" 
          onClick={() => setStatusFilter('Pending')}
        />
        <StatCard 
          label="Approved SBL" 
          value={stats.approved} 
          icon={<CheckCircle2 className="w-5 h-5 text-emerald-500" />} 
          color="emerald" 
          onClick={() => setStatusFilter('Approved')}
        />
        <StatCard 
          label="Rejected SBL" 
          value={stats.total - stats.approved - stats.pending} 
          icon={<AlertCircle className="w-5 h-5 text-rose-500" />} 
          color="rose" 
          onClick={() => setStatusFilter('Rejected')}
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-2 space-y-4">
          <div className="bg-white dark:bg-slate-900/50 dark:backdrop-blur-xl p-4 rounded-lg border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
            <div className="flex flex-wrap items-center gap-4">
              <div className="relative flex-1 min-w-[240px]">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input 
                  type="text" 
                  placeholder="Search employee..."
                  className="w-full pl-10 pr-4 py-2 bg-slate-50 dark:bg-slate-800 dark:text-white border-none rounded-xl text-sm focus:ring-2 focus:ring-indigo-500/20"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              
              <select 
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value as any)}
                className="px-4 py-2 bg-slate-50 dark:bg-slate-800 border-none rounded-xl text-sm font-bold text-slate-600 dark:text-slate-300 focus:ring-2 focus:ring-indigo-500/20"
              >
                <option value="All">All Status</option>
                <option value="Pending">Pending</option>
                <option value="Approved">Approved</option>
                <option value="Rejected">Rejected</option>
                <option value="Final Confirmed">Final Confirmed</option>
              </select>

              <select 
                value={designationFilter}
                onChange={(e) => setDesignationFilter(e.target.value)}
                className="px-4 py-2 bg-slate-50 border-none rounded-xl text-sm font-bold text-slate-600 focus:ring-2 focus:ring-indigo-500/20"
              >
                <option value="All">All Designations</option>
                {[...new Set(employees.map(e => e.designation).filter(Boolean))].map(d => (
                  <option key={d} value={d}>{d}</option>
                ))}
              </select>

              <select 
                value={contractorFilter}
                onChange={(e) => setContractorFilter(e.target.value)}
                className="px-4 py-2 bg-slate-50 border-none rounded-xl text-sm font-bold text-slate-600 focus:ring-2 focus:ring-indigo-500/20"
              >
                <option value="All">All Contractors</option>
                {[...new Set(employees.map(e => e.contractorName).filter(Boolean))].map(c => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>
            </div>

            <div className="overflow-x-auto rounded-xl border border-slate-100">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-slate-50/50 text-xs font-semibold text-slate-400 uppercase tracking-normal">
                    <th className="px-4 py-4 w-12 text-center">
                      <input 
                        type="checkbox"
                        checked={filteredRecords.length > 0 && selectedIds.length === filteredRecords.length}
                        onChange={(e) => setSelectedIds(e.target.checked ? filteredRecords.map(r => r.id) : [])}
                        className="w-4 h-4 rounded border-slate-300 text-sky-600 cursor-pointer"
                      />
                    </th>
                    <th className="px-6 py-4">Employee</th>
                    <th className="px-6 py-4">Date</th>
                    <th className="px-6 py-4">Type</th>
                    <th className="px-6 py-4">Status</th>
                    <th className="px-6 py-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-50">
                  {filteredRecords.map((record, idx) => {
                    const emp = employees.find(e => e.id === record.employeeId);
                    return (
                      <motion.tr 
                        key={record.id}
                        initial={{ opacity: 0, y: 5 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: idx * 0.02 }}
                        className={`hover:bg-slate-50/50 group transition-colors ${selectedIds.includes(record.id) ? 'bg-sky-50/50' : ''}`}
                      >
                        <td className="px-4 py-4 text-center">
                          <input 
                            type="checkbox"
                            checked={selectedIds.includes(record.id)}
                            onChange={() => handleSelect(record.id)}
                            className="w-4 h-4 rounded border-slate-300 text-sky-600 cursor-pointer"
                          />
                        </td>
                        <td className="px-6 py-4">
                          <p className="text-sm font-semibold text-slate-900 leading-none">{emp?.name || 'Unknown'}</p>
                          <p className="text-xs font-bold text-slate-400 mt-1 uppercase">{record.employeeId}</p>
                        </td>
                        <td className="px-6 py-4 text-sm font-bold text-slate-600">
                          {format(parseISO(record.date), 'dd MMM yyyy')}
                        </td>
                        <td className="px-6 py-4">
                          <span className="text-xs font-semibold uppercase tracking-normal p-1.5 bg-sky-50 text-sky-600 rounded">
                            {record.leaveType}
                          </span>
                        </td>
                        <td className="px-6 py-4">
                          <span className={`text-xs font-semibold uppercase tracking-normal px-2 py-1 rounded-lg ${
                            record.status === 'Final Confirmed' ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-100' :
                            record.status === 'Not Approved' ? 'bg-slate-900 text-white' :
                            record.status === 'Approved' ? 'bg-emerald-50 text-emerald-600' :
                            record.status === 'Rejected' ? 'bg-rose-50 text-rose-600' : 'bg-amber-50 text-amber-600'
                          }`}>
                            {record.status}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-right space-x-1">
                          {record.status === 'Pending' && (
                            <>
                              <button 
                                onClick={() => handleStatusChange(record.id, 'Approved')}
                                className="p-1.5 text-emerald-600 hover:bg-emerald-50 rounded-lg transition-colors"
                                title="Approve"
                              >
                                <CheckCircle2 className="w-4 h-4" />
                              </button>
                              <button 
                                onClick={() => handleStatusChange(record.id, 'Rejected')}
                                className="p-1.5 text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                                title="Reject"
                              >
                                <AlertCircle className="w-4 h-4" />
                              </button>
                            </>
                          )}
                          {record.status === 'Approved' && (
                            <div className="flex justify-end gap-1">
                               <button 
                                onClick={() => handleStatusChange(record.id, 'Final Confirmed')}
                                className="px-2 py-1 bg-indigo-50 text-indigo-600 text-xs font-semibold uppercase rounded hover:bg-indigo-600 hover:text-white transition-all flex items-center gap-1"
                                title="Audit: Final Confirm"
                              >
                                <ShieldCheck className="w-3 h-3" />
                                Final Confirm
                              </button>
                              <button 
                                onClick={() => handleStatusChange(record.id, 'Not Approved')}
                                className="px-2 py-1 bg-slate-50 text-slate-600 text-xs font-semibold uppercase rounded hover:bg-slate-900 hover:text-white transition-all flex items-center gap-1"
                                title="Audit: Not Approved"
                              >
                                <ShieldAlert className="w-3 h-3" />
                                Not Approved
                              </button>
                            </div>
                          )}
                          <button 
                            onClick={(e) => {
                              e.stopPropagation();
                              if (window.confirm('Are you sure you want to delete this SBL record?')) {
                                handleDeleteSBL(record.id);
                              }
                            }}
                            className="p-1.5 text-rose-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                            title="Delete"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </td>
                      </motion.tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        <div className="space-y-4">
          <div className="bg-white p-6 rounded-lg border border-slate-200 shadow-sm">
             <h3 className="text-sm font-semibold text-slate-900 uppercase tracking-normal mb-6">Approval Distribution</h3>
             <div className="space-y-6">
                <DistributionItem label="Approved" count={stats.approved} total={stats.total} color="bg-emerald-500" />
                <DistributionItem label="Pending" count={stats.pending} total={stats.total} color="bg-amber-500" />
                <DistributionItem label="Rejected" count={stats.total - stats.approved - stats.pending} total={stats.total} color="bg-rose-500" />
             </div>
             
             <div className="mt-8 p-4 bg-slate-50 rounded-xl border border-slate-100">
                <div className="flex gap-3">
                   <Info className="w-5 h-5 text-indigo-500 shrink-0" />
                   <p className="text-xs text-slate-500 font-bold uppercase tracking-tight leading-relaxed">
                     SBL (Substitute Leave) is credited to non-OT eligible staff working on Weekly Offs or Holidays. Admin approval is final.
                   </p>
                </div>
             </div>
          </div>
        </div>
      </div>

      <AnimatePresence>
        {isModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsModalOpen(false)}
              className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative w-full max-w-lg bg-white rounded-lg shadow-md overflow-hidden border border-white"
            >
              <div className="px-8 py-6 border-b border-slate-100 flex items-center justify-between bg-white">
                <div>
                  <h3 className="text-xl font-semibold text-slate-900">New SBL Entry</h3>
                  <p className="text-xs font-bold text-slate-400 uppercase tracking-normal mt-0.5">Substitute Leave Registration</p>
                </div>
                <button 
                  onClick={() => setIsModalOpen(false)}
                  className="w-10 h-10 flex items-center justify-center rounded-xl bg-slate-50 text-slate-400 hover:bg-slate-100 transition-colors"
                >
                  <Plus className="w-5 h-5 rotate-45" />
                </button>
              </div>

              <form onSubmit={handleAddSBL} className="p-5 space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-xs font-semibold text-slate-400 uppercase tracking-normal ml-1">Employee</label>
                    <select 
                      required
                      value={formData.employeeId}
                      onChange={e => setFormData({ ...formData, employeeId: e.target.value })}
                      className="w-full px-4 py-3 bg-slate-50 border-none rounded-lg text-sm font-bold text-slate-900 focus:ring-2 focus:ring-sky-500/20"
                    >
                      <option value="">Staff Select...</option>
                      {employees.map(emp => (
                        <option key={emp.id} value={emp.id}>{emp.name} ({emp.id})</option>
                      ))}
                    </select>
                  </div>

                  <div className="space-y-2">
                    <label className="text-xs font-semibold text-slate-400 uppercase tracking-normal ml-1">Credited Date</label>
                    <input 
                      type="date"
                      required
                      value={formData.date}
                      onChange={e => setFormData({ ...formData, date: e.target.value })}
                      className="w-full px-4 py-3 bg-slate-50 border-none rounded-lg text-sm font-bold text-slate-900 focus:ring-2 focus:ring-sky-500/20"
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-xs font-semibold text-slate-400 uppercase tracking-normal ml-1">Leave Type</label>
                    <select 
                      value={formData.leaveType}
                      onChange={e => setFormData({ ...formData, leaveType: e.target.value as any })}
                      className="w-full px-4 py-3 bg-slate-50 border-none rounded-lg text-sm font-bold text-slate-900 focus:ring-2 focus:ring-sky-500/20"
                    >
                      <option value="SBL">Substitute Leave (SBL)</option>
                      <option value="Comp Leave">Compensatory Leave</option>
                    </select>
                  </div>

                  <div className="space-y-2">
                    <label className="text-xs font-semibold text-slate-400 uppercase tracking-normal ml-1">Duration</label>
                    <select 
                      value={formData.duration}
                      onChange={e => setFormData({ ...formData, duration: e.target.value })}
                      className="w-full px-4 py-3 bg-slate-50 border-none rounded-lg text-sm font-bold text-slate-900 focus:ring-2 focus:ring-sky-500/20"
                    >
                      <option value="Full Day">Full Day</option>
                      <option value="Half Day (First)">Half Day (First)</option>
                      <option value="Half Day (Second)">Half Day (Second)</option>
                    </select>
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-semibold text-slate-400 uppercase tracking-normal ml-1">Official Reason</label>
                  <textarea 
                    required
                    value={formData.reason}
                    onChange={e => setFormData({ ...formData, reason: e.target.value })}
                    className="w-full px-4 py-3 bg-slate-50 border-none rounded-lg text-sm font-bold text-slate-900 focus:ring-2 focus:ring-sky-500/20 min-h-[80px]"
                    placeholder="E.g. Worked on Public Holiday (Jan 26th)..."
                  />
                </div>

                <button 
                  type="submit"
                  className="w-full py-4 bg-sky-600 text-white rounded-lg text-sm font-semibold shadow-sm shadow-sky-100 hover:bg-sky-700 transition-all flex items-center justify-center gap-2"
                >
                  <Save className="w-4 h-4" />
                  Register SBL Entry
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

function StatCard({ label, value, icon, color, onClick }: any) {
  const colors: any = {
    sky: 'bg-sky-50 dark:bg-sky-900/10 text-sky-600 border-sky-100 dark:border-sky-800/50 hover:bg-sky-100 dark:hover:bg-sky-800/20',
    amber: 'bg-amber-50 dark:bg-amber-900/10 text-amber-600 border-amber-100 dark:border-amber-800/50 hover:bg-amber-100 dark:hover:bg-amber-800/20',
    emerald: 'bg-emerald-50 dark:bg-emerald-900/10 text-emerald-600 border-emerald-100 dark:border-emerald-800/50 hover:bg-emerald-100 dark:hover:bg-emerald-800/20',
    rose: 'bg-rose-50 dark:bg-rose-900/10 text-rose-600 border-rose-100 dark:border-rose-800/50 hover:bg-rose-100 dark:hover:bg-rose-800/20',
  };
  return (
    <div 
      onClick={onClick}
      className={`p-5 rounded-lg border shadow-sm ${colors[color]} transition-all ${onClick ? 'cursor-pointer active:scale-95' : ''}`}
    >
       <div className="flex items-center justify-between mb-3">
          <div className="w-10 h-10 bg-white dark:bg-slate-800 rounded-xl flex items-center justify-center shadow-sm dark:border dark:border-slate-700">{icon}</div>
          <span className="text-2xl font-semibold">{value || 0}</span>
       </div>
       <p className="text-xs font-semibold uppercase tracking-normal opacity-60 ml-1">{label}</p>
    </div>
  );
}

function DistributionItem({ label, count, total, color }: any) {
  const percentage = total > 0 ? (count / total) * 100 : 0;
  return (
    <div className="space-y-2">
       <div className="flex justify-between text-xs font-semibold uppercase tracking-normal">
          <span className="text-slate-500">{label}</span>
          <span className="text-slate-900">{count} ({Math.round(percentage)}%)</span>
       </div>
       <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
          <motion.div 
            initial={{ width: 0 }}
            animate={{ width: `${percentage}%` }}
            className={`h-full ${color}`}
          />
       </div>
    </div>
  );
}
