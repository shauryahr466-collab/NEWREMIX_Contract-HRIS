import React, { useState, useEffect } from 'react';
import { useAppStore } from '../store';
import { Save, Plus, Trash2, AlertTriangle, Database, Download, CheckCircle2, XCircle, X } from 'lucide-react';
import { format } from 'date-fns';
import { ShiftMaster } from '../types';
import { generateId } from '../lib/utils';
import { motion, AnimatePresence } from 'motion/react';

export function SettingsPage() {
  const { settings, setSettings, employees, setEmployees, punches, setPunches, shiftAssignments, setShiftAssignments, clearAllData, quotaExceeded } = useAppStore();
  const [localSettings, setLocalSettings] = useState(settings);
  const [isWiping, setIsWiping] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [dismissedWarnings, setDismissedWarnings] = useState(false);
  const [isConfirmingPurge, setIsConfirmingPurge] = useState(false);
  const [purgeConfirmationInput, setPurgeConfirmationInput] = useState('');
  const [notification, setNotification] = useState<{ type: 'success' | 'error', message: string } | null>(null);

  useEffect(() => {
    setLocalSettings(settings);
    setDismissedWarnings(false);
  }, [settings]);

  useEffect(() => {
    if (notification) {
      const timer = setTimeout(() => setNotification(null), 3000);
      return () => clearTimeout(timer);
    }
  }, [notification]);

  const handleSave = async () => {
    if (quotaExceeded) {
      setNotification({ type: 'error', message: 'Database write limit reached.' });
      return;
    }
    
    setIsSaving(true);
    try {
      await setSettings(localSettings);
      setNotification({ type: 'success', message: 'Settings saved successfully!' });
    } catch (err) {
      setNotification({ type: 'error', message: 'Failed to save settings.' });
    } finally {
      setIsSaving(false);
    }
  };

  const handleClearAllData = async () => {
    if (quotaExceeded) return;
    if (purgeConfirmationInput !== 'DELETE') return;
    
    try {
      setIsWiping(true);
      setIsConfirmingPurge(false);
      await clearAllData();
      setPurgeConfirmationInput('');
    } finally {
      setIsWiping(false);
    }
  };

  const handleLoadSampleData = async () => {
    if (quotaExceeded) {
      alert('Cannot load sample data: Database write limit reached.');
      return;
    }
    if (confirm('Load sample employee data? This will add 3 example employees and initialize attendance.')) {
      await setEmployees([
        {
          id: 'EMP001',
          name: 'Alice Johnson',
          department: 'Bio',
          designation: 'Geneticist',
          shiftId: 'shift-1',
          joiningDate: '2024-01-15',
          status: 'Active',
          weeklyOff: 'Sunday',
          otEligible: true,
          targetWorkingHours: 8
        },
        {
          id: 'EMP002',
          name: 'Robert Smith',
          department: 'Operations',
          designation: 'Technician',
          shiftId: 'shift-1',
          joiningDate: '2024-02-01',
          status: 'Active',
          weeklyOff: 'Sunday',
          otEligible: true,
          targetWorkingHours: 8
        },
        {
          id: '1211001',
          name: 'Sarah Chen',
          department: 'Bio',
          designation: 'Bioanalyst',
          shiftId: 'shift-1',
          joiningDate: '2024-03-10',
          status: 'Active',
          weeklyOff: 'Sunday',
          otEligible: true,
          targetWorkingHours: 8
        }
      ]);
      setNotification({ type: 'success', message: 'Sample data loaded successfully!' });
    }
  };

  const handleExportBackup = () => {
    const backupData = {
      version: '1.0',
      timestamp: new Date().toISOString(),
      data: {
        employees,
        punches,
        settings,
        shiftAssignments
      }
    };

    const blob = new Blob([JSON.stringify(backupData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Attendance_System_Backup_${format(new Date(), 'yyyyMMdd')}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleImportBackup = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (quotaExceeded) {
      alert('Cannot import: Database write limit reached.');
      return;
    }
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const backup = JSON.parse(event.target?.result as string);
        if (!backup.data) throw new Error('Invalid backup format');

        if (confirm('Restoring will overwrite all current data. Proceed?')) {
          await setEmployees(backup.data.employees);
          await setPunches(backup.data.punches);
          await setSettings(backup.data.settings);
          await setShiftAssignments(backup.data.shiftAssignments);
          setNotification({ type: 'success', message: 'System restored successfully. Refreshing...' });
          setTimeout(() => window.location.reload(), 2000);
        }
      } catch (err) {
        setNotification({ type: 'error', message: 'Failed to restore: Invalid backup file.' });
      }
    };
    reader.readAsText(file);
  };

  const addShift = () => {
    const newShift: ShiftMaster = {
      id: generateId(),
      name: 'New Shift',
      startTime: '09:00',
      endTime: '18:00',
      isNightShift: false
    };
    setLocalSettings({
      ...localSettings,
      shifts: [...(localSettings.shifts || []), newShift]
    });
  };

  const removeShift = (id: string) => {
    setLocalSettings({
      ...localSettings,
      shifts: localSettings.shifts.filter(s => s.id !== id)
    });
  };

  const updateShift = (id: string, updates: Partial<ShiftMaster>) => {
    setLocalSettings({
      ...localSettings,
      shifts: localSettings.shifts.map(s => s.id === id ? { ...s, ...updates } : s)
    });
  };

  const getOverlapWarnings = () => {
    const warnings: string[] = [];
    const shifts = localSettings.shifts || [];
    
    // Represent each shift as one or two normalization intervals [start, end] in [0, 1440)
    const getIntervals = (shift: ShiftMaster) => {
      const toMins = (t: string) => {
        if (!t) return null;
        const [h, m] = t.split(':').map(Number);
        if (isNaN(h) || isNaN(m)) return null;
        return h * 60 + m;
      };
      
      const s = toMins(shift.startTime);
      const e = toMins(shift.endTime);
      
      if (s === null || e === null) return []; // Invalid time
      
      if (e < s) {
        // Wraps around midnight: [s, 1440] and [0, e]
        return [[s, 1440], [0, e]];
      } else if (s === e) {
        // 24-hour shift (only if user explicitly sets it, otherwise might be empty)
        // If s and e are 0, it might be unconfigured. Let's assume non-empty.
        if (s === 0 && e === 0 && !shift.startTime) return [];
        return [[0, 1440]];
      }
      return [[s, e]];
    };

    const hasOverlap = (int1: number[], int2: number[]) => {
      // Basic range intersection: max(s1, s2) < min(e1, e2)
      // We use a small epsilon (0.01) or just strict < to allow touching shifts
      return Math.max(int1[0], int2[0]) < Math.min(int1[1], int2[1]);
    };

    for (let i = 0; i < shifts.length; i++) {
      for (let j = i + 1; j < shifts.length; j++) {
        const s1 = shifts[i];
        const s2 = shifts[j];
        
        const ints1 = getIntervals(s1);
        const ints2 = getIntervals(s2);

        let overlapDetected = false;
        for (const i1 of ints1) {
          for (const i2 of ints2) {
            if (hasOverlap(i1, i2)) {
              overlapDetected = true;
              break;
            }
          }
          if (overlapDetected) break;
        }

        if (overlapDetected) {
          warnings.push(`"${s1.name}" and "${s2.name}" have overlapping working hours.`);
        }
      }
    }
    return warnings;
  };

  const shiftWarnings = getOverlapWarnings();

  return (
    <div className="max-w-5xl mx-auto space-y-6 pb-12 relative">
      <AnimatePresence>
        {notification && (
          <motion.div 
            initial={{ opacity: 0, y: -20, x: '-50%' }}
            animate={{ opacity: 1, y: 0, x: '-50%' }}
            exit={{ opacity: 0, y: -20, x: '-50%' }}
            className={`fixed top-6 left-1/2 z-[200] flex items-center gap-3 px-6 py-4 rounded-lg shadow-md border ${
              notification.type === 'success' 
                ? 'bg-emerald-600 border-emerald-500 text-white' 
                : 'bg-red-600 border-red-500 text-white'
            }`}
          >
            {notification.type === 'success' ? (
              <CheckCircle2 className="w-5 h-5" />
            ) : (
              <XCircle className="w-5 h-5" />
            )}
            <span className="font-bold text-sm tracking-tight">{notification.message}</span>
            <button onClick={() => setNotification(null)} className="ml-2 hover:bg-black/10 rounded-full p-1 transition-colors">
              <X className="w-4 h-4" />
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-slate-900 tracking-tight">System Settings</h2>
        
        {JSON.stringify(localSettings) !== JSON.stringify(settings) && (
          <motion.span 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="text-xs font-semibold uppercase tracking-normal bg-amber-100 text-amber-600 px-3 py-1 rounded-full border border-amber-200"
          >
            Unsaved Changes
          </motion.span>
        )}
      </div>
      
      {shiftWarnings.length > 0 && !dismissedWarnings && (
        <div className="bg-amber-50 border border-amber-200 rounded-lg p-5 flex gap-4 animate-in fade-in slide-in-from-top-4 shadow-sm relative group overflow-hidden">
          <div className="absolute top-0 right-0 p-4">
             <button 
                onClick={() => setDismissedWarnings(true)}
                className="text-xs font-bold text-amber-500 hover:text-amber-700 bg-amber-100/50 hover:bg-amber-100 px-3 py-1.5 rounded-lg transition-colors flex items-center gap-1.5"
              >
                Dismiss
              </button>
          </div>
          <div className="p-3 bg-white rounded-lg h-fit border border-amber-200/50 shadow-sm">
            <AlertTriangle className="w-8 h-8 text-amber-500 shrink-0" />
          </div>
          <div className="space-y-3 flex-1 min-w-0">
            <div>
              <p className="text-lg font-semibold text-amber-900 tracking-tight leading-none mb-1">Shift Overlap Detected</p>
              <p className="text-xs text-amber-600 font-medium tracking-tight">The following shifts have conflicting time ranges:</p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-2 max-h-[180px] overflow-y-auto pr-4 custom-scrollbar">
              {shiftWarnings.map((w, i) => (
                <div key={i} className="text-xs text-amber-800/90 font-medium flex items-center gap-2.5 bg-white/40 p-2 rounded-xl border border-amber-200/30">
                  <span className="flex-shrink-0 w-1.5 h-1.5 rounded-full bg-amber-500 shadow-sm" />
                  <span className="truncate">{w}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      <div className="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden divide-y divide-slate-100">
        
        {/* Shift Master Overview Timeline */}
        <div className="p-6 space-y-4">
           <div className="flex items-center justify-between">
              <h3 className="text-lg font-bold text-slate-700">Shift Timeline Visualization</h3>
              <span className="text-xs font-bold text-slate-400 uppercase tracking-normal bg-slate-50 px-2 py-1 rounded">24 Hour View</span>
           </div>
           
           <div className="relative h-20 bg-slate-100 rounded-xl overflow-hidden shadow-inner border border-slate-200">
              {/* Grid Lines */}
              {[0, 4, 8, 12, 16, 20, 24].map(h => (
                <div key={h} className="absolute h-full border-l border-slate-200" style={{ left: `${(h/24)*100}%` }}>
                  <span className="absolute top-1 left-1 text-xs font-bold text-slate-400">{h}:00</span>
                </div>
              ))}
              
              {/* Shift Bars */}
              <div className="relative h-full flex flex-col justify-center gap-1.5 p-2 pt-6">
                {(localSettings.shifts || []).map((shift, i) => {
                  const toMins = (t: string) => {
                    const [h, m] = t.split(':').map(Number);
                    return h * 60 + m;
                  };
                  const start = toMins(shift.startTime);
                  const end = toMins(shift.endTime);
                  const duration = shift.isNightShift || end < start ? (end + 1440 - start) : (end - start);
                  
                  const left = (start / 1440) * 100;
                  const width = (duration / 1440) * 100;
                  
                  // Check for conflict
                  const hasConflict = shiftWarnings.some(w => w.includes(`"${shift.name}"`));
                  
                  // Simple coloring
                  const colors = ['bg-indigo-500', 'bg-emerald-500', 'bg-rose-500', 'bg-amber-500', 'bg-sky-500', 'bg-violet-500'];
                  const colorClass = hasConflict ? 'bg-rose-600 shadow-lg shadow-rose-200 ring-2 ring-rose-300 ring-offset-1' : colors[i % colors.length];

                  return (
                    <div key={shift.id} className="relative group">
                       <div 
                        className={`h-3 rounded-full ${colorClass} ${hasConflict ? 'opacity-100' : 'opacity-80 hover:opacity-100'} transition-all cursor-help relative`}
                        style={{ marginLeft: `${left}%`, width: `${width > 100 ? 100 : width}%` }}
                       >
                         {/* Split segment for wrap-around night shifts */}
                         {left + width > 100 && (
                            <div 
                              className={`absolute h-3 rounded-full ${colorClass} ${hasConflict ? 'opacity-100' : 'opacity-80'}`}
                              style={{ left: `-${left}%`, width: `${(width - (100 - left))}%` }}
                            />
                         )}
                         <div className="absolute -top-6 left-0 invisible group-hover:visible whitespace-nowrap bg-slate-800 text-white text-xs font-bold px-2 py-1 rounded shadow-sm z-20">
                           {hasConflict && <span className="text-rose-300 mr-1">⚠️ OVERLAP:</span>}
                           {shift.name} ({shift.startTime} - {shift.endTime})
                         </div>
                       </div>
                    </div>
                  );
                })}
              </div>
           </div>
        </div>

        {/* Shift Master */}
        <div className="p-6 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-lg font-bold text-slate-700">Shift Master</h3>
              <p className="text-xs text-slate-500 font-medium">Configure multiple working shifts with specific start/end times and grace periods.</p>
            </div>
            <button 
              onClick={addShift}
              className="flex items-center gap-2 px-3 py-1.5 bg-indigo-50 text-indigo-600 rounded-lg text-sm font-bold hover:bg-indigo-100 transition"
            >
              <Plus className="w-4 h-4" /> Add Shift
            </button>
          </div>
          
          <div className="space-y-4">
            {(localSettings.shifts || []).map((shift) => (
              <div key={shift.id} className="p-5 border border-slate-200 rounded-xl bg-white shadow-sm flex flex-wrap xl:flex-nowrap gap-6 items-end transition-all hover:border-indigo-200">
                <div className="flex-1 min-w-[200px]">
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-1.5 tracking-wider">Shift Name</label>
                  <input 
                    type="text"
                    value={shift.name}
                    onChange={e => updateShift(shift.id, { name: e.target.value })}
                    placeholder="e.g. Morning Shift"
                    className="w-full px-3 py-2.5 border border-slate-200 rounded-lg text-sm bg-slate-50/30 focus:bg-white focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
                  />
                </div>
                
                <div className="w-full sm:w-auto min-w-[260px]">
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-1.5 tracking-wider">Working Hours (Start - End)</label>
                  <div className="flex items-center gap-2">
                    <input 
                      type="time"
                      value={shift.startTime}
                      onChange={e => updateShift(shift.id, { startTime: e.target.value })}
                      className="w-full sm:w-32 px-3 py-2.5 border border-slate-200 rounded-lg text-sm bg-slate-50/30 focus:bg-white outline-none"
                    />
                    <span className="text-slate-300 font-bold text-xs uppercase px-1">to</span>
                    <input 
                      type="time"
                      value={shift.endTime}
                      onChange={e => updateShift(shift.id, { endTime: e.target.value })}
                      className="w-full sm:w-32 px-3 py-2.5 border border-slate-200 rounded-lg text-sm bg-slate-50/30 focus:bg-white outline-none"
                    />
                  </div>
                </div>

                <div className="flex gap-4">
                  <div className="w-28">
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1.5 tracking-wider">Grace (Min)</label>
                    <input 
                      type="number"
                      min="0"
                      value={shift.graceTime ?? 15}
                      onChange={e => updateShift(shift.id, { graceTime: Number(e.target.value) })}
                      className="w-full px-3 py-2.5 border border-slate-200 rounded-lg text-sm bg-slate-50/30 focus:bg-white outline-none text-center font-mono"
                    />
                  </div>

                  <div className="w-28">
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1.5 tracking-wider">Late (Min)</label>
                    <input 
                      type="number"
                      min="0"
                      value={shift.lateThreshold ?? 30}
                      onChange={e => updateShift(shift.id, { lateThreshold: Number(e.target.value) })}
                      className="w-full px-3 py-2.5 border border-slate-200 rounded-lg text-sm bg-slate-50/30 focus:bg-white outline-none text-center font-mono"
                    />
                  </div>
                </div>

                <div className="flex items-center gap-4 h-[46px] px-4 bg-slate-50/50 border border-slate-200 rounded-lg">
                  <label className="flex items-center gap-2 cursor-pointer group">
                    <input 
                      type="checkbox"
                      checked={shift.isNightShift}
                      onChange={e => updateShift(shift.id, { isNightShift: e.target.checked })}
                      className="w-4 h-4 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500"
                    />
                    <span className="text-xs font-bold text-slate-600 uppercase whitespace-nowrap group-hover:text-indigo-600 transition-colors">Night Shift</span>
                  </label>
                </div>

                <div className="flex items-center h-[46px]">
                  <button 
                    onClick={() => removeShift(shift.id)}
                    className="p-2.5 text-slate-400 hover:text-rose-500 hover:bg-rose-50 rounded-xl transition-all"
                    title="Remove Shift"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
        {/* Calculation Period Control */}
        <div className="p-6 space-y-4 border-t border-slate-100">
          <div>
            <h3 className="text-lg font-bold text-slate-700">Calculation Period Control</h3>
            <p className="text-xs text-slate-500 font-medium">Restrict attendance processing to a specific date range to improve performance.</p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            <div>
              <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">Calculation Start Date</label>
              <input 
                type="date" 
                value={localSettings.calculationStartDate || ''}
                onChange={e => setLocalSettings({...localSettings, calculationStartDate: e.target.value})}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">Calculation End Date</label>
              <input 
                type="date" 
                value={localSettings.calculationEndDate || ''}
                onChange={e => setLocalSettings({...localSettings, calculationEndDate: e.target.value})}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
              />
            </div>
          </div>
          <p className="text-xs text-amber-600 font-medium bg-amber-50 p-2 rounded-lg border border-amber-100 flex items-center gap-2">
            <AlertTriangle className="w-3 h-3" /> 
            Leave blank to process all available punch data (might be slow for very large datasets).
          </p>
        </div>

        <div className="p-6 space-y-4">
          <h3 className="text-lg font-bold text-slate-700">Company Profile</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">Company Name</label>
              <input 
                type="text" 
                value={localSettings.companyName}
                onChange={e => setLocalSettings({...localSettings, companyName: e.target.value})}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">Report Title</label>
              <input 
                type="text" 
                value={localSettings.reportTitle}
                onChange={e => setLocalSettings({...localSettings, reportTitle: e.target.value})}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
              />
            </div>
          </div>
        </div>

        {/* Attendance Rules */}
        <div className="p-6 space-y-4">
          
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            <div>
              <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">Standard Shift Start</label>
              <input 
                type="time" 
                value={localSettings.shiftStartTime}
                onChange={e => setLocalSettings({...localSettings, shiftStartTime: e.target.value})}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">Standard Shift End</label>
              <input 
                type="time" 
                value={localSettings.shiftEndTime}
                onChange={e => setLocalSettings({...localSettings, shiftEndTime: e.target.value})}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">Merge Duplicate Punches (Mins)</label>
              <input 
                type="number" 
                min="0"
                value={localSettings.duplicateMergeTime}
                onChange={e => setLocalSettings({...localSettings, duplicateMergeTime: Number(e.target.value)})}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">Grace Period (Mins)</label>
              <input 
                type="number" 
                min="0"
                value={localSettings.graceTime}
                onChange={e => setLocalSettings({...localSettings, graceTime: Number(e.target.value)})}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">Late Threshold (Mins)</label>
              <input 
                type="number" 
                min="0"
                value={localSettings.lateThreshold}
                onChange={e => setLocalSettings({...localSettings, lateThreshold: Number(e.target.value)})}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">Overtime Threshold (Hrs/Day)</label>
              <input 
                type="number" 
                min="0" step="0.5"
                value={localSettings.overtimeThreshold}
                onChange={e => setLocalSettings({...localSettings, overtimeThreshold: Number(e.target.value)})}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
              />
            </div>
          </div>
        </div>

        <div className="p-4 bg-slate-50 flex justify-end">
          <button 
            onClick={handleSave}
            disabled={quotaExceeded || isSaving}
            className="flex items-center gap-2 px-6 py-2.5 bg-indigo-600 text-white rounded-xl text-sm font-bold shadow-lg shadow-indigo-100 hover:bg-indigo-700 transition disabled:bg-slate-400 disabled:cursor-not-allowed min-w-[180px] justify-center"
          >
            {isSaving ? (
              <div className="w-4 h-4 border-2 border-white/20 border-t-white rounded-full animate-spin" />
            ) : (
              <Save className="w-4 h-4" />
            )}
            {isSaving ? 'Saving Changes...' : 'Save Configuration'}
          </button>
        </div>
      </div>

      {/* System Maintenance */}
      <div className="bg-white border border-red-200 rounded-xl shadow-sm overflow-hidden divide-y divide-red-50">
        <div className="p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-2 bg-red-50 rounded-lg">
              <AlertTriangle className="w-5 h-5 text-red-600" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-slate-800">System Maintenance</h3>
              <p className="text-xs text-slate-500 font-medium tracking-tight">Destructive actions for clearing system state</p>
            </div>
          </div>
          
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-4">
            <div className="space-y-1">
              <p className="text-sm font-bold text-slate-900">Backup, Recovery & Setup</p>
              <p className="text-xs text-slate-500 font-medium">Download all system data for desktop storage or seed with example records.</p>
            </div>
            <div className="flex flex-wrap gap-2">
              <button 
                onClick={handleLoadSampleData}
                className="flex items-center gap-2 px-4 py-2 bg-emerald-600 text-white rounded-lg text-sm font-bold shadow-sm hover:bg-emerald-700 transition"
              >
                <Plus className="w-4 h-4" /> Load Sample Data
              </button>
              <button 
                onClick={handleExportBackup}
                className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-lg text-sm font-bold shadow-sm hover:bg-indigo-700 transition"
              >
                <Download className="w-4 h-4" /> Export System Backup
              </button>
              <label className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-200 text-slate-600 rounded-lg text-sm font-bold shadow-sm hover:bg-slate-50 transition cursor-pointer">
                <Plus className="w-4 h-4" /> Restore from File
                <input type="file" accept=".json" onChange={handleImportBackup} className="hidden" />
              </label>
            </div>
          </div>
          
          <div className="bg-red-50/50 border border-red-100 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="space-y-1">
              <p className="text-sm font-bold text-red-900">Clear All Application Data</p>
              <p className="text-xs text-red-700">Wipe all employees, punch logs, and shift assignments.</p>
              <p className="text-xs text-red-500 font-bold mt-1">
                {quotaExceeded ? 'Write-lock active: Daily quota reached.' : 'Note: Each deletion counts as a database write. Large volumes may hit your daily Firestore quota.'}
              </p>
            </div>
            <button 
              onClick={() => {
                if (quotaExceeded) return;
                setIsConfirmingPurge(true);
              }}
              disabled={isWiping || quotaExceeded}
              className="flex items-center gap-2 px-4 py-2 bg-red-600 text-white rounded-lg text-sm font-bold shadow-sm hover:bg-red-700 transition disabled:opacity-50"
            >
              <Database className={`w-4 h-4 ${isWiping ? 'animate-spin' : ''}`} /> 
              {isWiping ? 'Wiping System...' : quotaExceeded ? 'Quota Exceeded' : 'Purge Everything'}
            </button>
          </div>

          {/* Verification Dialog */}
          {isConfirmingPurge && (
            <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
              <div className="bg-white rounded-lg shadow-md border border-slate-200 max-w-md w-full overflow-hidden animate-in zoom-in-95 duration-200">
                <div className="p-6">
                  <div className="flex items-center gap-3 mb-4 text-red-600">
                    <AlertTriangle className="w-6 h-6" />
                    <h4 className="text-lg font-bold">Critical Action Discovery</h4>
                  </div>
                  <p className="text-sm text-slate-600 leading-relaxed mb-6">
                    This will <span className="font-bold text-red-600 uppercase">permanently delete</span> all employees, biometric logs, and system configurations. This action cannot be undone.
                  </p>
                  
                  <div className="space-y-3">
                    <label className="block text-xs font-bold text-slate-500 uppercase tracking-normal">
                      Type <span className="text-red-600 select-all underline decoration-red-200">DELETE</span> to confirm
                    </label>
                    <input 
                      type="text"
                      autoFocus
                      placeholder="Type DELETE"
                      value={purgeConfirmationInput}
                      onChange={(e) => setPurgeConfirmationInput(e.target.value)}
                      className="w-full px-4 py-3 bg-slate-50 border-2 border-slate-100 rounded-xl text-center font-semibold tracking-normal text-slate-900 focus:border-red-500 focus:bg-white outline-none transition-all placeholder:text-slate-300 placeholder:font-normal placeholder:tracking-normal"
                    />
                  </div>
                </div>
                <div className="bg-slate-50 p-4 border-t border-slate-100 flex gap-3">
                  <button 
                    onClick={() => {
                      setIsConfirmingPurge(false);
                      setPurgeConfirmationInput('');
                    }}
                    className="flex-1 px-4 py-2.5 bg-white border border-slate-200 text-slate-600 rounded-xl text-sm font-bold hover:bg-slate-100 transition-colors"
                  >
                    Cancel
                  </button>
                  <button 
                    onClick={handleClearAllData}
                    disabled={purgeConfirmationInput !== 'DELETE'}
                    className="flex-[2] px-4 py-2.5 bg-red-600 text-white rounded-xl text-sm font-bold hover:bg-red-700 transition-all disabled:opacity-30 disabled:cursor-not-allowed shadow-lg shadow-red-200"
                  >
                    Purge All Data
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
