import React, { createContext, useContext, useState, useEffect, useCallback, useMemo } from 'react';
import type { Employee, RawPunch, ProcessedAttendance, Settings, ShiftAssignment, AssignmentLog, AttendanceException, AuditLog, OvertimeRecord, SBLRecord, ForceAttendanceRecord } from '../types';
import { processPunches, detectExceptions } from '../lib/engine';
import { onAuthStateChanged } from 'firebase/auth';
import { db, auth } from '../lib/firebase';
import { logAdminOverride } from '../lib/audit';
import { toast } from 'sonner';
import { 
  collection, 
  onSnapshot, 
  doc, 
  setDoc, 
  getDoc,
  deleteDoc, 
  writeBatch,
  query,
  limit,
  orderBy,
  getDocs,
  where
} from 'firebase/firestore';

enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
  }
}

interface StoreState {
  employees: Employee[];
  punches: RawPunch[];
  settings: Settings;
  shiftAssignments: ShiftAssignment[];
  assignmentLogs: AssignmentLog[];
  exceptions: AttendanceException[];
  auditLogs: AuditLog[];
  overtimeRecords: OvertimeRecord[];
  sblRecords: SBLRecord[];
  forceAttendanceRecords: ForceAttendanceRecord[];
  calculationSource: 'all' | 'standard' | 'multi-time';
  processedData: ProcessedAttendance[];
  isInitializing: boolean;
  user: any;
  isAdmin: boolean;
  selectedEmployeeId: string | null;
  lastError: string | null;
  quotaExceeded: boolean;
  theme: 'light' | 'dark';
  globalSearchTerm: string;
  isOtpVerified: boolean;
  
  // Actions
  setUser: (user: any) => void;
  setIsAdmin: (isAdmin: boolean) => void;
  setIsOtpVerified: (isVerified: boolean) => void;
  setTheme: (theme: 'light' | 'dark') => void;
  setGlobalSearchTerm: (term: string) => void;
  openEmployeeProfile: (id: string) => void;
  closeEmployeeProfile: () => void;
  setEmployees: (data: Employee[]) => Promise<void>;
  updateEmployee: (id: string, data: Partial<Employee>) => Promise<void>;
  addEmployee: (data: Employee) => Promise<void>;
  deleteEmployeesBatch: (ids: string[]) => Promise<void>;
  
  setPunches: (data: RawPunch[], onProgress?: (msg: string) => void) => Promise<void>;
  addPunch: (punch: Omit<RawPunch, 'id'>) => Promise<void>;
  updatePunch: (id: string, punch: Partial<RawPunch>) => Promise<void>;
  deletePunch: (id: string) => Promise<void>;
  deletePunchBatch: (importId: string) => Promise<void>;
  deletePunchesBatch: (ids: string[]) => Promise<void>;
  clearPunches: (onProgress?: (msg: string) => void) => Promise<void>;
  fetchPunches: () => Promise<void>;
  
  setSettings: (data: Settings) => Promise<void>;
  setShiftAssignments: (data: ShiftAssignment[]) => Promise<void>;
  addAssignmentLog: (employeeId: string, date: string, shiftId: string, action: AssignmentLog['action']) => Promise<void>;
  
  addAuditLog: (log: Omit<AuditLog, 'id' | 'timestamp'>) => Promise<void>;
  updateException: (id: string, data: Partial<AttendanceException>) => Promise<void>;
  setExceptionsBatch: (data: AttendanceException[]) => Promise<void>;

  // OT, SBL, Force Attendance
  updateOvertime: (id: string, data: Partial<OvertimeRecord>) => Promise<void>;
  addOvertime: (data: Omit<OvertimeRecord, 'id'>) => Promise<void>;
  updateSBL: (id: string, data: Partial<SBLRecord>) => Promise<void>;
  addSBL: (data: Omit<SBLRecord, 'id'>) => Promise<void>;
  deleteOvertime: (id: string) => Promise<void>;
  deleteSBL: (id: string) => Promise<void>;
  addForceAttendance: (data: Omit<ForceAttendanceRecord, 'id' | 'timestamp'>) => Promise<void>;

  setCalculationSource: (source: 'all' | 'standard' | 'multi-time') => void;
  recalculate: () => Promise<void>;
  clearAllData: () => Promise<void>;
  resetError: () => void;
  reportError: (error: unknown, operationType?: OperationType, path?: string | null) => void;
}

const StoreContext = createContext<StoreState | undefined>(undefined);

const defaultSettings: Settings = {
  duplicateMergeTime: 5,
  shiftStartTime: "09:00",
  shiftEndTime: "18:00",
  graceTime: 15,
  lateThreshold: 30,
  overtimeThreshold: 8,
  companyName: "Contractor HRIS",
  reportTitle: "Contractor Attendance Report",
  shifts: [
    { id: 'shift-1', name: 'Day Shift', startTime: '09:00', endTime: '18:00', isNightShift: false },
    { id: 'shift-2', name: 'Night', startTime: '22:00', endTime: '06:00', isNightShift: true },
  ]
};

export function StoreProvider({ children }: { children: React.ReactNode }) {
  const [employees, setEmployeesState] = useState<Employee[]>([]);
  const [punches, setPunchesState] = useState<RawPunch[]>([]);
  const [settings, setSettingsState] = useState<Settings>(defaultSettings);
  const [shiftAssignments, setShiftAssignmentsState] = useState<ShiftAssignment[]>([]);
  const [assignmentLogs, setAssignmentLogsState] = useState<AssignmentLog[]>([]);
  const [exceptions, setExceptionsState] = useState<AttendanceException[]>([]);
  const [auditLogs, setAuditLogsState] = useState<AuditLog[]>([]);
  const [overtimeRecords, setOvertimeRecordsState] = useState<OvertimeRecord[]>([]);
  const [sblRecords, setSblRecordsState] = useState<SBLRecord[]>([]);
  const [forceAttendanceRecords, setForceAttendanceRecordsState] = useState<ForceAttendanceRecord[]>([]);
  const [calculationSource, setCalculationSource] = useState<'all' | 'standard' | 'multi-time'>('all');
  const [user, setUser] = useState<any>(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [selectedEmployeeId, setSelectedEmployeeId] = useState<string | null>(null);
  const [isInitializing, setIsInitializing] = useState(true);
  const [lastError, setLastError] = useState<string | null>(null);
  const [theme, setThemeState] = useState<'light' | 'dark'>(() => {
    const saved = localStorage.getItem('theme');
    return (saved as 'light' | 'dark') || 'light';
  });
  const [globalSearchTerm, setGlobalSearchTerm] = useState('');
  const [isOtpVerified, setIsOtpVerifiedState] = useState(() => {
    return sessionStorage.getItem('is_otp_verified') === 'true';
  });

  const setIsOtpVerified = useCallback((isVerified: boolean) => {
    setIsOtpVerifiedState(isVerified);
    sessionStorage.setItem('is_otp_verified', isVerified ? 'true' : 'false');
  }, []);

  const setTheme = useCallback((newTheme: 'light' | 'dark') => {
    setThemeState(newTheme);
    localStorage.setItem('theme', newTheme);
    if (newTheme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, []);

  // Initialize theme on mount
  useEffect(() => {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [theme]);

  const quotaExceeded = useMemo(() => 
    lastError?.toLowerCase().includes('quota') || 
    lastError?.toLowerCase().includes('resource-exhausted'), 
  [lastError]);

  const checkQuota = useCallback(() => {
    if (quotaExceeded) {
      throw new Error("Firestore Quota Exceeded. Writes are currently blocked. Please wait for the daily reset (usually at midnight US Pacific Time).");
    }
  }, [quotaExceeded]);

  const handleFirestoreError = useCallback((error: any, operationType: OperationType, path: string | null) => {
    const code = error?.code || '';
    const message = error instanceof Error ? error.message : String(error);
    
    // Explicitly check for Firestore resource-exhausted code
    const isQuotaError = 
      code === 'resource-exhausted' || 
      message.toLowerCase().includes('quota') || 
      message.toLowerCase().includes('resource-exhausted');
    
    const displayMessage = isQuotaError 
      ? "Firestore Quota Exceeded. You have reached the free daily limit for database writes. High-volume imports or bulk deletions are restricted until the daily reset (usually midnight UTC)."
      : message;

    const errInfo: FirestoreErrorInfo = {
      error: displayMessage,
      authInfo: {
        userId: auth.currentUser?.uid,
        email: auth.currentUser?.email,
      },
      operationType,
      path
    };
    
    console.error('Firestore Error: ', JSON.stringify(errInfo));
    
    if (isQuotaError) {
      setLastError(displayMessage);
      return new Error(displayMessage);
    }
    
    if (operationType === OperationType.LIST && quotaExceeded) {
      return new Error(displayMessage);
    }

    setLastError(displayMessage);
    return new Error(displayMessage);
  }, [quotaExceeded]);

  const fetchPunches = useCallback(async () => {
    try {
      const q = query(collection(db, 'punches'), orderBy('punchDatetime', 'desc'), limit(1000));
      const s = await getDocs(q);
      setPunchesState(s.docs.map(d => d.data() as RawPunch));
    } catch (e) {
      handleFirestoreError(e, OperationType.LIST, 'punches');
    }
  }, [handleFirestoreError]);

  const processedData = useMemo(() => {
    if (employees.length === 0) return [];
    
    const filteredPunches = calculationSource === 'all' 
      ? punches 
      : punches.filter(p => p.importFormat === calculationSource);
      
    return processPunches(filteredPunches, employees, settings, shiftAssignments);
  }, [punches, employees, settings, shiftAssignments, calculationSource]);

  // Sync Data from Firestore
  useEffect(() => {
    if (!user) {
      // If we're not logged in, we shouldn't be "initializing" the data sync
      // but we might still be initializing the auth state
      return;
    }

    let unsubs: (() => void)[] = [];
    let active = true;

    const startSync = async () => {
      try {
        console.log("Initializing shared Firestore sync for user:", user.email);
        setIsInitializing(true);
        
        if (!active) return;

        unsubs.push(
          onSnapshot(collection(db, 'punches'), 
            (s) => setPunchesState(s.docs.map(d => d.data() as RawPunch)),
            (error) => handleFirestoreError(error, OperationType.LIST, 'punches')
          ),
          onSnapshot(collection(db, 'employees'), 
            (s) => setEmployeesState(s.docs.map(d => d.data() as Employee)),
            (error) => handleFirestoreError(error, OperationType.LIST, 'employees')
          ),
          onSnapshot(doc(db, 'settings', 'config'), 
            (s) => { 
              if (s.exists()) {
                const data = s.data() as Settings;
                // Migration: Fix "My Company" persistence if it exists in DB
                if (data.companyName === "My Company" || !data.companyName) {
                  const updated = { ...data, companyName: "Contractor HRIS" };
                  setSettingsState(updated);
                  // Don't auto-write back here to avoid quota issues, 
                  // but the local state will at least be correct.
                } else {
                  setSettingsState(data);
                }
              } 
            },
            (error) => handleFirestoreError(error, OperationType.LIST, 'settings/config')
          ),
          onSnapshot(collection(db, 'shiftAssignments'), 
            (s) => setShiftAssignmentsState(s.docs.map(d => d.data() as ShiftAssignment)),
            (error) => handleFirestoreError(error, OperationType.LIST, 'shiftAssignments')
          ),
          onSnapshot(query(collection(db, 'assignmentLogs'), orderBy('timestamp', 'desc'), limit(100)), 
            (s) => setAssignmentLogsState(s.docs.map(d => d.data() as AssignmentLog)),
            (error) => handleFirestoreError(error, OperationType.LIST, 'assignmentLogs')
          ),
          onSnapshot(collection(db, 'exceptions'), 
            (s) => setExceptionsState(s.docs.map(d => d.data() as AttendanceException)),
            (error) => handleFirestoreError(error, OperationType.LIST, 'exceptions')
          ),
          onSnapshot(query(collection(db, 'auditLogs'), orderBy('timestamp', 'desc'), limit(500)), 
            (s) => setAuditLogsState(s.docs.map(d => d.data() as AuditLog)),
            (error) => handleFirestoreError(error, OperationType.LIST, 'auditLogs')
          ),
          onSnapshot(collection(db, 'overtime'), 
            (s) => setOvertimeRecordsState(s.docs.map(d => d.data() as OvertimeRecord)),
            (error) => handleFirestoreError(error, OperationType.LIST, 'overtime')
          ),
          onSnapshot(collection(db, 'sbl'), 
            (s) => setSblRecordsState(s.docs.map(d => d.data() as SBLRecord)),
            (error) => handleFirestoreError(error, OperationType.LIST, 'sbl')
          ),
          onSnapshot(collection(db, 'forceAttendance'), 
            (s) => setForceAttendanceRecordsState(s.docs.map(d => d.data() as ForceAttendanceRecord)),
            (error) => handleFirestoreError(error, OperationType.LIST, 'forceAttendance')
          ),
        );
        
        // Wait a very small amount of time for initial snapshot or local cache to resolve
        await new Promise(resolve => setTimeout(resolve, 300));
      } catch (e) {
        console.error("Initialization error:", e);
        handleFirestoreError(e, OperationType.LIST, 'sync');
      } finally {
        if (active) {
          setIsInitializing(false);
        }
      }
    };

    const unsubscribeAuth = onAuthStateChanged(auth, (user) => {
      if (user) {
        startSync();
      } else {
        setEmployeesState([]);
        setPunchesState([]);
        setShiftAssignmentsState([]);
        setAssignmentLogsState([]);
        setIsInitializing(false);
        unsubs.forEach(u => u());
        unsubs = [];
      }
    });

    return () => {
      active = false;
      unsubscribeAuth();
      unsubs.forEach(u => u());
    };
  }, [user?.uid]); // Only re-run if user ID changes, not on every error/quota state change

  const updateEmployee = useCallback(async (id: string, data: Partial<Employee>) => {
    try {
      checkQuota();
      const existing = employees.find(e => e.id === id);
      if (existing) {
        await setDoc(doc(db, 'employees', id), { ...existing, ...data });
      }
    } catch (e) {
      throw handleFirestoreError(e, OperationType.UPDATE, `employees/${id}`);
    }
  }, [employees, handleFirestoreError, checkQuota]);

  const addEmployee = useCallback(async (data: Employee) => {
    try {
      checkQuota();
      await setDoc(doc(db, 'employees', data.id), data);
    } catch (e) {
      throw handleFirestoreError(e, OperationType.CREATE, `employees/${data.id}`);
    }
  }, [handleFirestoreError, checkQuota]);

  const deleteEmployeesBatch = useCallback(async (ids: string[]) => {
    try {
      checkQuota();
      const batchSize = 100; // Smaller batches for better reliability
      for (let i = 0; i < ids.length; i += batchSize) {
        if (quotaExceeded) throw new Error("Quota exceeded during deletion.");
        
        const chunk = ids.slice(i, i + batchSize);
        const batch = writeBatch(db);
        chunk.forEach(id => {
          batch.delete(doc(db, 'employees', id));
        });
        await batch.commit();
        
        // Update local state immediately
        setEmployeesState(prev => prev.filter(emp => !chunk.includes(emp.id)));
        
        await new Promise(resolve => setTimeout(resolve, 100)); // Rate limiting
      }
    } catch (e) {
      throw handleFirestoreError(e, OperationType.DELETE, `employees/batch`);
    }
  }, [handleFirestoreError, checkQuota, quotaExceeded]);

  const addPunch = useCallback(async (data: Omit<RawPunch, 'id'>) => {
    try {
      checkQuota();
      const id = `${data.employeeId}_${data.punchDatetime.replace(/[:.-]/g, '')}`;
      const newPunch = { ...data, id };
      await setDoc(doc(db, 'punches', id), newPunch);
      // Local state will be updated via onSnapshot
    } catch (e) {
      throw handleFirestoreError(e, OperationType.CREATE, 'punches/single');
    }
  }, [handleFirestoreError, checkQuota]);

  const updatePunch = useCallback(async (id: string, data: Partial<RawPunch>) => {
    try {
      checkQuota();
      const existing = punches.find(p => p.id === id);
      if (existing) {
        const updated = { ...existing, ...data };
        await setDoc(doc(db, 'punches', id), updated);
        // Local state will be updated via onSnapshot
      }
    } catch (e) {
      throw handleFirestoreError(e, OperationType.UPDATE, `punches/${id}`);
    }
  }, [punches, handleFirestoreError, checkQuota]);

  const deletePunch = useCallback(async (id: string) => {
    try {
      checkQuota();
      await deleteDoc(doc(db, 'punches', id));
      // Local state will be updated via onSnapshot
    } catch (e) {
      throw handleFirestoreError(e, OperationType.DELETE, `punches/${id}`);
    }
  }, [handleFirestoreError, checkQuota]);

  const deletePunchBatch = useCallback(async (importId: string) => {
    try {
      checkQuota();
      const q = query(collection(db, 'punches'), where('importId', '==', importId));
      const snapshot = await getDocs(q);
      const docs = snapshot.docs;
      
      const batchSize = 500;
      for (let i = 0; i < docs.length; i += batchSize) {
        const chunk = docs.slice(i, i + batchSize);
        const writeBatchObj = writeBatch(db);
        chunk.forEach(d => writeBatchObj.delete(d.ref));
        await writeBatchObj.commit();
      }
      
      setPunchesState(prev => prev.filter(p => p.importId !== importId));
    } catch (e) {
      throw handleFirestoreError(e, OperationType.DELETE, `punches batch ${importId}`);
    }
  }, [handleFirestoreError, checkQuota]);

  const deletePunchesBatch = useCallback(async (ids: string[]) => {
    try {
      checkQuota();
      const batchSize = 500;
      for (let i = 0; i < ids.length; i += batchSize) {
        const chunk = ids.slice(i, i + batchSize);
        const batch = writeBatch(db);
        chunk.forEach(id => {
          batch.delete(doc(db, 'punches', id));
        });
        await batch.commit();
      }
      // Local state will be updated via onSnapshot
    } catch (e) {
      throw handleFirestoreError(e, OperationType.DELETE, `punches/batch`);
    }
  }, [handleFirestoreError, checkQuota]);

  const clearPunches = useCallback(async (onProgress?: (msg: string) => void) => {
    try {
      checkQuota();
      const q = collection(db, 'punches');
      const snapshot = await getDocs(q);
      const docs = snapshot.docs;
      for (let i = 0; i < docs.length; i += 500) {
        if (onProgress) onProgress(`Purging records ${i} to ${Math.min(i + 500, docs.length)} of ${docs.length}...`);
        const chunk = docs.slice(i, i + 500);
        const batch = writeBatch(db);
        chunk.forEach(d => batch.delete(d.ref));
        await batch.commit();
      }
      setPunchesState([]);
    } catch (e) {
      throw handleFirestoreError(e, OperationType.DELETE, 'punches');
    }
  }, [handleFirestoreError, checkQuota]);

  const clearAllData = useCallback(async () => {
    const collectionsList = ['employees', 'punches', 'shiftAssignments', 'assignmentLogs'];
    try {
      checkQuota();
      for (const coll of collectionsList) {
        const q = collection(db, coll);
        const snapshot = await getDocs(q);
        const docs = snapshot.docs;
        for (let i = 0; i < docs.length; i += 500) {
          const chunk = docs.slice(i, i + 500);
          const batch = writeBatch(db);
          chunk.forEach(d => batch.delete(d.ref));
          await batch.commit();
        }
      }
      await deleteDoc(doc(db, 'settings', 'config'));
      window.localStorage.clear();
      window.location.reload();
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, 'clearAllData');
    }
  }, [handleFirestoreError, checkQuota]);

  const setEmployees = useCallback(async (data: Employee[]) => {
    try {
      checkQuota();
      
      const recordsToWrite = data.filter(newE => {
        const existing = employees.find(e => e.id === newE.id);
        return !existing || JSON.stringify(existing) !== JSON.stringify(newE);
      });

      if (recordsToWrite.length === 0) return;

      const total = recordsToWrite.length;
      const batchSize = 500;
      
      for (let i = 0; i < total; i += batchSize) {
        if (quotaExceeded) throw new Error("Quota exceeded during multi-batch write.");
        
        const chunk = recordsToWrite.slice(i, i + batchSize);
        const batch = writeBatch(db);
        chunk.forEach(emp => {
          batch.set(doc(db, 'employees', emp.id), emp);
        });
        await batch.commit();
        
        // Update local state incrementally to stay responsive
        setEmployeesState(prev => {
          const next = [...prev];
          chunk.forEach(e => {
            const index = next.findIndex(existing => existing.id === e.id);
            if (index > -1) next[index] = e;
            else next.push(e);
          });
          return next;
        });
        
        await new Promise(resolve => setTimeout(resolve, 50));
      }
    } catch (e) {
      throw handleFirestoreError(e, OperationType.WRITE, 'employees');
    }
  }, [employees, handleFirestoreError, checkQuota, quotaExceeded]);

  const setPunches = useCallback(async (data: RawPunch[], onProgress?: (msg: string) => void) => {
    try {
      checkQuota();
      
      // Use local state if available, but be aware it might be slightly stale if another batch just committed
      // Actually, for bulk imports, we usually have the full set in 'data'
      const recordsToWrite = data.filter(newP => {
        const existing = punches.find(p => p.id === newP.id);
        if (!existing) return true;
        return JSON.stringify(existing) !== JSON.stringify(newP);
      });

      if (recordsToWrite.length === 0) {
        if (onProgress) onProgress('All records already up to date.');
        return;
      }

      const total = recordsToWrite.length;
      const batchSize = 500;
      
      for (let i = 0; i < total; i += batchSize) {
        if (quotaExceeded) throw new Error("Quota exceeded during multi-batch write.");
        
        const chunk = recordsToWrite.slice(i, i + batchSize);
        const batch = writeBatch(db);
        chunk.forEach(p => {
          batch.set(doc(db, 'punches', p.id), p);
        });
        if (onProgress) onProgress(`Saving ${Math.min(i + batchSize, total)} of ${total} new/updated records...`);
        await batch.commit();
        
        // Update local state incrementally to stay responsive
        setPunchesState(prev => {
          const next = [...prev];
          chunk.forEach(p => {
            const index = next.findIndex(existing => existing.id === p.id);
            if (index > -1) next[index] = p;
            else next.push(p);
          });
          return next;
        });

        // Minor delay to let snapshot listeners settle and potentially avoid tight loops if many small batches
        await new Promise(resolve => setTimeout(resolve, 50));
      }
    } catch (e) {
      throw handleFirestoreError(e, OperationType.WRITE, 'punches');
    }
  }, [punches, handleFirestoreError, checkQuota, quotaExceeded]);

  const setSettings = useCallback(async (data: Settings) => {
    try {
      checkQuota();
      await setDoc(doc(db, 'settings', 'config'), data);
    } catch (e) {
      throw handleFirestoreError(e, OperationType.WRITE, 'settings/config');
    }
  }, [handleFirestoreError, checkQuota]);

  const setShiftAssignments = useCallback(async (data: ShiftAssignment[]) => {
    try {
      checkQuota();
      // Identify records to update or add
      const recordsToWrite = data.filter(newA => {
        const id = `${newA.employeeId}_${newA.date}`;
        const existing = shiftAssignments.find(a => `${a.employeeId}_${a.date}` === id);
        return !existing || JSON.stringify(existing) !== JSON.stringify(newA);
      });

      if (recordsToWrite.length === 0) return;

      const total = recordsToWrite.length;
      const batchSize = 500;
      
      for (let i = 0; i < total; i += batchSize) {
        if (quotaExceeded) throw new Error("Quota exceeded during multi-batch write.");
        
        const chunk = recordsToWrite.slice(i, i + batchSize);
        const batch = writeBatch(db);
        chunk.forEach(a => {
          const id = `${a.employeeId}_${a.date}`;
          batch.set(doc(db, 'shiftAssignments', id), a);
        });
        await batch.commit();
        await new Promise(resolve => setTimeout(resolve, 50));
      }
    } catch (e) {
      throw handleFirestoreError(e, OperationType.WRITE, 'shiftAssignments');
    }
  }, [shiftAssignments, handleFirestoreError, checkQuota, quotaExceeded]);

  const addAssignmentLog = useCallback(async (employeeId: string, date: string, shiftId: string, action: AssignmentLog['action']) => {
    try {
      checkQuota();
      const shift = settings.shifts?.find(s => s.id === shiftId);
      const newLog: AssignmentLog = {
        id: Math.random().toString(36).substr(2, 9),
        employeeId,
        date,
        shiftId,
        shiftName: shift?.name || 'No Shift',
        timestamp: new Date().toISOString(),
        action
      };
      await setDoc(doc(db, 'assignmentLogs', newLog.id), newLog);
    } catch (e) {
      throw handleFirestoreError(e, OperationType.WRITE, 'assignmentLogs');
    }
  }, [settings.shifts, handleFirestoreError, checkQuota]);

  const addAuditLog = useCallback(async (log: Omit<AuditLog, 'id' | 'timestamp'>) => {
    try {
      checkQuota();
      const newLog: AuditLog = {
        ...log,
        id: Math.random().toString(36).substr(2, 9),
        timestamp: new Date().toISOString()
      };
      await setDoc(doc(db, 'auditLogs', newLog.id), newLog);
    } catch (e) {
      throw handleFirestoreError(e, OperationType.WRITE, 'auditLogs');
    }
  }, [handleFirestoreError, checkQuota]);

  const updateException = useCallback(async (id: string, data: Partial<AttendanceException>) => {
    try {
      checkQuota();
      const existing = exceptions.find(ex => ex.id === id);
      if (existing) {
        await setDoc(doc(db, 'exceptions', id), { ...existing, ...data });
      }
    } catch (e) {
      throw handleFirestoreError(e, OperationType.WRITE, `exceptions/${id}`);
    }
  }, [exceptions, handleFirestoreError, checkQuota]);

  const setExceptionsBatch = useCallback(async (data: AttendanceException[]) => {
    try {
      checkQuota();
      const batch = writeBatch(db);
      data.forEach(ex => {
        batch.set(doc(db, 'exceptions', ex.id), ex);
      });
      await batch.commit();
    } catch (e) {
      throw handleFirestoreError(e, OperationType.WRITE, 'exceptions/batch');
    }
  }, [handleFirestoreError, checkQuota]);

  const updateOvertime = useCallback(async (id: string, data: Partial<OvertimeRecord>) => {
    try {
      checkQuota();
      const existing = overtimeRecords.find(r => r.id === id);
      if (existing) {
        await setDoc(doc(db, 'overtime', id), { ...existing, ...data });
      }
    } catch (e) {
      throw handleFirestoreError(e, OperationType.UPDATE, `overtime/${id}`);
    }
  }, [overtimeRecords, handleFirestoreError, checkQuota]);

  const addOvertime = useCallback(async (data: Omit<OvertimeRecord, 'id'>) => {
    try {
      checkQuota();
      const id = `ot_${Math.random().toString(36).substr(2, 9)}`;
      await setDoc(doc(db, 'overtime', id), { ...data, id });
    } catch (e) {
      throw handleFirestoreError(e, OperationType.CREATE, 'overtime');
    }
  }, [handleFirestoreError, checkQuota]);

  const updateSBL = useCallback(async (id: string, data: Partial<SBLRecord>) => {
    try {
      checkQuota();
      const existing = sblRecords.find(r => r.id === id);
      if (existing) {
        await setDoc(doc(db, 'sbl', id), { ...existing, ...data });
      }
    } catch (e) {
      throw handleFirestoreError(e, OperationType.UPDATE, `sbl/${id}`);
    }
  }, [sblRecords, handleFirestoreError, checkQuota]);

  const addSBL = useCallback(async (data: Omit<SBLRecord, 'id'>) => {
    try {
      checkQuota();
      const id = `sbl_${Math.random().toString(36).substr(2, 9)}`;
      await setDoc(doc(db, 'sbl', id), { ...data, id });
    } catch (e) {
      throw handleFirestoreError(e, OperationType.CREATE, 'sbl');
    }
  }, [handleFirestoreError, checkQuota]);

  const deleteOvertime = useCallback(async (id: string) => {
    try {
      checkQuota();
      await deleteDoc(doc(db, 'overtime', id));
      setOvertimeRecordsState(prev => prev.filter(r => r.id !== id));
    } catch (e) {
      throw handleFirestoreError(e, OperationType.DELETE, `overtime/${id}`);
    }
  }, [handleFirestoreError, checkQuota]);

  const deleteSBL = useCallback(async (id: string) => {
    try {
      checkQuota();
      await deleteDoc(doc(db, 'sbl', id));
      setSblRecordsState(prev => prev.filter(r => r.id !== id));
    } catch (e) {
      throw handleFirestoreError(e, OperationType.DELETE, `sbl/${id}`);
    }
  }, [handleFirestoreError, checkQuota]);

  const addForceAttendance = useCallback(async (data: Omit<ForceAttendanceRecord, 'id' | 'timestamp'>) => {
    try {
      checkQuota();
      const id = `force_${data.employeeId}_${data.date.replace(/-/g, '')}`;
      const timestamp = new Date().toISOString();
      await setDoc(doc(db, 'forceAttendance', id), { ...data, id, timestamp });
      
      // Automatic Audit Log for manual attendance override
      const emp = employees.find(e => e.id === data.employeeId);
      
      // New requested Audit Trigger
      await logAdminOverride(
        auth.currentUser?.email || 'unknown@admin.com',
        { status: 'Calculated' },
        { status: 'Forced', inTime: data.inTime, outTime: data.outTime, reason: data.reason }
      );

      await addAuditLog({
        employeeId: data.employeeId,
        employeeName: emp?.name || 'Unknown',
        date: data.date,
        field: 'Attendance Override',
        oldValue: 'Calculated',
        newValue: `${data.inTime} - ${data.outTime}`,
        changedBy: data.approvedBy || auth.currentUser?.email?.split('@')[0] || 'Admin',
        remarks: data.remarks || data.reason
      });
    } catch (e) {
      throw handleFirestoreError(e, OperationType.CREATE, 'forceAttendance');
    }
  }, [handleFirestoreError, checkQuota, employees, addAuditLog]);

  const recalculate = useCallback(async () => {
    const tId = toast.loading('Synchronizing entire system state...');
    try {
      const [
        pSnapshot, eSnapshot, sSnapshot, saSnapshot, 
        exSnapshot, otSnapshot, sblSnapshot, forceSnapshot
      ] = await Promise.all([
        getDocs(collection(db, 'punches')),
        getDocs(collection(db, 'employees')),
        getDoc(doc(db, 'settings', 'config')),
        getDocs(collection(db, 'shiftAssignments')),
        getDocs(collection(db, 'exceptions')),
        getDocs(collection(db, 'overtime')),
        getDocs(collection(db, 'sbl')),
        getDocs(collection(db, 'forceAttendance'))
      ]);
      
      setPunchesState(pSnapshot.docs.map(d => d.data() as RawPunch));
      setEmployeesState(eSnapshot.docs.map(d => d.data() as Employee));
      if (sSnapshot.exists()) setSettingsState(sSnapshot.data() as Settings);
      setShiftAssignmentsState(saSnapshot.docs.map(d => d.data() as ShiftAssignment));
      setExceptionsState(exSnapshot.docs.map(d => d.data() as AttendanceException));
      setOvertimeRecordsState(otSnapshot.docs.map(d => d.data() as OvertimeRecord));
      setSblRecordsState(sblSnapshot.docs.map(d => d.data() as SBLRecord));
      setForceAttendanceRecordsState(forceSnapshot.docs.map(d => d.data() as ForceAttendanceRecord));
      
      toast.success('Enterprise data synchronized', { id: tId });
    } catch (e) {
      toast.error('Synchronization failed', { id: tId });
      handleFirestoreError(e, OperationType.LIST, 'recalculate');
    }
  }, [handleFirestoreError]);
  const resetError = useCallback(() => setLastError(null), []);

  const openEmployeeProfile = useCallback((id: string) => setSelectedEmployeeId(id), []);
  const closeEmployeeProfile = useCallback(() => setSelectedEmployeeId(null), []);

  const reportError = useCallback((error: unknown, operationType: OperationType = OperationType.WRITE, path: string | null = null) => {
    handleFirestoreError(error, operationType, path);
  }, [handleFirestoreError]);

  const value: StoreState = {
    employees, setEmployees, updateEmployee, addEmployee, deleteEmployeesBatch,
    punches, setPunches, addPunch, updatePunch, deletePunch, deletePunchBatch, deletePunchesBatch, clearPunches, fetchPunches,
    settings, setSettings,
    shiftAssignments, setShiftAssignments,
    assignmentLogs,
    addAssignmentLog,
    exceptions,
    auditLogs,
    addAuditLog,
    updateException,
    setExceptionsBatch,
    overtimeRecords,
    sblRecords,
    forceAttendanceRecords,
    updateOvertime,
    addOvertime,
    deleteOvertime,
    updateSBL,
    addSBL,
    deleteSBL,
    addForceAttendance,
    calculationSource, setCalculationSource,
    processedData,
    user, setUser,
    isAdmin, setIsAdmin,
    isOtpVerified, setIsOtpVerified,
    theme, setTheme,
    globalSearchTerm, setGlobalSearchTerm,
    selectedEmployeeId,
    openEmployeeProfile,
    closeEmployeeProfile,
    isInitializing,
    lastError,
    quotaExceeded,
    recalculate,
    clearAllData,
    resetError,
    reportError
  };

  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>;
}

export function useAppStore() {
  const context = useContext(StoreContext);
  if (context === undefined) {
    throw new Error('useAppStore must be used within a StoreProvider');
  }
  return context;
}

