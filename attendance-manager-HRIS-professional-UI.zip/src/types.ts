export type Role = 'Admin' | 'Editor' | 'HR' | 'Supervisor';

export interface User {
  id: string;
  username: string;
  role: Role;
}

export interface ShiftMaster {
  id: string;
  name: string;
  startTime: string; // "HH:mm"
  endTime: string; // "HH:mm"
  isNightShift: boolean;
  graceTime?: number; // minutes
  lateThreshold?: number; // minutes
}

export interface Employee {
  id: string; // Employee ID
  name: string;
  department: string;
  designation: string;
  shiftId?: string; // Reference to ShiftMaster
  joiningDate: string;
  status: 'Active' | 'Inactive';
  contractorName?: string;
  contactNumber?: string;
  weeklyOff?: string; // e.g., "Sunday"
  otEligible?: boolean;
  targetWorkingHours?: number; // e.g., 8
  profilePicture?: string;
  accommodation?: string;
  email?: string;
  phone?: string;
  aadharNumber?: string;
}

export interface RawPunch {
  id: string;
  employeeId: string; // Maps to Employee.id
  punchDatetime: string; // ISO string
  deviceId?: string;
  location?: string;
  importFormat?: 'standard' | 'multi-time';
  importId?: string;
  importDate?: string;
  fileName?: string;
}

export interface ProcessedAttendance {
  id: string;
  employeeId: string;
  date: string; // YYYY-MM-DD logical date
  firstPunch: string | null; // ISO string
  lastPunch: string | null; // ISO string
  workingHours: number; // in hours
  overtime: number; // in hours
  shiftId?: string; // Assigned or default shift ID
  expectedHours?: number; // Duration of the shift in hours
  status: 'Present' | 'Absent' | 'Late' | 'SPF' | 'Weekly Off' | 'Early' | 'On Time' | 'Overtime' | 'PWO'; // SPF = Single Punch Found, PWO = Present on Weekly Off
  lateMinutes: number;
  earlyMinutes: number;
  logs: string[]; // Array of ISO strings (filtered punches)
  rawLogs: string[]; // Array of ISO strings (unfiltered punches)
}

export interface ShiftAssignment {
  employeeId: string;
  date: string; // YYYY-MM-DD
  shiftId: string;
}

export type ExceptionType = 
  | 'SPF' 
  | 'Missing In' 
  | 'Missing Out' 
  | 'Duplicate Punch' 
  | 'Shift Mismatch' 
  | 'Short Hours' 
  | 'Long Hours' 
  | 'Punch Outside Shift'
  | 'No Punch Attendance';

export interface AttendanceException {
  id: string;
  employeeId: string;
  date: string; // YYYY-MM-DD
  type: ExceptionType;
  description: string;
  severity: 'low' | 'medium' | 'high';
  status: 'pending' | 'resolved' | 'ignored';
  resolvedBy?: string;
  resolvedAt?: string;
  remarks?: string;
}

export interface AuditLog {
  id: string;
  employeeId: string;
  employeeName: string;
  date: string; // The date of the record being audited
  field: string; // e.g., 'firstPunch', 'lastPunch', 'shiftId'
  oldValue: string;
  newValue: string;
  changedBy: string;
  timestamp: string; // ISO string
  remarks: string;
}

export interface OvertimeRecord {
  id: string;
  employeeId: string;
  date: string;
  hours: number; // This will be the Final OT Eligible
  bioOtHours: number;
  supervisorOtHours: number;
  hrSaving: number;
  standardDutyHours: number;
  otStartTime?: string; // HH:mm
  otEndTime?: string; // HH:mm
  type: 'Regular' | 'Holiday' | 'Weekly Off';
  status: 'Pending' | 'Approved' | 'Rejected';
  approvedBy?: string;
  reviewedBy?: string;
  reviewedDate?: string;
  remarks: string;
  shiftId?: string;
}

export interface SBLRecord {
  id: string;
  employeeId: string;
  date: string;
  leaveType: 'SBL' | 'Short Break';
  duration: string; // e.g., "2 hours"
  reason: string;
  status: 'Pending' | 'Approved' | 'Rejected' | 'Final Confirmed' | 'Not Approved';
  approvedBy?: string;
}

export interface ForceAttendanceRecord {
  id: string;
  employeeId: string;
  date: string;
  inTime: string; // HH:mm
  outTime: string; // HH:mm
  reason: string;
  approvedBy: string;
  remarks: string;
  timestamp: string;
}

export interface AssignmentLog {
  id: string;
  employeeId: string;
  date: string;
  shiftId: string;
  shiftName: string;
  timestamp: string;
  action: 'Assigned' | 'Updated' | 'Removed';
}

export interface Settings {
  duplicateMergeTime: number; // minutes, default 5
  shiftStartTime: string; // "09:00"
  shiftEndTime: string; // "18:00"
  graceTime: number; // minutes, default 15
  lateThreshold: number; // minutes, default 30
  overtimeThreshold: number; // working hours after which OT starts
  companyName: string;
  reportTitle: string;
  shifts: ShiftMaster[];
  calculationStartDate?: string; // YYYY-MM-DD
  calculationEndDate?: string; // YYYY-MM-DD
  holidays?: { date: string; name: string }[];
}
